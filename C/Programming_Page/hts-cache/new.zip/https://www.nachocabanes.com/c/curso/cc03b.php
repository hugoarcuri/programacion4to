<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 3 - Estructuras alternativas</title>

    
    <meta name="description" content="Curso de C - Tema 3 - Estructuras alternativas - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="bucle,alternativa,if,while,repeat,switch,case" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 3 - Estructuras alternativas          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc03.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc03c.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h3>3.2. Estructuras repetitivas</h3>


<p style="margin-left:150px;margin-right:150px;text-align:center;"><i>(Nota: 
En la <a href="../curso2016/">versión 2016 del curso</a>
tienes <a href="../curso2016/cc003b.php">una variante más reciente y más detallada de este apartado</a>)</i></p>


<p>Hemos visto c&oacute;mo comprobar condiciones, pero no c&oacute;mo hacer que una cierta parte de un programa se repita un cierto n&uacute;mero de veces o mientras se cumpla una condici&oacute;n (lo que llamaremos un &ldquo;<strong>bucle</strong>&rdquo;). En C tenemos varias formas de conseguirlo.</p>
<h4>3.2.1. while</h4>
<p>Si queremos hacer que una secci&oacute;n de nuestro programa se repita mientras se cumpla una cierta condici&oacute;n, usaremos la orden &ldquo;while&rdquo;. Esta orden tiene dos formatos distintos, seg&uacute;n comprobemos la condici&oacute;n al principio o al final.</p>
<p>En el primer caso, su sintaxis es</p>
<p> <span class="nsource">while (condici&oacute;n)<br />
 &nbsp;&nbsp; sentencia;</span></p>
<p>Es decir, la sentencia se repetir&aacute; <strong>mientras</strong> la condici&oacute;n sea cierta. Si la condici&oacute;n es falsa ya desde un principio, la sentencia no se ejecuta nunca. Si queremos que se repita m&aacute;s de una sentencia, basta agruparlas entre { y }. Como ocurria con "if", puede ser recomendable incluir siempre las llaves, aunque sea una única sentencia, para evitar errores posteriores difíciles de localizar.</p>

<p>Un ejemplo que nos diga si cada n&uacute;mero que tecleemos es positivo o negativo, y que pare cuando tecleemos el n&uacute;mero 0, podr&iacute;a ser:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 26:      */
/*  C026.C                   */
/*                           */
/*  La orden "while"         */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  int numero;

  printf("Teclea un número (0 para salir): ");
  scanf("%d", &numero);
  while (numero!=0)
  {
    if (numero > 0) printf("Es positivo\n");
      else printf("Es negativo\n");
    printf("Teclea otro número (0 para salir): ");
    scanf("%d", &numero);
  }
      
  return 0;
}
</code></pre></p>    

<p>En este ejemplo, si se introduce 0 la primera vez, la condici&oacute;n es falsa y ni siquiera se entra al bloque del &ldquo;while&rdquo;, terminando el programa inmediatamente.</p>
<p>Nota: si recordamos que una condici&oacute;n falsa se eval&uacute;a como el valor 0 y una condici&oacute;n verdadera como una valor distinto de cero, veremos que ese &ldquo;while (numero != 0)&rdquo; se podr&iacute;a abreviar como &ldquo;while (numero)&rdquo;.</p>
<p><strong>Ejercicios propuestos: </strong></p>

<ul>
  <li> Crear un programa que pida al usuario su contrase&ntilde;a (num&eacute;rica). Deber&aacute; terminar cuando introduzca como contrase&ntilde;a el n&uacute;mero 4567, pero volv&eacute;rsela a pedir tantas veces como sea necesario. </li>
  <li> Crea un programa que escriba en pantalla los n&uacute;meros del 1 al 10, usando “while”. </li>
  <li> Crea un programa que escriba en pantalla los n&uacute;meros pares del 26 al 10 (descen&shy;diendo), usando “while”. </li>
  <li> Crear un programa calcule cuantas cifras tiene un n&uacute;mero entero positivo (pista: se puede hacer dividiendo varias veces entre 10). </li>
</ul>
<h4>3.2.2. do ... while</h4>
<p>Este es el otro formato que puede tener la orden &ldquo;while&rdquo;: la condici&oacute;n se comprueba<strong> al final</strong>. El punto en que comienza a repetirse se indica con la orden &ldquo;do&rdquo;, as&iacute;:</p>
<p class="nsource"> do <br />
  sentencia;<br />
  while (condici&oacute;n);</p>
<p>Al igual que en el caso anterior, si queremos que se repitan varias &oacute;rdenes (es lo habitual), deberemos encerrarlas entre llaves. Nuevamente, puede ser recomendable incluir siempre las llaves, como costumbre.</p>
<p>Como ejemplo, vamos a ver c&oacute;mo ser&iacute;a el t&iacute;pico programa que nos pide una clave de acceso y nos nos deja entrar hasta que tecleemos la clave correcta. Eso s&iacute;, como todav&iacute;a no sabemos manejar cadenas de texto, la clave ser&aacute; un n&uacute;mero:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 27:      */
/*  C027.C                   */
/*                           */
/*  La orden "do..while"     */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  int valida = 711;
  int clave;

  do
  {
    printf("Introduzca su clave numérica: ");
    scanf("%d", &clave);
    if (clave != valida) printf("No válida!\n");
  }
  while (clave != valida);
  printf("Aceptada.\n");
      
  return 0;
}
</code></pre></p>    



<p>En este caso, se comprueba la condici&oacute;n al final, de modo que se nos preguntar&aacute; la clave al menos una vez. Mientras que la respuesta que demos no sea la correcta, se nos vuelve a preguntar. Finalmente, cuando tecleamos la clave correcta, el ordenador escribe &ldquo;Aceptada&rdquo; y termina el programa.</p>
<p><strong>Ejercicios propuestos: </strong></p>
<ul>
  <li> Crear un programa que pida n&uacute;meros positivos al usuario, y vaya calculando la suma de todos ellos (terminar&aacute; cuando se teclea un n&uacute;mero negativo o cero). </li>
  <li> Crea un programa que escriba en pantalla los n&uacute;meros del 1 al 10, usando &quot;do..while&quot;. </li>
  <li> Crea un programa que escriba en pantalla los n&uacute;meros pares del 26 al 10 (descen&shy;diendo), usando &quot;do..while&quot;. </li>
  <li> Crea un programa que pida al usuario su c&oacute;digo de usuario (un n&uacute;mero entero) y su contrase&ntilde;a num&eacute;rica (otro n&uacute;mero entero), y no le permita seguir hasta que introduzca como c&oacute;digo 1024 y como contrase&ntilde;a 4567. </li>
</ul>
<h4>3.2.3. for</h4>
<p>&Eacute;sta es la orden que usaremos habitualmente para crear partes del programa que se repitan un cierto <strong>n&uacute;mero de veces</strong>. El formato de &ldquo;for&rdquo; es</p>
<p> <span class="nsource">for (valorInicial; Condici&oacute;nRepetici&oacute;n; Incremento)<br />
 &nbsp; Sentencia;</span></p>
<p>As&iacute;, para <strong>contar del 1 al 10</strong>, tendr&iacute;amos 1 como valor inicial, &lt;=10 como condici&oacute;n de repetici&oacute;n, y el incremento ser&iacute;a de 1 en 1. Por tanto, el programa quedar&iacute;a:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 28:      */
/*  C028.C                   */
/*                           */
/*  Uso básico de "for"      */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  int contador;

  for (contador=1; contador<=10; contador++)
    printf("%d ", contador);
      
  return 0;
}
</code></pre></p>    

<p>Recordemos que &ldquo;contador++&rdquo; es una forma abreviada de escribir &ldquo;contador=contador+1&rdquo;, de modo que en este ejemplo aumentamos la variable de uno en uno.</p>

<p><strong>Ejercicios propuestos</strong>:</p>
<ul>
  <li> Crear un programa que muestre los n&uacute;meros del 15 al 5, descendiendo (pista: en cada pasada habr&aacute; que descontar 1, por ejemplo haciendo i--).</li>
  <li> Crear un programa que muestre los primeros ocho n&uacute;meros pares (pista: en cada pasada habr&aacute; que aumentar de 2 en 2, o bien mostrar el doble del valor que hace de contador).<br />
  </li>
</ul>

<p>En un &ldquo;for&rdquo;, realmente, la parte que hemos llamado &ldquo;Incremento&rdquo; no tiene por qu&eacute; incrementar la variable, aunque &eacute;se es su uso m&aacute;s habitual. Es simplemente una orden que se ejecuta cuando se termine la &ldquo;Sentencia&rdquo; y antes de volver a comprobar si todav&iacute;a se cumple la condici&oacute;n de repetici&oacute;n. </p>
<p>Por eso, si escribimos la siguiente l&iacute;nea:</p>
<p> for (contador=1; contador&lt;=10; )</p>
<p>la variable &ldquo;contador&rdquo; no se incrementa nunca, por lo que nunca se cumplir&aacute; la condici&oacute;n de salida: nos quedamos encerrados dando vueltas dentro de la orden que siga al &ldquo;for&rdquo;.</p>
<p>Un caso todav&iacute;a m&aacute;s exagerado de algo a lo que se entra y de lo que no se sale ser&iacute;a la siguiente orden:</p>
<p> for ( ; ; )<br />
    <br />
    Los bucles &ldquo;for&rdquo; se pueden <strong>anidar</strong> (incluir uno dentro de otro), de modo que podr&iacute;amos escribir las tablas de multiplicar del 1 al 5 con:</p>
    
<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 29:      */
/*  C029.C                   */
/*                           */
/*  "for" anidados           */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  int tabla, numero;

  for (tabla=1; tabla<=5; tabla++)
    for (numero=1; numero<=10; numero++)
      printf("%d por %d es %d\n", tabla, numero, tabla*numero);
          
  return 0;
}
</code></pre></p>    


<p>En estos ejemplos que hemos visto, despu&eacute;s de &ldquo;for&rdquo; hab&iacute;a una &uacute;nica sentencia. Si queremos que se hagan varias cosas, basta definirlas como un <strong>bloque</strong> (una sentencia compuesta) encerr&aacute;ndolas entre llaves. Por ejemplo, si queremos mejorar el ejemplo anterior haciendo que deje una l&iacute;nea en blanco entre tabla y tabla, ser&iacute;a:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 30:      */
/*  C030.C                   */
/*                           */
/*  "for" anidados (2)       */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
    int tabla, numero;

    for (tabla=1; tabla<=5; tabla++)
    {
        for (numero=1; numero<=10; numero++)
           printf("%d por %d es %d\n", tabla, numero, tabla*numero);
        printf("\n");
    }
        
  return 0;
}
</code></pre></p>    


<p>Al igual que ocurría con "if" y con "while", suele ser buena costumbre <b>incluir siempre las llaves</b>, aunque haya una única orden que se repita en el "for", para evitar funcionamientos incorrectos si después hay que añadir más sentencias que deban repetirse y se olvida incluir las llaves en ese momento.</p>
<p>&nbsp; </p>

<p>Para &ldquo;contar&rdquo; no necesariamente hay que usar n&uacute;meros. Por ejemplo, podemos<strong> contar con letras</strong> as&iacute;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 31:      */
/*  C031.C                   */
/*                           */
/*  "for" que usa "char"     */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  char letra;

  for (letra='a'; letra<='z'; letra++)
    printf("%c", letra);
        
  return 0;
}
</code></pre></p>    


<p>En este caso, empezamos en la &ldquo;a&rdquo; y terminamos en la &ldquo;z&rdquo;, aumentando de uno en uno.<br />
</p>
<p> <br />
  Si queremos contar de forma <strong>decreciente</strong>, o de dos en dos, o como nos interese, basta indicarlo en la condici&oacute;n de finalizaci&oacute;n del &ldquo;for&rdquo; y en la parte que lo incrementa:</p>
  
<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 32:      */
/*  C032.C                   */
/*                           */
/*  "for" que descuenta      */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  char letra;

  for (letra='z'; letra>='a'; letra-=2)
    printf("%c", letra);
        
  return 0;
}
</code></pre></p>      
  

<p><strong>Ejercicios propuestos</strong>: </p>
<ul>
  <li>Crear un programa que muestre las letras de la Z (may&uacute;scula) a la A (may&uacute;scula, descendiendo).</li>
  <li>Crear un programa que escriba en pantalla la tabla de multiplicar del 6.</li>
  <li>Crear un programa que escriba en pantalla los n&uacute;meros del 1 al 50 que sean m&uacute;ltiplos de 3 (pista: habr&aacute; que recorrer todos esos n&uacute;meros y ver si el resto de la divisi&oacute;n entre 3 resulta 0).</li>
</ul>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   44618 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc03.php">Anterior</a></li>
                    <li><a href="cc03c.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        