<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 7 - Funciones</title>

    
    <meta name="description" content="Curso de C - Tema 7 - Funciones - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="valor,referencia,recursividad,return" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 7 - Funciones          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc07c.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc07e.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>7.4. Valor devuelto por una funci&oacute;n</h3>
<p>Tambi&eacute;n es habitual que queramos que nuestra funci&oacute;n realice una serie de c&aacute;lculos y nos "devuelva" el resultado de esos c&aacute;lculos, para poderlo usar desde cualquier otra parte de nuestro programa. Por ejemplo, podr&iacute;amos crear una funci&oacute;n para elevar un n&uacute;mero entero al cuadrado as&iacute;:</p>

<p><pre><code class='language-c'>int cuadrado ( int n ) {
  return n*n;
}

int main() {
  int numero;
  int resultado;

  numero= 5;
  resultado = cuadrado(numero);
  printf("El cuadrado del numero es %d", resultado);
  printf(" y el de 3 es %d", cuadrado(3));

  return 0;
}
</code></pre></p>

<p>Podemos hacer una funci&oacute;n que nos diga cual es el mayor de dos n&uacute;meros reales as&iacute;:</p>

<p><pre><code class='language-c'>float mayor ( float n1, float n2 ) {
  if (n1>n2)
    return n1;
  else
    return n2;
}
</code></pre></p>

<p>Esto tiene mucho que ver con el "return 0" que siempre estamos indicando al final de "main". Lo veremos en el siguiente apartado.</p>


<p><strong>Ejercicios propuestos</strong>: </p>
<ul>
  <li> Crear una funci&oacute;n que calcule el cubo de un n&uacute;mero real (float). El resultado deber&aacute; ser otro n&uacute;mero real. Probar esta funci&oacute;n para calcular el cubo de 3.2 y el de 5.</li>
  <li>Crear una funci&oacute;n que calcule cual es el menor de dos n&uacute;meros enteros. El resultado ser&aacute; otro n&uacute;mero entero.</li>
  <li> Crear una funci&oacute;n llamada “signo”, que reciba un n&uacute;mero real, y devuelva un n&uacute;mero entero con el valor: -1 si el n&uacute;mero es negativo, 1 si es positivo o 0 si es cero.</li>
  <li>Crear una funci&oacute;n que devuelva la primera letra de una cadena de texto. Probar esta funci&oacute;n para calcular la primera letra de la frase “Hola”</li>
  <li> Crear una funci&oacute;n que devuelva la &uacute;ltima letra de una cadena de texto. Probar esta funci&oacute;n para calcular la &uacute;ltima letra de la frase “Hola”. <br />
  </li>
</ul>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   14265 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc07c.php">Anterior</a></li>
                    <li><a href="cc07e.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        