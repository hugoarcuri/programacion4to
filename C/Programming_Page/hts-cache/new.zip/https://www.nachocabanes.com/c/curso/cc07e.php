<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 7 - Funciones</title>

    
    <meta name="description" content="Curso de C - Tema 7 - Funciones - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="valor,referencia,recursividad,return" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 7 - Funciones          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc07d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc07f.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h3>7.5. El valor de retorno "void". El valor de retorno de "main"</h3>
<p>Cuando queremos dejar claro que una funci&oacute;n no tiene que devolver ning&uacute;n valor, podemos hacerlo indicando al principio que el tipo de datos va a ser "void" (nulo). Por ejemplo, nuestra funci&oacute;n "saludar", que se limitaba a escribir varios textos en pantalla, quedar&iacute;a m&aacute;s correcta si fuera as&iacute;:</p>


<p><pre><code class='language-c'>void saludar() {
  printf("Bienvenido al programa\n");
  printf(" de ejemplo\n");
  printf("Bienvenido al programa\n");
}
</code></pre></p>

<p>Muchos compiladores antiguos (previos al estándar C99) permiten que una función se indique sin tipo devuelto, como hicimos en el primer ejemplo, y en ese caso, el lenguaje C no supondrá que no vaya a devolver ningún valor, sino que <b>devolverá un valor entero</b> (int):</p>

<p><pre><code class='language-c'>main() {
  ...
}
</code></pre></p>
<p>A partir del estándar C99, es obligatorio indicar el tipo devuelto, así que deberemos usar explícitamente "void", si la función no va a devolver ningún dato.  Por eso, la forma habitual de declarar el cuerpo de un programa es:</p>

<p><pre><code class='language-c'>int main() {
  ...
}
</code></pre></p>

<p>Eso quiere decir que "main" también devuelve un valor, que se leerá desde fuera de nuestro programa. Lo habitual es devolver 0 si todo ha funcionado correctamente</p>

<p><pre><code class='language-c'>int main() {
  ...
  return 0;
}
</code></pre></p>
<p>Y devolver&iacute;amos otro valor si hubiera habido alg&uacute;n problema durante el funcionamiento de nuestro programa (por ejemplo, si no hemos podido abrir alg&uacute;n fichero):</p>

<p><pre><code class='language-c'>int main() {
  FILE* fichero;
  fichero = fopen("nombre.txt", "rt");
  if (fichero == NULL) return 1;
  ...
  return 0;
}
</code></pre></p>
<p>Este valor se podr&iacute;a comprobar desde el sistema operativo. Por ejemplo, en MsDos y Windows se lee con "IF ERRORLEVEL", as&iacute;:</p>
<p><pre>IF ERRORLEVEL 1 ECHO Ha habido un error en el programa</pre><br />
</p>

<p>Nota 1: En la mayoría de compiladores, el cuerpo del programa ("main") debe ser devolver un entero (int). Algunos compiladores permiten declarar "main" como "void", pero la mayoría no lo consideran aceptable.</p>

<p>Nota 2: En algunos lenguajes de programaci&oacute;n se llama "procedimientos" (en ingl&eacute;s "procedure") o "subrutinas" a las funciones que no devuelven ning&uacute;n valor, y se reserva el nombre "funci&oacute;n" para las que s&iacute; dan un resultado.</p>

<p><strong>Ejercicios propuestos</strong>: </p>
<ul>
  <li>Crear una función "escribirGuiones" que escriba en pantalla tantos guiones ("-") como se indique como parámetro y no devuelva ningún valor.</li>
  <li>Crear una función "dibujarRectangulo", que reciba como parámetros la anchura y la altura del rectángulo a mostrar, y muestre en pantalla un rectángulo de ese tamaño, relleno de caracteres "#". Por ejemplo, para anchura 4 y altura 2 sería:</li>
</ul>
<p>####<br />
####</p>
<ul>
  <li>Crear una funci&oacute;n "borrarPantalla" que borre la pantalla dibujando 25 l&iacute;neas en blanco. No debe devolver ning&uacute;n valor. </li>
  <li>Crear una funci&oacute;n "mostrarPerimSuperf" que reciba un n&uacute;mero y muestre en pantalla el per&iacute;metro y la superficie de un cuadrado que tenga como lado el n&uacute;mero que se ha indicado como par&aacute;metro. </li>
  <li>Crear una función "escribirCentrado" que reciba un texto y lo escriba centrado en la siguiente línea de pantalla (suponiendo 80 columnas en pantalla). Por ejemplo, si el texto es "Hola", que tiene 4 letras, se escribirán 38 espacios antes de él.</li>
</ul>
<p>&nbsp;</p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   13393 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc07d.php">Anterior</a></li>
                    <li><a href="cc07f.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        