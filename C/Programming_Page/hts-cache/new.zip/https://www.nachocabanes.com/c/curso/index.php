<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Contenido / indice</title>

    
    <meta name="description" content="Tutorial de C - Contenido / indice - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="C,fundamentos de programacion,fp,curso,tutorial" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Contenido / indice          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="index.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc00.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        <h2>Fundamentos de programaci&oacute;n en C</h2>

<p><br />
  Este texto pretende ser una introducci&oacute;n a la programaci&oacute;n de ordenadores en lenguaje C.</p>
<p>Se ha revisado con la intenci&oacute;n que su nivel sea el razonable para una asignatura de &ldquo;Fundamentos de programaci&oacute;n&rdquo; o similar, aunque quiz&aacute; algunos centros (especialmente universitarios) exijan un nivel m&aacute;s alto que el que se cubre.</p>
<p>Est&aacute; organizado de una forma ligeramente distinta a los libros de texto &ldquo;convencionales&rdquo;, procurando incluir ejercicios pr&aacute;cticos lo antes posible, para evitar que un exceso de teor&iacute;a en los primeros temas haga el texto pesado de seguir.</p>
<p>Aun as&iacute;, este texto no pretende &ldquo;sustituir a un profesor&rdquo;, sino servir de apoyo para que los alumnos no pierdan tiempo en tomar apuntes. Pero es trabajo del profesor aclarar las dudas que surjan y proponer muchos m&aacute;s ejercicios que los que figuran aqu&iacute;. <br />
</p>

<p>Este texto ha sido escrito por Nacho Cabanes. Si quiere conseguir la &uacute;ltima versi&oacute;n, estar&aacute; en mi p&aacute;gina web:</p>
<p align="center"><a href="http://www.nachocabanes.com">www.nachocabanes.com</a><br />
</p>

<p>La &uacute;ltima versi&oacute;n de este curso, tanto para consultar en l&iacute;nea como en formato PDF, se podr&aacute; encontrar en el apartado sobre Lenguaje C:</p>
<p align="center"><a href="http://www.nachocabanes.com/c/#cursos">www.nachocabanes.com/c</a><br />
</p>

<p>Este texto es de libre distribuci&oacute;n (&ldquo;gratis&rdquo;). Se puede distribuir a otras personas libremente, siempre y cuando no se modifique.</p>
<p>Este texto se distribuye &quot;tal cual&quot;, sin garant&iacute;a de ning&uacute;n tipo, impl&iacute;cita ni expl&iacute;cita. Aun as&iacute;, mi intenci&oacute;n es que resulte &uacute;til, as&iacute; que le rogar&iacute;a que me comunique cualquier error que encuentre.</p>
<p>Para cualquier sugerencia, no dude en contactar conmigo a trav&eacute;s de mi web.<br />
</p>
<p>&nbsp;</p>
<h3>Contenido</h3>
<ul>
  <li><a href="cc00.php"> 0. Conceptos básicos sobre programación</a>
    <ul>
      <li> 0.1. Lenguajes de alto nivel y de bajo nivel</li>
      <li> 0.2. Ensambladores, compiladores e int&eacute;rpretes</li>
      <li> 0.3. Pseudoc&oacute;digo</li>
    </ul>
  </li>
  <li><a href="cc01.php">1. Toma de contacto con C </a>
    <ul>
      <li>1.1 Escribir un texto en C</li>
      <li>1.1.1. C&oacute;mo probar este programa en Linux</li>
      <li>1.1.2. C&oacute;mo probar este programa en Windows</li>
      <li>1.2. Mostrar n&uacute;meros enteros en pantalla</li>
      <li>1.3. Operaciones aritm&eacute;ticas b&aacute;sicas</li>
      <li>1.3.1. Orden de prioridad de los operadores</li>
      <li>1.3.2. Introducci&oacute;n a los problemas de desbordamiento</li>
      <li>1.4. Introducci&oacute;n a las variables: int</li>
      <li>1.4.1. Definici&oacute;n de variables: n&uacute;meros enteros</li>
      <li>1.4.2. Asignaci&oacute;n de valores</li>
      <li>1.4.3. Mostrar el valor de una variable en pantalla</li>
      <li>1.5. Identificadores</li>
      <li>1.6. Comentarios</li>
      <li>1.7. Datos por el usuario: scanf</li>
      </ul>
  </li>
  <li><a href="cc02.php">2. Tipos de datos básicos </a>
    <ul>
    <li>2.1. Tipo de datos entero</li>
    <li>2.1.1. Tipos de enteros: signed/unsigned, short/long</li>
    <li>2.1.2. Problem&aacute;tica: asignaciones y tama&ntilde;o de los n&uacute;meros; distintos espacios ocupados seg&uacute;n el sistema</li>
    <li>2.1.3. Unidades de medida empleadas en inform&aacute;tica (1): bytes, kilobytes, megabytes...</li>
    <li>2.1.4. Unidades de medida empleadas en inform&aacute;tica (2): los bits</li>
    <li>2.1.5. Sistemas de numeraci&oacute;n: 1- Sistema binario</li>
    <li>2.1.6. Sistemas de numeraci&oacute;n: 2- Sistema octal</li>
    <li>2.1.7. Sistemas de numeraci&oacute;n: 3- Sistema hexadecimal</li>
    <li>2.1.8. Formato de constantes enteras: oct, hex</li>
    <li>2.1.9. Representaci&oacute;n interna de los enteros</li>
    <li>2.1.10. Incremento y decremento</li>
    <li>2.1.11. Operaciones abreviadas: +=</li>
    <li>2.1.12. Modificadores de acceso: const, volatile</li>
    <li>2.2. Tipo de datos real</li>
    <li>2.2.1. Simple y doble precisi&oacute;n</li>
    <li>2.2.2. Mostrar en pantalla n&uacute;meros reales</li>
    <li>2.3. Operador de tama&ntilde;o: sizeof</li>
    <li>2.4. Operador de molde: (tipo) operando</li>
    <li>2.5. Tipo de datos car&aacute;cter</li>
    <li>2.5.1. Secuencias de escape: \n y otras.</li>
    <li>2.5.2. Introducci&oacute;n a las dificultades de las cadenas de texto</li>
    </ul>
  </li>
  
<li><a href="cc03.php">3. Estructuras de control</a>
    <ul>
      <li> 3.1. Estructuras alternativas</li>
      <li> 3.1.1. if</li>
      <li> 3.1.2. if y sentencias compuestas</li>
      <li> 3.1.3. Operadores relacionales: &lt;, &lt;=, &gt;, &gt;=, ==, !=</li>
      <li> 3.1.4. if-else </li>
      <li> 3.1.5. Operadores l&oacute;gicos: &amp;&amp;, ||, !</li>
      <li> 3.1.6. C&oacute;mo funciona realmente la condici&oacute;n en un &ldquo;if&rdquo;</li>
      <li> 3.1.7. El peligro de la asignaci&oacute;n en un &ldquo;if&rdquo;</li>
      <li> 3.1.8. Introducci&oacute;n a los diagramas de flujo</li>
      <li> 3.1.9. Operador condicional: ?</li>
      <li> 3.1.10. switch</li>
      <li> 3.2. Estructuras repetitivas</li>
      <li> 3.2.1. while</li>
      <li> 3.2.2. do ... while</li>
      <li> 3.2.3. for</li>
      <li> 3.3. Sentencia break: termina el bucle</li>
      <li> 3.4. Sentencia continue: fuerza la siguiente iteraci&oacute;n</li>
      <li> 3.5. Sentencia goto</li>
      <li> 3.6. M&aacute;s sobre diagramas de flujo. Diagramas de Chapin.</li>
      <li> 3.7. Recomendaci&oacute;n de uso de los distintos tipos de bucle</li>
    </ul>
  </li>
  <li><a href="cc04.php">4. Entrada/salida b&aacute;sica</a>
    <ul>
      <li> 4.1. printf</li>
      <li> 4.2. scanf</li>
      <li> 4.3. putchar</li>
      <li> 4.4. getchar</li>
    </ul>
  </li>
   
    <li><a href="cc05.php">5. Arrays y estructuras</a>
    <ul>
      <li>5.1. Conceptos b&aacute;sicos sobre tablas</li>
      <li>5.1.1. Definici&oacute;n de una tabla y acceso a los datos</li>
      <li>5.1.2. Valor inicial de una tabla</li>
      <li>5.1.3. Recorriendo los elementos de una tabla</li>
      <li>5.2. Cadenas de caracteres</li>
      <li>5.2.1. Definici&oacute;n. Lectura desde teclado</li>
      <li>5.2.2. C&oacute;mo acceder a las letras que forman una cadena</li>
      <li>5.2.3. Longitud de la cadena.</li>
      <li>5.2.4. Entrada/salida para cadenas: gets, puts</li>
      <li>5.2.5. Asignando a una cadena el valor de otra: strcpy, strncpy; strcat</li>
      <li>5.2.6. Comparando cadenas: strcmp</li>
      <li>5.2.7. Otras funciones de cadenas: sprintf, sscanf</li>
      <li>5.2.8. Valor inicial de una cadena de texto</li>
      <li>5.3. Tablas bidimensionales</li>
      <li>5.4. Arrays indeterminados.</li>
      <li>5.5. Estructuras</li>
      <li>5.5.1. Definici&oacute;n y acceso a los datos</li>
      <li>5.5.2. Arrays de estructuras</li>
      <li>5.5.3. Estructuras anidadas</li>
      <li>5.6 Ejemplo completo</li>
    </ul>
    </li>
    
    <li>
      <a href="cc06.php">6. Manejo de ficheros</a>
      <ul>
        <li>6.1. Escritura en un fichero de texto</li>
        <li>6.2. Lectura de un fichero de texto</li>
        <li>6.3. Lectura hasta el final del fichero</li>
        <li>6.4. Ficheros con tipo</li>
        <li>6.5 Leer y escribir letra a letra</li>
        <li>6.6 Modos de apertura</li>
        <li>6.7 Ficheros binarios</li>
        <li>6.8 Ejemplo: copiador de ficheros</li>
        <li>6.9 Acceder a cualquier posici&oacute;n de un fichero</li>
        <li>6.10 Ejemplo: leer informaci&oacute;n de un fichero BMP</li>
        <li>6.11. Ficheros especiales 1: la impresora</li>
        <li>6.12. Ficheros especiales 2: salida de errores</li>
        <li>6.13. Un ejemplo de lectura y escritura: TAG de un MP3</li>
    </ul>
   </li>
    
   <li>
      <a href="cc07.php">7. Introducci&oacute;n a las funciones</a>
      <ul>
        <li>7.1. Dise&ntilde;o modular de programas: Descomposici&oacute;n modular</li>
        <li>7.2. Conceptos b&aacute;sicos sobre funciones</li>
        <li>7.3. Par&aacute;metros de una funci&oacute;n</li>
        <li>7.4. Valor devuelto por una funci&oacute;n</li>
        <li>7.5. El valor de retorno &ldquo;void&rdquo;. El valor de retorno de &ldquo;main&rdquo;</li>
        <li>7.6. Variables locales y variables globales</li>
        <li>7.7. Los conflictos de nombres en las variables</li>
        <li>7.8. El orden importa</li>
        <li>7.9. Algunas funciones &uacute;tiles</li>
        <li>7.9.1. N&uacute;meros aleatorios</li>
        <li>7.9.2. Funciones matem&aacute;ticas</li>
        <li>7.9.3. Pero casi todo son funciones&hellip;</li>
        <li>7.10. Recursividad</li>
        <li>7.11. C&oacute;mo interrumpir el programa.</li>
    </ul>
  </li>
    
    <li>
      <a href="cc08.php">8. C&oacute;mo depurar los programas</a>
      <ul>
        <li>8.1. Conceptos b&aacute;sicos sobre depuraci&oacute;n</li>
        <li>8.2. Ejemplos de algunos entornos</li>
      </ul>
    </li>
      
    <li>
      <a href="cc09.php">9. Punteros y gesti&oacute;n din&aacute;mica de memoria</a>
      <ul>
        <li>9.1. &iquest;Por qu&eacute; usar estructuras din&aacute;micas?</li>
        <li>9.2. &iquest;Qu&eacute; son los punteros?</li>
        <li>9.3. Repasemos con un ejemplo sencillo</li>
        <li>9.4. Aritm&eacute;tica de punteros</li>
        <li>9.5. Punteros y funciones: par&aacute;metros por referencia</li>
        <li>9.6. Punteros y arrays</li>
        <li>9.7. Arrays de punteros</li>
        <li>9.8. Punteros y estructuras</li>
        <li>9.9. Par&aacute;metros de &ldquo;main&rdquo;</li>
        <li>9.10. Estructuras din&aacute;micas habituales 1: las listas enlazadas</li>
        <li>9.11. Estructuras din&aacute;micas habituales 2: los &aacute;rboles binarios</li>
        <li>9.12. Indirecci&oacute;n m&uacute;ltiple</li>
        <li>9.13. Un ejemplo: copiador de ficheros en una pasada</li>
      </ul>
    </li>
      
    <li>
      <a href="cc10.php">10. Bibliotecas de uso frecuente</a>
      <ul>
        <li>10.1. Llamadas al sistema: system</li>
        <li>10.2. Temporizaci&oacute;n</li>
        <li>10.3. Pantalla y teclado con Turbo C</li>
        <li>10.4. Acceso a pantalla en Linux: curses.h</li>
        <li>10.5. <a href="cc10b.php">Juegos multiplataforma: SDL</a></li>
      </ul>
    </li>
      
    <li>
      <a href="cc11.php">11. Otras caracter&iacute;sticas avanzadas de C</a>
      <ul>
        <li>11.1 Operaciones con bits</li>
        <li>11.2 Directivas del preprocesador</li>
        <li>11.2.1. Constantes simb&oacute;licas: #define</li>
        <li>11.2.2 Inclusi&oacute;n de ficheros: #include</li>
        <li>11.2.3. Compilaci&oacute;n condicional: #ifdef, #endif</li>
        <li>11.2.4. Otras directivas</li>
        <li>11.3. Programas a partir de varios fuentes</li>
        <li>11.3.1. Creaci&oacute;n desde la l&iacute;nea de comandos</li>
        <li>11.3.2. Introducci&oacute;n al uso de la herramienta Make</li>
        <li>11.3.3. Introducci&oacute;n a los &ldquo;proyectos&rdquo;</li>
        <li>11.4 Uniones y campos de bits</li>
        <li>11.5. El operador coma</li>
        <li>11.6. Enumeraciones</li>
        <li>11.7. Definici&oacute;n de tipos</li>
      </ul>
    </li>
</ul>

<ul>
  <li><a href="c_cambios.php">Cambios entre entregas</a></li>
</ul>


<p></p>
<p>&nbsp;</p>
<p><a href="c_soluciones.php">Soluciones a los ejercicios propuestos</a></p>

           </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   </p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="index.php">Anterior</a></li>
                    <li><a href="cc00.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        