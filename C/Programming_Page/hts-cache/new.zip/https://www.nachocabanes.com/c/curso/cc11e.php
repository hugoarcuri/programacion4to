<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 11 - Caracteristicas avanzadas</title>

    
    <meta name="description" content="Curso de C - Tema 11 - Caracteristicas avanzadas - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="or,and,not,desplazamiento,directiva,preprocesador,makefile,coma" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 11 - Caracteristicas avanzadas          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc11d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc11f.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>11.5. El operador coma</h3>
<p>Cuando vimos la orden &ldquo;for&rdquo;, siempre us&aacute;bamos una &uacute;nica variable como contador, pero esto no tiene por qu&eacute; ser siempre as&iacute;. Vamos a verlo con un ejemplo:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 100:     */
/*  c100.c                   */
/*                           */
/*  Operador coma (1)        */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/
 
#include <stdio.h>

int main(){
  int i, j;
  
  for (i=0,j=1; i<=5, j<=30; i++, j+=2)
    printf("i vale %d y j vale %d.\n", i, j);

  return 0;    
}
</code></pre></p>

<p>Vamos a ver qu&eacute; hace este &quot;for&quot;:<br />
    <br />
    * Los valores iniciales son i=0, j=1.<br />
    * Se repetir&aacute; mientras que i &lt;= 5, j &lt;= 30.<br />
    * Al final de cada paso, i aumenta en una unidad, y j en dos unidades.</p>
<p>El &uacute;nico problema est&aacute; en saber c&uacute;ando terminar&aacute; el bucle: si se parar&aacute; en cuanto se cumpla una de las dos condiciones o si tendr&aacute;n que cumplirse las dos.</p>
<p>El resultado de este programa servir&aacute; como respuesta:<br />
</p>
<p> i vale 0 y j vale 1.<br />
  i vale 1 y j vale 3.<br />
  i vale 2 y j vale 5.<br />
  i vale 3 y j vale 7.<br />
  i vale 4 y j vale 9.<br />
  i vale 5 y j vale 11.<br />
  i vale 6 y j vale 13.<br />
  i vale 7 y j vale 15.<br />
  i vale 8 y j vale 17.<br />
  i vale 9 y j vale 19.<br />
  i vale 10 y j vale 21.<br />
  i vale 11 y j vale 23.<br />
  i vale 12 y j vale 25.<br />
  i vale 13 y j vale 27.<br />
  i vale 14 y j vale 29.</p>
<p>Como podemos observar, llega un momento en que deja de cumplise que i&lt;=5, pero el programa sigue avanzando: no se sale del bucle &ldquo;for&rdquo; hasta que se cumplen las dos condiciones (realmente, hasta que se cumple la segunda).</p>
<p>La idea es que, en general, si se usa el operador coma para separar dos expresiones, nuestro compilador eval&uacute;a la primera expresi&oacute;n, luego la segunda, y devuelve como valor el resultado de la segunda. Ve&aacute;moslo con un segundo ejemplo algo m&aacute;s rebuscado</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 101:     */
/*  c101.c                   */
/*                           */
/*  Operador coma (2)        */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/
 
#include <stdio.h>
 
int main(){    
  int i, j, k;
  k = ((i=5), (j=6));

  printf("i=%d, j=%d, k=%d", i, j, k);

  return 0;  
}
</code></pre></p>
<p>Aun as&iacute;, en la pr&aacute;ctica, el &uacute;nico uso habitual del operador coma es el primero que hemos visto: utilizar dos condiciones simult&aacute;neas para controlar un bucle &ldquo;for&rdquo;.</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   8215 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc11d.php">Anterior</a></li>
                    <li><a href="cc11f.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        
