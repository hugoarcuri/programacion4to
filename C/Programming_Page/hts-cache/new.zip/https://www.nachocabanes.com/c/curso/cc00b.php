<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 0 - Conceptos basicos</title>

    
    <meta name="description" content="Tutorial de C - Tema 1 - Toma de contacto con C - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="interprete,compilador,ensamblador" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 0 - Conceptos basicos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc00a.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc00c.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h3>0.2. Ensambladores, compiladores e int&eacute;rpretes</h3>

<p>Como hemos visto, las órdenes que nosotros escribimos (lo que se conoce 
como "programa <b>fuente</b>") deben convertirse a lo que el ordenador 
comprende (obteniendo el "programa <b>ejecutable</b>").</p>

<p>Si elegimos un lenguaje de bajo nivel, como el ensamblador (en ingl&eacute;s
Assembly, abreviado habitualmente como Asm), la traducci&oacute;n es sencilla, y 
de hacer esa traducci&oacute;n se encargan unas herramientas llamadas <b>
ensambladores</b> (en ingl&eacute;s <em>Assembler</em>).</p>

<p>Cuando el lenguaje que hemos empleado es de alto nivel, la traducci&oacute;n
es m&aacute;s complicada, y a veces implicar&aacute; tambi&eacute;n
recopilar varios fuentes distintos o incluir otras posibilidades que se 
encuentran en bibliotecas adicionales, que no hemos preparado nosotros. Las 
herramientas encargadas de todo esto son los <b>compiladores</b>.</p>

<p>El programa ejecutable obtenido con un compilador o un ensamblador se podr&iacute;a
hacer funcionar en otro ordenador similar al que hab&iacute;amos 
utilizado para crearlo, sin necesidad de que ese otro ordenador tenga 
instalado el compilador o el ensamblador.</p>

<p>Por ejemplo, en el caso de Windows (y de MsDos), y del programa que nos 
saluda en lenguaje Pascal, tendr&iacute;amos un fichero fuente llamado 
SALUDO.PAS. Este fichero no servir&iacute;a de nada en un ordenador que no 
tuviera un compilador de Pascal. En cambio, despu&eacute;s de compilarlo 
obtendr&iacute;amos un fichero SALUDO.EXE, capaz de funcionar en cualquier 
otro ordenador que tuviera el mismo sistema operativo, aunque no tenga un 
compilador de Pascal instalado.</p>

<p>Un <b>int&eacute;rprete</b> es una herramienta parecida a un compilador, 
con la diferencia de que en los int&eacute;rpretes no se crea ning&uacute;n 
"programa ejecutable" capaz de funcionar "por s&iacute; solo", de modo que 
si queremos distribuir nuestro programa a alguien, deberemos entregarle el 
programa fuente y deberá tener tambi&eacute;n el int&eacute;rprete que es capaz de 
entenderlo, o no le servir&aacute; de nada. Cuando ponemos el programa en 
funcionamiento, el int&eacute;rprete de encarga de convertir el programa en 
lenguaje de alto nivel a c&oacute;digo m&aacute;quina, orden por orden, 
justo en el momento en que hay que procesar cada una de las &oacute;rdenes. 
</p>

<p>Para algunos lenguajes, es frecuente encontrar compiladores pero no suele 
existir int&eacute;rpretes. Es el caso del lenguaje C, de Pascal y de C++, 
por ejemplo. En cambio, para otros lenguajes, lo habitual es trabajar con int&eacute;rpretes
y no con compiladores, como ocurre con Python, Ruby y PHP. 
</p>

<p>Adem&aacute;s, hoy en d&iacute;a existe algo que parece intermedio entre 
un compilador y un int&eacute;rprete: Existen lenguajes que no se compilan 
para obtener un ejecutable para un ordenador concreto, sino un ejecutable 
"gen&eacute;rico", que es capaz de funcionar en distintos tipos de 
ordenadores, a condici&oacute;n de que en ese ordenador exista una "m&aacute;quina virtual" capaz de entender esos ejecutables gen&eacute;ricos. Esta es 
la idea que se aplica en Java: los fuentes son ficheros de texto, con extensi&oacute;n
".java", que se compilan a ficheros ".class". Estos ficheros 
".class" se podr&iacute;an llevar a cualquier ordenador que tenga instalada 
una "<b>m&aacute;quina virtual</b> Java" (las hay para la mayor&iacute;a de 
sistemas operativos). Esta misma idea se sigue en el lenguaje C#, que se 
apoya en una m&aacute;quina virtual llamada "Dot Net Framework" (algo as&iacute;
como "plataforma punto net").</p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   23574 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc00a.php">Anterior</a></li>
                    <li><a href="cc00c.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        