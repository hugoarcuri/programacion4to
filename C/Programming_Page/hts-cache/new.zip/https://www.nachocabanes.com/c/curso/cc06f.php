<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 6 - Ficheros</title>

    
    <meta name="description" content="Curso de C - Tema 6 - Ficheros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="aleatorio,fichero,texto,fopen,fclose,eof,feof,fgets,fprintf,fscanf,fread,fwrite" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 6 - Ficheros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc06e.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc06g.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>6.6 Modos de apertura</h3>
<p>Antes de seguir, vamos a ver las letras que pueden aparecer en el<strong> modo de apertura</strong> del fichero, para poder a&ntilde;adir datos a un fichero ya existente:</p>
<table cellspacing="0" cellpadding="0">
  <tr>
    <td width="77" valign="top"><p>Tipo </p></td>
    <td width="584" valign="top"><p>Significado </p></td>
  </tr>
  <tr>
    <td width="77" valign="top"><p>r </p></td>
    <td width="584" valign="top"><p>Abrir s&oacute;lo para lectura. </p></td>
  </tr>
  <tr>
    <td width="77" valign="top"><p>w </p></td>
    <td width="584" valign="top"><p>Crear para escribir. Sobreescribe el fichero si existiera ya (borrando el original). </p></td>
  </tr>
  <tr>
    <td width="77" valign="top"><p>a </p></td>
    <td width="584" valign="top"><p>A&ntilde;ade al final del fichero si existe, o lo crea si no existe. </p></td>
  </tr>
  <tr>
    <td width="77" valign="top"><p>+ </p></td>
    <td width="584" valign="top"><p>Se escribe a continuaci&oacute;n de los modos anteriores para indicar que tambi&eacute;n queremos modificar. Por ejemplo: r+ permite leer y modificar el fichero </p></td>
  </tr>
  <tr>
    <td width="77" valign="top"><p>t </p></td>
    <td width="584" valign="top"><p>Abrir en modo de texto. </p></td>
  </tr>
  <tr>
    <td width="77" valign="top"><p>b </p></td>
    <td width="584" valign="top"><p>Abrir en modo binario. </p></td>
  </tr>
</table>
<p><strong>&nbsp; </strong></p>
<p><strong>Ejercicios propuestos: </strong></p>
<ul>
  <li> Un programa que pida al usuario que teclee frases, y las almacene en el fichero &quot;registro.txt&quot;, que puede existir anteriormente (y que no deber&aacute; borrarse, sino a&ntilde;adir al final de su contenido). Cada sesi&oacute;n acabar&aacute; cuando el usuario pulse Intro sin teclear nada. </li>
  <li> Crear un programa que pida al usuario pares de n&uacute;meros enteros y escriba su suma (con el formato &quot;20 + 3 = 23&quot;) en pantalla y en un fichero llamado &quot;sumas.txt&quot;, que se encontrar&aacute; en un subdirectorio llamado &quot;resultados&quot;. Cada vez que se ejecute el programa, deber&aacute; a&ntilde;adir los nuevos resultados a continuaci&oacute;n de los resultados de las ejecuciones anteriores. <strong></strong></li>
</ul>
<p>&nbsp; </p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   22513 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc06e.php">Anterior</a></li>
                    <li><a href="cc06g.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        