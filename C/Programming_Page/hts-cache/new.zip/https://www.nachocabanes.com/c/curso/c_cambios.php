<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Cambios</title>

    
    <meta name="description" content="Tutorial de C - Cambios - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="C,main,compilar,enlazar,printf" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Cambios          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="index.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="index.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        <h2>Revisiones de este texto hasta la fecha:</h2>

<ul>
<li>0.90 pre7, de 06-Ene-10. A&ntilde;adidos m&aacute;s ejercicios en 6.4 (2), 6.8 (2), 6.10 (3), 7.4 (3), 7.5 (1), 7.6 (6), 7.10 (6).<br />
</li><li>0.90 pre6, de 20-Dic-09. A&ntilde;adidos m&aacute;s ejercicios en 6.1 (1), 6.2 (1), 6.6 (2), 6.10 (1).<br />
</li><li>0.90 pre5, de 16-Dic-09. A&ntilde;adidos m&aacute;s ejercicios en 5.1.1 (2), 5.1.2 (1), 5.1.4 (2), 5.2.3 (2), 5.2.4 (1), 5.2.5 (1), 5.2.6 (2), 5.3 (2), 5.5.1 (1), 5.5.2 (1), 5.5.3 (1), 5.6 (5), 5.7 (1).<br />
</li><li>0.90 pre4, de 12-Dic-09. Ampliado el contenido del apartado 4.4. A&ntilde;adidos m&aacute;s ejercicios en 3.1.3 (1), 3.1.4 (2), 3.1.5 (2), 3.1.8 (1), 3.1.9 (2), 3.1.10 (2), 3.2.1 (2), 3.2.3 (3), 3.7 (2), 4.1 (2), 4.2 (3), 4.3 (1), 4.4 (1).<br />
</li><li>0.90 pre3, de 07-Dic-09. Corregido un error en 11.1. Ligera revisi&oacute;n de aspecto en la versi&oacute;n web: mayor cantidad de textos en negrita en los temas 6 a 11 (imitando la apariencia de la versi&oacute;n PDF), una imagen nueva en el apartado 10 (ejemplo de conio.h), lista de secuencias de escape y de modos de apertura de fichero reescritas como tablas, alg&uacute;n apartado ligeramente reescrito.<br />
</li><li>0.90 pre2, de 05-Dic-09. Ligeramente reescrito alg&uacute;n p&aacute;rrafo del tema 2, a&ntilde;adido un p&aacute;rrafo en 2.1.12, reescrito un p&aacute;rrafo en 4.1.<br />
</li><li>0.90 pre1, de 29-Nov-09. Ligeramente ampliados los apartados 0.2, 1.1. Alg&uacute;n p&aacute;rrafo reescrito (el primero de 1.2). Incluidos ejemplos de posibles soluciones a los ejercicios propuestos en 1.2, 1.3.1, 1.4.3, 1.7.1 (3)<br />
</li><li>0.23, de 11-Ene-07. M&aacute;s detallado el apartado 5.2.7 y el 7.8. A&ntilde;adido un ejemplo m&aacute;s a 7.3. Revisados muchos fuentes para usar variables locales, en vez de globales, siempre que fuera posible. En el tema 5.6 hab&iacute;a dos ejemplos de agenda muy parecidos, eliminado uno de ellos. (174 p&aacute;ginas).<br />
</li><li>0.22, de 31-Oct-06. A&ntilde;adidos al tema 3 varios ejercicios resueltos (14), relacionados con fallos frecuentes de los alumnos. Ligera revisi&oacute;n ortogr&aacute;fica. (175 p&aacute;ginas).<br />
</li><li>0.21, de 07-Jul-06. Incluye hasta el apartado 11.7 (172 p&aacute;ginas).<br />
</li><li>0.20, de 09-Jun-06. Incluye hasta el apartado 11.5 (169 p&aacute;ginas).<br />
</li><li>0.19, de 08-May-06. Incluye hasta el apartado 11.3.2 (160 p&aacute;ginas).<br />
</li><li>0.18, de 27-Abr-06. Incluye hasta el apartado 11.2.3 (152 p&aacute;ginas).<br />
</li><li>0.17, de 04-Abr-06. Completado el tema de &ldquo;punteros y memoria din&aacute;mica&rdquo; (tema 9) y el de &ldquo;bibliotecas &uacute;tiles&rdquo; (tema 10) (145 p&aacute;ginas).<br />
</li><li>0.16, de 21-Mar-06. Ampliado el tema de &ldquo;punteros y memoria din&aacute;mica&rdquo;, hasta el apartado 9.10 (132 p&aacute;ginas).<br />
</li><li>0.15, de 19-Mar-06. A&ntilde;adido un tema sobre depuraci&oacute;n (nuevo tema 8, el tema de &ldquo;punteros&rdquo; pasa a ser el tema 9). Ampliado el tema de &ldquo;punteros y memoria din&aacute;mica&rdquo; con un ejemplo b&aacute;sico, informaci&oacute;n sobre par&aacute;metros por valor y por referencia, aritm&eacute;tica de punteros y la equivalencia entre punteros y arrays. Ampliado el apartado de &ldquo;funciones&rdquo; para hablar de el orden de las funciones (tema 7.8, renumerados los posteriores) (123 p&aacute;ginas).<br />
</li><li>0.14, de 16-Feb-06. Ampliado el apartado de &ldquo;funciones&rdquo; para hablar de n&uacute;meros aleatorios y de funciones matem&aacute;ticas. Ampliado el apartado de &ldquo;punteros y memoria din&aacute;mica&rdquo; con un primer ejemplo de su uso (114 p&aacute;ginas).<br />
</li><li>0.13, de 05-Feb-06. Ampliado el apartado de &ldquo;funciones&rdquo; y comenzado el apartado de &ldquo;punteros y memoria din&aacute;mica&rdquo;. A&ntilde;adido el apartado 6.13, con un ejemplo de lectura y escritura en un fichero. A&ntilde;adidos ejercicios en los apartados 2.1.3, 2.1.7, 2.1.10, 2.2, 2.3, 3.1.5, 3.2.3... Corregida una errata en el formato de &ldquo;fread&rdquo; y &ldquo;fwrite&rdquo;. (108 p&aacute;ginas, cambia la numeraci&oacute;n a partir de la p&aacute;gina 27 por la inclusi&oacute;n de esos ejercicios b&aacute;sicos).<br />
</li><li>0.12, de 25-Ene-06. Completado el cap&iacute;tulo de &ldquo;ficheros&rdquo; y comenzado el de &ldquo;funciones&rdquo; (hasta el apartado 7.6, 100 p&aacute;ginas).<br />
</li><li>0.11, de 11-Ene-06. A&ntilde;adido un ejemplo de &ldquo;array&rdquo; para almacenar muchos registros. M&aacute;s ejemplos sobre ficheros: c&oacute;mo mostrar datos de una imagen BMP (89 p&aacute;ginas, cambia la numeraci&oacute;n a partir de la p&aacute;gina 79 por incluir el ejemplo de registros).<br />
</li><li>0.10, de 12-Dic-05. M&aacute;s informaci&oacute;n sobre ficheros: binarios, lectura y escritura, acceso directo... (86 p&aacute;ginas).<br />
</li><li>0.09, de 30-Nov-05. A&ntilde;adida informaci&oacute;n sobre &ldquo;structs&rdquo; y sobre lectura y escritura de ficheros de texto (tema 6.2). Corregidos alguno de los formatos de &ldquo;scanf&rdquo;, que el procesador de textos hab&iacute;a convertido a may&uacute;sculas incorrectamente (82 p&aacute;ginas).<br />
</li><li>0.08, de 14-Nov-05. Incluye hasta el tema 5.4 (76 p&aacute;ginas).<br />
</li><li>0.07, de 30-Oct-05. Incluye hasta el tema 5.2.4 (70 p&aacute;ginas).<br />
</li><li>0.06, de 23-Oct-05. Incluye todo el tema 3 (60 p&aacute;ginas).<br />
</li><li>0.05, de 10-Oct-05. Incluye hasta el tema 3.3 (56 p&aacute;ginas).<br />
</li><li>0.04, de 04-Oct-05. Incluye hasta el tema 3.1 (49 p&aacute;ginas).<br />
</li><li>0.03, de 30-Sept-05. Incluye hasta el tema 2 (42 p&aacute;ginas).<br />
</li><li>0.02, de 21-Sept-05. Incluye el tema 0 y el tema 1.<br />
</li><li>0.01, de 18-Sept-05, como texto de apoyo para los alumnos de Fundamentos de Programaci&oacute;n en el I.E.S. San Vicente. Incluye el tema 0.</p>
</li>
</ul>
           </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   4760 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="index.php">Anterior</a></li>
                    <li><a href="index.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        