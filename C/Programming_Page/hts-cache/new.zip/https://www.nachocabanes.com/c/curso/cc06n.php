<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 6 - Ficheros</title>

    
    <meta name="description" content="Curso de C - Tema 6 - Ficheros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="aleatorio,fichero,texto,fopen,fclose,eof,feof,fgets,fprintf,fscanf,fread,fwrite" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 6 - Ficheros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc06m.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc07.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>6.14. Evitar los problemas de "gets"</h3>

<p>Como comentamos en el tema 5, el uso de "gets" está desaconsejado a partir del estándar C99 (de 1999), por tratarse de una orden poco segura, pero esta orden ni siquiera existirá en los compiladores que sigan el estándar C11 (de diciembre de 2011). Una alternativa, en compiladores modernos, es usar "get_s" que recibe como segundo parámetro el tamaño máximo del texto. Otra alternativa, más segura que gets, que permite que la cadena contenga espacios, y que funcionará en cualquier compilador de C, es usar "fgets".</p>

<p>"fgets" espera 3 parámetros: la variable en la que se guardará el texto, la anchura máxima y el fichero desde el que leer. El "truco" para usar "fgets" para leer de teclado es indicar "stdin" (standard in, entrada estándar) como nombre que fichero, que es un identificador predefinido en el sistema:</p>

<p><pre><code class='language-c'>fgets(nombre, 20, stdin);</code></pre></p>
<p>Eso sí, "fgets" tiene un problema para este uso: conserva el avance de línea (\n). Por eso, habrá que eliminarlo "a mano" (si la cadena no está vacía y si realmente termina en avance de línea, porque puede no ser así si la cadena era más larga que lo esperado y se ha truncado):</p>

<p><pre><code class='language-c'>if ((strlen(nombre)>0) && (nombre[strlen (nombre) - 1] == '\n'))
        nombre[strlen (nombre) - 1] = '\0';</code></pre></p>
<p>Con esas dos órdenes podriamos evitar los problemas de "gets" de una forma que se comporte bien en cualquier compilador, usando "fgets" para leer de teclado como si fuera un fichero.</p>

<p>No es la única forma: hay autores que prefieren no usar ficheros sino un formato avanzado de "scanf", en el que se le indica que acepte todo hasta llegar a un avance de línea, pero esto puede no ser admitido por todos los compiladores:</p>

<p><pre><code class='language-c'>scanf("%[^\n]s",nombre);</code></pre></p>
<p>Para evitar problemas de desbordamiento, deberíamos indicar la anchura máxima:</p>

<p><pre><code class='language-c'>scanf("%20[^\n]",nombre);</code></pre></p>
<p>También podemos delimitar los caracteres admisibles (nuevamente, quizá no todos los compiladores lo permitan):</p>

<p><pre><code class='language-c'>scanf("%10[0-9a-zA-Z ]s", nombre);</code></pre></p>
<p>Muchos expertos recomiendan no usar directamente "gets" ni "scanf", ni siquiera para leer datos numéricos, sino hacer la lectura en una cadena de texto con "fgets" y luego extraer la información de ella con "sscanf".</p>


<p><strong>Ejercicio propuesto: </strong></p>
<ul>
  <li>Pedir al usuario dos números y la operación (suma o resta) a realizar con ellos, y mostrar el resultado de dicha operación. Utilizar "fgets" y "sscanf" para la lectura de teclado.</li>
</ul>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   21936 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc06m.php">Anterior</a></li>
                    <li><a href="cc07.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        