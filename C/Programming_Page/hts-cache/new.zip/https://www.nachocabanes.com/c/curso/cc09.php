<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 9 - Punteros</title>

    
    <meta name="description" content="Curso de C - Tema 9 - Punteros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="punteros,malloc,free,argc,argv,pointer,null" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 9 - Punteros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc08b.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc09b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        <h2>9. Punteros y gesti&oacute;n din&aacute;mica de memoria</h2>

<h3>    9.1. &iquest;Por qu&eacute; usar estructuras din&aacute;micas?</h3>
<p>Hasta ahora ten&iacute;amos una serie de variables que declaramos al principio del programa o de cada funci&oacute;n. Estas variables, que reciben el nombre de <strong>EST&Aacute;TICAS</strong>, tienen un tama&ntilde;o asignado desde el momento en que se crea el programa.</p>
<p>Este tipo de variables son sencillas de usar y r&aacute;pidas... si s&oacute;lo vamos a manejar estructuras de datos que no cambien, pero resultan poco eficientes si tenemos estructuras cuyo tama&ntilde;o no sea siempre el mismo.</p>
<p>Es el caso de una agenda: tenemos una serie de fichas, e iremos a&ntilde;adiendo m&aacute;s. Si reservamos espacio para 10, no podremos llegar a a&ntilde;adir la n&uacute;mero 11, estamos limitando el m&aacute;ximo. Una soluci&oacute;n ser&iacute;a la de trabajar siempre en el disco: no tenemos l&iacute;mite en cuanto a n&uacute;mero de fichas, pero es much&iacute;simo m&aacute;s lento.</p>
<p>Lo ideal ser&iacute;a aprovechar mejor la memoria que tenemos en el ordenador, para guardar en ella todas las fichas o al menos todas aquellas que quepan en memoria.</p>
<p>Una soluci&oacute;n &ldquo;t&iacute;pica&rdquo; (pero mala) es sobredimensionar: preparar una agenda contando con 1000 fichas, aunque supongamos que no vamos a pasar de 200. Esto tiene varios inconvenientes: se desperdicia memoria, obliga a conocer bien los datos con los que vamos a trabajar, sigue pudiendo verse sobrepasado, etc.</p>
<p>La soluci&oacute;n suele ser crear estructuras <strong>DIN&Aacute;MICAS</strong>, que puedan ir creciendo o disminuyendo seg&uacute;n nos interesen. Ejemplos de este tipo de estructuras son:</p>
<ul>
  <li>  Las pilas. Como una pila de libros: vamos apilando cosas en la cima, o cogiendo de la cima.</li>
  <li> Las colas. Como las del cine (en teor&iacute;a): la gente llega por un sitio (la cola) y sale por el opuesto (la cabeza).</li>
  <li> Las listas, en las que se puede a&ntilde;adir elementos, consultarlos o borrarlos en cualquier posici&oacute;n.</li>
</ul>
<p>Y la cosa se va complicando: en los <strong>&aacute;rboles</strong> cada elemento puede tener varios sucesores, etc. </p>
<p>    Todas estas estructuras tienen en com&uacute;n que, si se programan bien, pueden ir creciendo o decreciendo seg&uacute;n haga falta, al contrario que un array, que tiene su tama&ntilde;o prefijado.</p>
<p>En todas ellas, lo que vamos haciendo es reservar un poco de memoria para cada <strong>nuevo elemento</strong> que nos haga falta, y enlazarlo a los que ya ten&iacute;amos. Cuando queramos borrar un elemento, enlazamos el anterior a &eacute;l con el posterior a &eacute;l (para que no &ldquo;se rompa&rdquo; nuestra estructura) y liberamos la memoria que estaba ocupando.</p>
<p>&nbsp;</p>



        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   11619 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc08b.php">Anterior</a></li>
                    <li><a href="cc09b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        