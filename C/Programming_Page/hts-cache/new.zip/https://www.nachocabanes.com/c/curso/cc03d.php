<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 3 - Estructuras alternativas</title>

    
    <meta name="description" content="Curso de C - Tema 3 - Estructuras alternativas - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="bucle,alternativa,if,while,repeat,switch,case" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 3 - Estructuras alternativas          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc03c.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc03e.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>3.4. Sentencia continue: fuerza la siguiente iteraci&oacute;n</h3>



<p style="margin-left:150px;margin-right:150px;text-align:center;"><i>(Nota: 
En la <a href="../curso2016/">versión 2016 del curso</a>
tienes <a href="../curso2016/cc003e.php">una variante más reciente y más detallada de este apartado</a>)</i></p>


<p>Podemos saltar alguna repetici&oacute;n de un bucle con la orden &ldquo;<strong>continue</strong>&rdquo;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 34:      */
/*  C034.C                   */
/*                           */
/*  "for" interrumpido con   */
/*  "continue"               */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  int i;

  for (i=0; i<=10; i++)
  {
    if (i==5) continue;
    printf("%d ", i);
  }
        
  return 0;
}
</code></pre></p>    



<p>El resultado de este programa es:</p>
<p> 0 1 2 3 4 6 7 8 9 10</p>
<p>En &eacute;l podemos observar que no aparece el valor 5.</p>
<p>&nbsp;</p>

<p><strong>Ejercicio propuesto</strong>: </p>
<ul>
  <li>Crear un programa que pida un número al usuario (entre 1 y 20) y muestre los números el 1 al 20, excepto el indicado por el usuario, usando "continue" para evitar ese valor.</li>
</ul>


<p><b>Ejercicios resueltos: </b></p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for (i=1; i&lt;4; i++) printf(&quot;%d&quot;, i);</p>
<p>Respuesta: los n&uacute;meros del 1 al 3 (se empieza en 1 y se repite mientras sea menor que 4).<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for (i=1; i&gt;4; i++) printf(&quot;%d&quot;, i);</p>
<p>Respuesta: no escribir&iacute;a nada, porque la condici&oacute;n es falsa desde el principio.<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for (i=1; i&lt;=4; i++); printf(&quot;%d&quot;, i);</p>
<p>Respuesta: escribe un 5, porque hay un punto y coma despu&eacute;s del &ldquo;for&rdquo;, de modo que repite cuatro veces una orden vac&iacute;a, y cuando termina, &ldquo;i&rdquo; ya tiene el valor 5.<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for (i=1; i&lt;4; ) printf(&quot;%d&quot;, i);</p>
<p>Respuesta: escribe &ldquo;1&rdquo; continuamente, porque no aumentamos el valor de &ldquo;i&rdquo;, luego nunca se llegar&aacute; a cumplir la condici&oacute;n de salida.<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for (i=1; ; i++) printf(&quot;%d&quot;, i);</p>
<p>Respuesta: escribe n&uacute;meros continuamente, comenzando en uno y aumentando una unidad en cada pasada, pero si terminar nunca.<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for ( i= 0 ; i&lt;= 4 ; i++) {<br />
  if ( i == 2 ) continue ; printf( &quot;%d &quot; , i); }</p>
<p>Respuesta: escribe los n&uacute;meros del 0 al 4, excepto el 2.<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for ( i= 0 ; i&lt;= 4 ; i++) {<br />
  if ( i == 2 ) break ; printf( &quot;%d &quot; , i); }</p>
<p>Respuesta: escribe los n&uacute;meros 0 y 1 (interruumpe en el 2).<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for ( i= 0 ; i&lt;= 4 ; i++) {<br />
  if ( i == 10 ) continue ; printf( &quot;%d &quot; , i); }</p>
<p>Respuesta: escribe los n&uacute;meros del 0 al 4, porque la condici&oacute;n del &ldquo;continue&rdquo; nunca se llega a dar.<br />
</p>
<p>&gt; &iquest;Qu&eacute; escribir&iacute;a en pantalla este fragmento de c&oacute;digo?</p>
<p>for ( i= 0 ; i&lt;= 4 ; i++) <br />
  if ( i == 2 ) continue ; printf( &quot;%d &quot; , i); </p>
<p>Respuesta: escribe 5, porque no hay llaves tras el &ldquo;for&rdquo;, luego s&oacute;lo se repite la orden &ldquo;if&rdquo;.</p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   38777 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc03c.php">Anterior</a></li>
                    <li><a href="cc03e.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        