<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 1 - Toma de contacto con C</title>

    
    <meta name="description" content="Tutorial de C - Tema 1 - Toma de contacto con C - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="C,main,compilar,enlazar,printf" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 1 - Toma de contacto con C          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc01.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc01b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>1.1 Escribir un texto en C</h3>

<p>Vamos con un primer ejemplo de programa en C, posiblemente el m&aacute;s 
sencillo de los que &ldquo;hacen algo &uacute;til&rdquo;. Se trata de 
escribir un texto en pantalla. La apariencia de este programa la vimos en el 
tema anterior. Vamos a verlo ahora con m&aacute;s detalle:</p>

<p><pre><code class='language-c'>#include <stdio.h>

main() 
{
  printf("Hola");
}</code></pre></p>
<p>Esto escribe &ldquo;Hola&rdquo; en la pantalla. Pero hay mucho que comentar: </p>
<ul>
  <li> Eso de &ldquo;#include&rdquo; nos permite incluir ciertas caracter&iacute;sticas para <b>ampliar</b> el lenguaje base. En este caso, el motivo es que en el lenguaje C base no hay predefinida ninguna orden para escribir en pantalla (!), sino que este tipo de &oacute;rdenes son una extensi&oacute;n, que se define en un fichero llamado &ldquo;stdio.h&rdquo;. Esto no es un problema, vamos a encontrar ese &ldquo;stdio.h&rdquo; en cualquier compilador que usemos.
&iquest;Por qu&eacute; no hay &oacute;rdenes de pantalla en el lenguaje base? Hay que recordar que un ordenador no es s&oacute;lo lo que acostumbramos a tener sobre nuestra mesa, con pantalla y teclado: existen otros muchos tipos de ordenadores que realizan tareas complejas y no necesitan una pantalla durante su funcionamiento normal, como el ordenador que controla el ABS de un coche.
  &iquest;Y por qu&eacute; se pone entre &lt; y &gt;? &iquest;Y por qu&eacute; eso de # al principio? Esos detalles los iremos viendo un poco m&aacute;s adelante.</li>
  <li>Ya que hemos hablado de ella, &quot;printf&quot; es la orden que se encarga de <b>mostrar un texto</b> en pantalla, la responsable de que hayamos escrito ese &ldquo;include&rdquo; al principio del programa.</li>
  <li> Aun quedan cosas: &iquest;qu&eacute; hacen esas llaves { y } ? C es un lenguaje estructurado, en el que un programa est&aacute; formado por diversos &ldquo;<b>bloques</b>&rdquo;. Todos los elementos que componen este bloque deben estar relacionados entre s&iacute;, lo que se indica encerr&aacute;ndolos entre llaves: { y }.</li>
  <li> Finalmente, &iquest;qu&eacute; es eso de &ldquo;<b>main</b>&rdquo;? Es algo que debe existir siempre, e indica el punto en el que realmente comenzar&aacute; a funcionar el programa. Despu&eacute;s de &quot;main&quot; van dos llaves { y }, que delimitan el bloque m&aacute;s importante: el <b>cuerpo</b> del programa.&iquest;Y por qu&eacute; tiene un par&eacute;ntesis vac&iacute;o a continuaci&oacute;n? Eso lo veremos m&aacute;s adelante...</li>
</ul>
<p>Y la cosa no acaba aqu&iacute;. A&uacute;n queda m&aacute;s miga de la que parece en este programa, pero cuando ya vayamos practicando un poco, iremos concretando m&aacute;s alguna que otra cosa de las que aqu&iacute; han quedado poco detalladas.</p>
<p><b>Ejercicio propuesto:</b> Crea un programa en C que te salude por tu nombre (ej: &ldquo;Hola, Nacho&rdquo;). <br />
    <br />
    S&oacute;lo un par de cosas m&aacute;s antes de seguir adelante:<br />
</p>
<ul>
  <li> Cada orden de C debe terminar con un <b>punto y coma</b> (;)</li>
  <li>C es un lenguaje de <b>formato libre</b>, de modo que puede haber varias &oacute;rdenes en una misma l&iacute;nea, u &oacute;rdenes separadas por varias l&iacute;neas o espacios entre medias. Lo que realmente indica d&oacute;nde termina una orden y donde empieza la siguiente son los puntos y coma. Por ese motivo, el programa anterior se podr&iacute;a haber escrito tambi&eacute;n as&iacute; (aunque no es aconsejable, porque puede resultar menos legible):</li>
</ul>

<p><pre><code class='language-c'>    #include <stdio.h>
    main()  {  printf("Hola"); }</code></pre></p>
    <ul>
      <li>De hecho, hay dos formas especialmente frecuentes de colocar la llave de comienzo, y yo usar&eacute; ambas indistintamente. Una es como hemos hecho en el primer ejemplo: situar la llave de apertura en una l&iacute;nea, sola, y justo encima de la llave de cierre correspondiente. La segunda forma habitual es situ&aacute;ndola a continuaci&oacute;n del nombre del bloque que comienza (en nuestro caso, a continuaci&oacute;n de la palabra &ldquo;main&rdquo;), as&iacute;:</li>
    </ul>
<p><pre><code class='language-c'>#include <stdio.h>

main()  {
  printf("Hola");
}</code></pre></p>

<p>(esta es la forma que yo emplear&eacute; en este texto cuando estemos trabajando con fuentes de mayor tama&ntilde;o, para que ocupe un poco menos de espacio). </p>
<ul>
  <li>La gran mayor&iacute;a de las &oacute;rdenes que encontraremos en el lenguaje C son palabras en ingl&eacute;s o abreviaturas de &eacute;stas. Pero hay que tener en cuenta que C <b>distingue entre may&uacute;sculas y min&uacute;sculas</b>, por lo que &quot;printf&quot; es una palabra reconocida, pero &quot;Printf&quot;, &quot;PRINTF&quot; o &quot;PrintF&quot; no lo son.</li>
</ul>
<p>&nbsp;</p>

<p><b>¿Y si ese programa "me da error"?</b> En algunas revisiones recientes del lenguaje C (especialmente en los compiladores que siguen el estándar C99) se obliga a que aparezca la palabra "int" antes de "main", y a que la última línea sea "return 0;". Veremos los motivos más adelante, en el tema 7, pero de momento asumiremos que si queremos que nuestro programa se pueda probar con cualquier compilador, su apariencia deberá ser ésta:</p>

<p><pre><code class='language-c'>#include <stdio.h>

int main() 
{
  printf("Hola");
  return 0;
}</code></pre></p>

<h4>1.1.1. C&oacute;mo probar este programa en Linux</h4>

<p><b>(Nota: este apartado está más actualizado en la versión 0.95 PDF del curso; pronto se incluirán aquí esos cambios)</b></p>

<p> Los sistemas operativos de la familia Unix, como Linux, suelen incluir un compilador de C, de modo que ser&aacute; f&aacute;cil probar nuestros programas. Supondremos que se trata de una versi&oacute;n de Linux de los &uacute;ltimos a&ntilde;os, que tenga entorno gr&aacute;fico. Podr&iacute;amos usar el editor del texto del entorno gr&aacute;fico, teclear el fuente y guardarlo en nuestra carpeta personal, por ejemplo con el nombre ejemplo001.c (lo que s&iacute; es importante es que termine en &ldquo;.c&rdquo;):</p>
<p align="center"><img src="cc_linux01.jpg" width="480" height="291" /></p>
<p>(en esta imagen se trata de Mandrake Linux 9.1, con el entorno Gnome y el editor b&aacute;sico que incorpora, GEdit).</p>
<p>Despu&eacute;s abrir&iacute;amos una ventana de terminal y teclear&iacute;amos la siguiente orden para compilar nuestro fuente:</p>
<pre>cc ejemplo001.c &ndash;o miprograma</pre>
<p>Donde:</p>
<ul>
  <li>&ldquo;cc&rdquo; es la orden que se usa para poner el compilador en marcha.</li>
  <li> &ldquo;ejemplo001.c&rdquo; es el nombre del fuente que queremos compilar.</li>
  <li>La opci&oacute;n &ldquo;-o&rdquo; se usa para indicar el nombre que queremos que tenga el fichero ejecutable resultante (la &ldquo;o&rdquo; viene de &ldquo;output&rdquo;, salida).</li>
  <li>&ldquo;miprograma&rdquo; es el nombre que tendr&aacute; el programa ejecutable.</li>
</ul>
<p>Y para probar el programa teclear&iacute;amos</p>
<pre>./miprograma</pre>
<p>Con lo que deber&iacute;a aparecer escrito &ldquo;Hola&rdquo; en la pantalla.</p>
<p align="center"><img src="cc_linux02.jpg" width="348" height="210" /></p>
<p>(Nota: Las versiones m&aacute;s recientes de Linux tienen entornos integrados, desde los que podemos teclear y probar nuestro programa, con m&aacute;s comodidad, como en el caso de la herramienta que vamos a comentar para Windows. Dos de los entornos m&aacute;s extendidos son KDevelop y Anjuta).</p>

<h4><br />
  1.1.2. C&oacute;mo probar este programa en Windows</h4>

<p><b>(Nota: este apartado está más actualizado en la versión 0.95 PDF del curso; pronto se incluirán aquí esos cambios)</b></p>


<p>La familia de sistemas Windows no incluye ning&uacute;n compilador de C, de modo que tendremos que localizar uno e instalarlo. Existen muchos gratuitos que se pueden descargar de Internet, y que incluyen un editor y otras herramientas auxiliares. Es el caso de Dev-C++, por ejemplo, que tiene su p&aacute;gina oficial en www.bloodshed.net. La instalaci&oacute;n es poco m&aacute;s que hacer doble clic en el fichero descargado, y hacer clic varias veces en el bot&oacute;n &ldquo;Siguiente&rdquo;:</p>
  
<p align="center"><img src="cc_devc01.jpg" width="324" height="253" /></p>

<p>En el caso de Dev-C++, podemos incluso trabajar con el entorno en espa&ntilde;ol:</p>

<p align="center"><img src="cc_devc02.jpg" width="312" height="237" /></p>

<p>&nbsp;</p>

<p>Para crear nuestro programa, en el men&uacute; &quot;Archivo&quot; escogemos &quot;Nuevo&nbsp; / C&oacute;digo fuente&quot;, y nos aparece un editor vac&iacute;o en el que ya podemos empezar a teclear. Si queremos nuestro programa en funcionamiento, entrar&iacute;amos al men&uacute; &ldquo;Ejecutar&rdquo; y usar&iacute;amos la opci&oacute;n &ldquo;Compilar y ejecutar&rdquo;:</p>

<p align="center"><img src="cc_devc03.jpg" width="348" height="243" /></p>

<p>(si todav&iacute;a no hemos guardado los cambios en nuestro fuente, nos pedir&iacute;a antes que lo hici&eacute;ramos).</p>

<p>&nbsp;</p>
<p>Puede ocurrir que se muestre el resultado en pantalla, pero la ventana desaparezca tan r&aacute;pido que no tengamos tiempo de leerlo. Si es nuestro caso, tenemos dos opciones:</p>
<ul>
  <li> Algunos entornos (como los de la familia Turbo C y Borland C) tienen una opci&oacute;n &ldquo;User Screen&rdquo; (pantalla de usuario) en el men&uacute; &ldquo;Run&rdquo; (ejecutar), que nos mostrar&iacute;a lo que ha aparecido en esa pantalla que no pudimos leer.</li>
  </ul>
<p align="center"><img src="cc_turboc.jpg" width="360" height="183" /></p>
<ul>
  <li>Otros entornos, como Dev-C++, no tienen esa posibilidad, por lo que deber&iacute;amos hacer un peque&ntilde;o cambio a nuestro fuente, para que espere a que pulsemos la tecla Intro antes de terminar. Una orden que nos permitir&iacute;a hacer eso (y que veremos con m&aacute;s detalle m&aacute;s adelante) es &ldquo;getchar()&rdquo;, as&iacute; que nuestro fuente quedar&iacute;a</li>
</ul>

<p><pre><code class='language-c'>#include <stdio.h>

main() 
{
  printf("Hola");
  getchar();
}</code></pre></p>
<p>O bien, si usamos la sintaxis más detallada:</p>

<p><pre><code class='language-c'>#include <stdio.h>

int main() 
{
  printf("Hola");
  getchar();
  return 0;
}</code></pre></p>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   25551 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc01.php">Anterior</a></li>
                    <li><a href="cc01b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        