<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema  5 - Arrays y estructuras</title>

    
    <meta name="description" content="Curso de C - Tema  5 - Arrays y estructuras - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="array,arreglo,struct,vector,matriz,estructura,registro" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema  5 - Arrays y estructuras          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc05e.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc05g.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>5.6 Ejemplo completo</h3>

<p>Vamos a hacer un ejemplo completo que use tablas (&ldquo;arrays&rdquo;), registros (&ldquo;struct&rdquo;) y que adem&aacute;s manipule cadenas.</p>
<p>La idea va a ser la siguiente: Crearemos un programa que pueda almacenar datos de hasta 1000 ficheros (archivos de ordenador). Para cada fichero, debe guardar los siguientes datos: Nombre del fichero (max 40 letras), Tama&ntilde;o (en KB, n&uacute;mero de 0 a 2.000.000.000). El programa mostrar&aacute; un men&uacute; que permita al usuario las siguientes operaciones:</p>
<p>1- A&ntilde;adir datos de un nuevo fichero<br />
  2- Mostrar los nombres de todos los ficheros almacenados<br />
  3- Mostrar ficheros que sean de m&aacute;s de un cierto tama&ntilde;o (por ejemplo, 2000 KB).<br />
  4- Ver todos los datos de un cierto fichero (a partir de su nombre)<br />
  5- Salir de la aplicaci&oacute;n (como todav&iacute;a no sabemos almacenar los datos, &eacute;stos se perder&aacute;n).</p>
<p>No deber&iacute;a resultar dif&iacute;cil. Vamos a ver directamente una de las formas en que se podr&iacute;a plantear y luego comentaremos alguna de las mejoras que se podr&iacute;a (incluso se deber&iacute;a) hacer.</p>
<p>Una opci&oacute;n que podemos a tomar para resolver este problema es la de contar el n&uacute;mero de fichas que tenemos almacenadas, y as&iacute; podremos a&ntilde;adir de una en una. Si tenemos 0 fichas, deberemos almacenar la siguiente (la primera) en la posici&oacute;n 0; si tenemos dos fichas, ser&aacute;n la 0 y la 1, luego a&ntilde;adiremos en la posici&oacute;n 2; en general, si tenemos &ldquo;n&rdquo; fichas, a&ntilde;adiremos cada nueva ficha en la posici&oacute;n &ldquo;n&rdquo;. Por otra parte, para revisar todas las fichas, recorreremos desde la posici&oacute;n 0 hasta la n-1, haciendo algo como</p>
<p> for (i=0; i&lt;=n-1; i++) { ... m&aacute;s &oacute;rdenes ...}</p>
<p>o bien algo como</p>
<p> for (i=0; i&lt;n; i++) { ... m&aacute;s &oacute;rdenes ...}</p>
<p>El resto del programa no es dif&iacute;cil: sabemos leer y comparar textos y n&uacute;meros. S&oacute;lo haremos tres consideraciones:</p>
<ul>
  <li> Los textos (nombre del fichero, por ejemplo) pueden contener espacios, por lo que usaremos &ldquo;gets&rdquo; en vez de &ldquo;scanf&rdquo;.</li>
  <li>Es<strong> &ldquo;peligroso&rdquo; mezclar &oacute;rdenes &ldquo;gets&rdquo; y &ldquo;scanf&rdquo;</strong>: si leemos un n&uacute;mero con &ldquo;scanf&rdquo;, la pulsaci&oacute;n de la tecla &ldquo;Intro&rdquo; posterior se queda en el buffer del teclado, lo que puede provocar que despu&eacute;s intentemos leer con &ldquo;gets&rdquo; un texto, pero s&oacute;lo leamos esa pulsaci&oacute;n de la tecla &ldquo;Intro&rdquo;. Para evitarlo, los n&uacute;meros los leeremos &ldquo;en dos etapas&rdquo;: primero leeremos una cadena con &ldquo;gets&rdquo; y luego la convertiremos a n&uacute;mero con &ldquo;sscanf&rdquo;.</li>
  <li>Hemos limitado el n&uacute;mero de fichas a 1000, as&iacute; que, si nos piden a&ntilde;adir, deber&iacute;amos asegurarnos antes de que todav&iacute;a tenemos hueco disponible.<br />
  </li>
</ul>
<p>Con todo esto, nuestro fuente quedar&iacute;a as&iacute;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 53:      */
/*  C053.C                   */
/*                           */
/*  Tabla con muchos struct  */
/*  y menu para manejarla    */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>
#include <string.h>

struct{
   char nombreFich[41];     /* Nombre del fichero */
   unsigned long tamanyo;   /* El tamaño en bytes */
} fichas[1000];

int numeroFichas=0;  /* Número de fichas que ya tenemos */
int i;               /* Para bucles */

int opcion;          /* La opcion del menu que elija el usuario */

char textoTemporal[40]; /* Para cuando preguntemos al usuario */
unsigned long numeroTemporal;

int main()
{ 
  do {
    /* Menu principal */
    printf("Escoja una opción:\n");
    printf("1.- Añadir datos de un nuevo fichero\n");
    printf("2.- Mostrar los nombres de todos los ficheros\n");
    printf("3.- Mostrar ficheros que sean de mas de un cierto tamaño\n");
    printf("4.- Ver datos de un fichero\n");
    printf("5.- Salir\n");

    /* Para evitar problemas con datos mal introducidos,
       leemos con "gets" y luego lo filtramos con "sscanf" */
    gets (textoTemporal);
    sscanf(textoTemporal, "%d", &opcion);

    /* Hacemos una cosa u otra según la opción escogida */
    switch(opcion){
       case 1: /* Añadir un dato nuevo */
               if (numeroFichas < 1000) {  /* Si queda hueco */
                 printf("Introduce el nombre del fichero: ");
                 gets(fichas[numeroFichas].nombreFich);
                 printf("Introduce el tamaño en KB: ");
                 gets(textoTemporal);
                 sscanf(textoTemporal,"%ld",&fichas[numeroFichas].tamanyo);
                 /* Y ya tenemos una ficha más */
                 numeroFichas++;
               } else   /* Si no hay hueco para más fichas, avisamos */
                 printf("Máximo de fichas alcanzado (1000)!\n");
               break;
       case 2: /* Mostrar todos */
               for (i=0; i<numeroFichas; i++) 
                  printf("Nombre: %s; Tamaño: %ld Kb\n",
                    fichas[i].nombreFich, fichas[i].tamanyo);
               break;
       case 3: /* Mostrar según el tamaño */
               printf("¿A partir de que tamaño quieres que te muestre?");
               gets(textoTemporal);
               sscanf(textoTemporal, "%ld", &numeroTemporal);
               for (i=0; i<numeroFichas; i++)
                 if (fichas[i].tamanyo >= numeroTemporal)
                    printf("Nombre: %s; Tamaño: %ld Kb\n",
                      fichas[i].nombreFich, fichas[i].tamanyo);
               break;
       case 4: /* Ver todos los datos (pocos) de un fichero */
               printf("¿De qué fichero quieres ver todos los datos?");
               gets(textoTemporal);
               for (i=0; i<numeroFichas; i++) 
                 if (strcmp(fichas[i].nombreFich, textoTemporal) == 0)
                    printf("Nombre: %s; Tamaño: %ld Kb\n",
                      fichas[i].nombreFich, fichas[i].tamanyo);
               break;
       case 5: /* Salir: avisamos de que salimos */
               printf("Fin del programa\n"); 
               break;
       default: /* Otra opcion: no válida */
               printf("Opción desconocida!\n"); 
               break;
       }
   } while (opcion != 5);  /* Si la opcion es 5, terminamos */
           
   return 0;
}
</code></pre></p>

<p>Funciona, y hace todo lo que tiene que hacer, pero es mejorable. Por supuesto, en un caso real es habitual que cada ficha tenga que guardar m&aacute;s informaci&oacute;n que s&oacute;lo esos dos apartados de ejemplo que hemos previsto esta vez. Si nos muestra todos los datos en pantalla y se trata de muchos datos, puede ocurrir que aparezcan en pantalla tan r&aacute;pido que no nos d&eacute; tiempo a leerlos, as&iacute; que ser&iacute;a deseable que parase cuando se llenase la pantalla de informaci&oacute;n (por ejemplo, una pausa tras mostrar cada 25 datos). Por supuesto, se nos pueden ocurrir muchas m&aacute;s preguntas que hacerle sobre nuestros datos. Y adem&aacute;s, cuando salgamos del programa se borrar&aacute;n todos los datos que hab&iacute;amos tecleado, pero eso es lo &uacute;nico &ldquo;casi inevitable&rdquo;, porque a&uacute;n no sabemos manejar ficheros.</p>
<p>&nbsp;</p>
<p>Ejercicios propuestos: </p>
<ul>
  <li> Un programa que pida el nombre, el apellido y la edad de una persona, los almacene en un &ldquo;struct&rdquo; y luego muestre los tres datos en una misma l&iacute;nea, separados por comas.</li>
  <li>Un programa que pida datos de 8 personas: nombre, dia de nacimiento, mes de nacimiento, y a&ntilde;o de nacimiento (que se deben almacenar en una tabla de structs). Despu&eacute;s deber&aacute; repetir lo siguiente: preguntar un n&uacute;mero de mes y mostrar en pantalla los datos de las personas que cumplan los a&ntilde;os durante ese mes. Terminar&aacute; de repetirse cuando se teclee 0 como n&uacute;mero de mes.</li>
  <li>Un programa que sea capaz de almacenar los datos de 50 personas: nombre, direcci&oacute;n, tel&eacute;fono, edad (usando una tabla de structs). Deber&aacute; ir pidiendo los datos uno por uno, hasta que un nombre se introduzca vac&iacute;o (se pulse Intro sin teclear nada). Entonces deber&aacute; aparecer un men&uacute; que permita:
    <ul>
      <li>Mostrar la lista de todos los nombres.</li>
      <li>Mostrar las personas de una cierta edad.</li>
      <li>Mostrar las personas cuya inicial sea la que el usuario indique.</li>
      <li>Salir del programa<br />
          (l&oacute;gicamente, este men&uacute; debe repetirse hasta que se escoja la opci&oacute;n de &ldquo;salir&rdquo;).<br />
        </li>
    </ul>
    </li>
  <li> Mejorar la base de datos de ficheros (ejemplo 53) para que no permita introducir tama&ntilde;os incorrectos (n&uacute;meros negativos) ni nombres de fichero vac&iacute;os. </li>
  <li>Ampliar la base de datos de ficheros (ejemplo 53) para que incluya una opci&oacute;n de b&uacute;squeda parcial, en la que el usuario indique parte del nombre y se muestre todos los ficheros que contienen ese fragmento (usando “strstr”). </li>
  <li>Ampliar la base de datos de ficheros (ejemplo 53) para que se pueda borrar un cierto dato (habr&aacute; que “mover hacia atr&aacute;s” todos los datos que hab&iacute;a despu&eacute;s de ese, y disminuir el contador de la cantidad de datos que tenemos). </li>
  <li>Mejorar la base de datos de ficheros (ejemplo 53) para que se pueda modificar un cierto dato a partir de su n&uacute;mero (por ejemplo, el dato n&uacute;mero 3). En esa modificaci&oacute;n, se deber&aacute; permitir al usuario pulsar Intro sin teclear nada, para indicar que no desea modificar un cierto dato, en vez de reemplazarlo por una cadena vac&iacute;a. </li>
  <li>Ampliar la base de datos de ficheros (ejemplo 53) para que se permita ordenar los datos por nombre. Para ello, deber&aacute;s buscar informaci&oacute;n sobre alg&uacute;n m&eacute;todo de ordenaci&oacute;n sencillo, como el &quot;m&eacute;todo de burbuja&quot; (en el siguiente apartado tienes algunos), y aplicarlo a este caso concreto. </li>
  </ul>
<p>&nbsp;</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   41346 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc05e.php">Anterior</a></li>
                    <li><a href="cc05g.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        