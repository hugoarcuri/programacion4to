<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 2 - Tipos de datos</title>

    
    <meta name="description" content="Curso de C - Tema 2 - Tipos de datos - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="int,float,double,char,void,cadena,ascii" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 2 - Tipos de datos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc02d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc03.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>2.5. Tipo de datos car&aacute;cter</h3>

<p>Tambi&eacute;n tenemos un tipo de datos que nos permite almacenar una &uacute;nica letra (ya veremos que manipular una cadena de texto completa es relativamente complicado). Es el tipo &ldquo;char&rdquo;:</p>
<p>char letra;</p>
<p>Asignar valores es sencillo:</p>
<p>letra = 'a';</p>
<p>(hay que destacar que se usa una <strong>comilla simple</strong> en vez de comillas dobles). Mostrarlos en pantalla tambi&eacute;n es f&aacute;cil:</p>
<p>printf(&quot;%c&quot;, letra);</p>
<p>As&iacute;, un programa que leyera una letra tecleada por el usuario, fijara otra y mostrara ambas podr&iacute;a ser:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 13:      */
/*  c013.c                   */
/*                           */
/*  Tipo de datos char       */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main() {
  char letra1, letra2;
       
  printf("Teclea una letra "); 
  scanf("%c", &letra1);
  letra2 = 'a';
  printf("La letra que has tecleado es %c y la prefijada es %c",
    letra1, letra2);
      
  return 0;
}
</code></pre></p>
<h4>2.5.1. Secuencias de escape: \n y otras.</h4>
<p>Al igual que ocurr&iacute;a con expresiones como %d, que ten&iacute;an un significado especial, ocurre lo mismo con ciertos caracteres, que nos permiten hacer cosas como bajar a la l&iacute;nea siguiente o mostrar las comillas en pantalla.</p>
<p>Son las siguientes:</p>
<table cellspacing="0" cellpadding="0">
  <tr>
    <td width="156" valign="top"><p><strong>Secuencia </strong></p></td>
    <td width="420" valign="top"><p><strong>Significado </strong></p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\a </p></td>
    <td width="420" valign="top"><p>Emite un pitido </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\b </p></td>
    <td width="420" valign="top"><p>Retroceso (permite borrar el &uacute;ltimo car&aacute;cter) </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\f </p></td>
    <td width="420" valign="top"><p>Avance de p&aacute;gina (expulsa una hoja en la impresora) </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\n </p></td>
    <td width="420" valign="top"><p>Avanza de l&iacute;nea (salta a la l&iacute;nea siguiente) </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\r </p></td>
    <td width="420" valign="top"><p>Retorno de carro (va al principio de la l&iacute;nea) </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\t </p></td>
    <td width="420" valign="top"><p>Salto de tabulaci&oacute;n horizontal </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\v </p></td>
    <td width="420" valign="top"><p>Salto de tabulaci&oacute;n vertical </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\' </p></td>
    <td width="420" valign="top"><p>Muestra una comilla simple </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\&quot; </p></td>
    <td width="420" valign="top"><p>Muestra una comilla doble </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\\ </p></td>
    <td width="420" valign="top"><p>Muestra una barra invertida </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\0 </p></td>
    <td width="420" valign="top"><p>Car&aacute;cter nulo (NULL) </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\7 </p></td>
    <td width="420" valign="top"><p>Emite un pitido (igual que \a) </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\ddd </p></td>
    <td width="420" valign="top"><p>Un valor en octal </p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>\xddd </p></td>
    <td width="420" valign="top"><p>Un valor en hexadecimal </p></td>
  </tr>
</table>
<p><strong>Ejercicio propuesto</strong>: Crear un programa que pida al usuario que teclee cuatro letras y las muestre en pantalla juntas, pero en orden inverso, y entre comillas dobles. Por ejemplo si las letras que se teclean son a, l, o, h, escribir&iacute;a &quot;hola&quot;.</p>
<h4>2.5.2. Introducci&oacute;n a las dificultades de las cadenas de texto</h4>
<p>En el lenguaje C, no existe un tipo de datos para representar una cadena de texto. Eso supone que su manejo no sea tan sencillo como el de los n&uacute;meros enteros, numeros reales y las letras. Deberemos tratarla como un bloque de varias letras. Por eso lo veremos m&aacute;s adelante.<br />
</p>
<p>&nbsp;</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   2902 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc02d.php">Anterior</a></li>
                    <li><a href="cc03.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        