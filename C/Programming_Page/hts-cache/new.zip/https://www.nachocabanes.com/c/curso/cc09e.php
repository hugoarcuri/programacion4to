<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 9 - Punteros</title>

    
    <meta name="description" content="Curso de C - Tema 9 - Punteros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="punteros,malloc,free,argc,argv,pointer,null" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 9 - Punteros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc09d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc09f.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>9.5. Punteros y funciones: par&aacute;metros por referencia</h3>
<p>Hasta ahora no sab&iacute;amos c&oacute;mo modificar los par&aacute;metros que pas&aacute;bamos a una funci&oacute;n. Recordemos el ejemplo 64:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 64:      */
/*  C064.C                   */
/*                           */
/*  Dos variables locales    */
/*  con el mismo nombre      */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

void duplica(int n) {
    n = n * 2;
}

int main() {
    int n = 5;
    printf("n vale %d\n", n);
    duplica(n);
    printf("Ahora n vale %d\n", n);
   
    return 0;
}
</code></pre></p>
Cuando pon&iacute;amos este programa en marcha, el valor de n que se mostraba era un 5, porque los cambios que hici&eacute;ramos dentro de la funci&oacute;n se perd&iacute;an al salir de ella. Esta forma de trabajar (la &uacute;nica que conoc&iacute;amos hasta ahora) es lo que se llama &ldquo;pasar <strong>par&aacute;metros por valor</strong>&rdquo;.</p>
<p>Pero existe una alternativa. Es lo que llamaremos &ldquo;<strong>pasar par&aacute;metros por referencia</strong>&rdquo;. Consiste en que el par&aacute;metro que nosotros pasamos a la funci&oacute;n no es realmente la variable, sino la direcci&oacute;n de memoria en que se encuentra dicha variable (usando &amp;). Dentro de la funci&oacute;n, modificaremos la informaci&oacute;n que se encuentra dentro de esa direcci&oacute;n de memoria (usando *), as&iacute;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 74:      */
/*  C074.C                   */
/*                           */
/*  Modificar el valor de    */
/*  un parámetro             */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

void duplica(int *x) {
    *x = *x * 2;
}

int main() {
    int n = 5;
    printf("n vale %d\n", n);
    duplica(&n);
    printf("Ahora n vale %d\n", n);

    return 0;   
}
</code></pre></p>
<p>Esto permite que podamos obtener m&aacute;s de un valor a partir de una funci&oacute;n. Por ejemplo, podemos crear una funci&oacute;n que intercambie los valores de dos variables enteras as&iacute;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 75:      */
/*  C075.C                   */
/*                           */
/*  Intercambiar el valor de */
/*  dos parámetros           */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

void intercambia(int *x, int *y) {
    int auxiliar;
    auxiliar = *x;
    *x = *y;
    *y = auxiliar ;
}

int main() {
    int a = 5;
    int b = 12;
    intercambia(&a, &b);
    printf("Ahora a es %d y b es %d\n", a, b);
   
    return 0;
}
</code></pre></p>
<p>Este programa escribir&aacute; en pantalla que a vale 12 y que b vale 5. Dentro de la funci&oacute;n &ldquo;intercambia&rdquo;, nos ayudamos de una variable auxiliar para memorizar el valor de x antes de cambiarlo por el valor de y.</p>
<p><strong>Ejercicio propuesto</strong>: crear una funci&oacute;n que calcule las dos soluciones de una ecuaci&oacute;n de segundo grado (Ax<sup>2</sup> + Bx + C = 0) y devuelva las dos soluciones como par&aacute;metros.<br />
</p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   8174 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc09d.php">Anterior</a></li>
                    <li><a href="cc09f.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        