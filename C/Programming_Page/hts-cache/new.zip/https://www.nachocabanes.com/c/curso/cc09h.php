<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 9 - Punteros</title>

    
    <meta name="description" content="Curso de C - Tema 9 - Punteros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="punteros,malloc,free,argc,argv,pointer,null" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 9 - Punteros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc09g.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc09i.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>9.8. Punteros y estructuras</h3>
<p>Igual que creamos punteros a cualquier tipo de datos b&aacute;sico, le reservamos memoria con &ldquo;malloc&rdquo; cuando necesitamos usarlo y lo liberamos con &ldquo;free&rdquo; cuando terminamos de utilizarlo, lo mismo podemos hacer si se trata de un tipo de datos no tan sencillo, como un &ldquo;struct&rdquo;.
  </p>

<p>Eso s&iacute;, la forma de acceder a los datos en un struct cambiar&aacute; ligeramente. Para un dato que sea un n&uacute;mero entero, ya sabemos que lo declarar&iacute;amos con int *n y cambiar&iacute;amos su valor haciendo algo como *n=2, de modo que para un struct podr&iacute;amos esperar que se hiciera algo como *persona.edad = 20. Pero esa no es la sintaxis correcta: deberemos utilizar el nombre de la variable y el del campo, con una flecha (-&gt;) entre medias, as&iacute;: persona-&gt;edad = 20. Vamos a verlo con un ejemplo:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 79:      */
/*  C079.C                   */
/*                           */
/*  Punteros y structs       */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main() {    
   /* Primero definimos nuestro tipo de datos */    
   struct datosPersona {
     char nombre[30];
     char email[25];
     int edad;
   };
   
   /* La primera persona será estática */
   struct datosPersona persona1;
   /* La segunda será dinámica */
   struct datosPersona *persona2;
   
   /* Damos valores a la persona estática */
   strcpy(persona1.nombre, "Juan");
   strcpy(persona1.email, "j@j.j");
   persona1.edad = 20;
   
   /* Ahora a la dinámica */
   persona2 = (struct datosPersona*)
     malloc (sizeof(struct datosPersona));
   strcpy(persona2->nombre, "Pedro");
   strcpy(persona2->email, "p@p.p");
   persona2->edad = 21;

   /* Mostramos los datos y liberamos la memoria */
   printf("Primera persona: %s, %s, con edad %d\n",
     persona1.nombre, persona1.email, persona1.edad);
   printf("Segunda persona: %s, %s, con edad %d\n",
     persona2->nombre, persona2->email, persona2->edad);
   free(persona2);

   return 0;   
}
</code></pre></p>

<strong>Ejercicio propuesto</strong>: mejorar la versi&oacute;n de la agenda que le&iacute;a todos los datos al principio de la ejecuci&oacute;n y guardaba todos los datos cuando termin&aacute;bamos su uso (apartado 6.4). Esta nueva versi&oacute;n deber&aacute; estar preparada para manejar hasta 1000 fichas, pero s&oacute;lo reservar&aacute; espacio para las que realmente sean necesarias.</p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   7787 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc09g.php">Anterior</a></li>
                    <li><a href="cc09i.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        