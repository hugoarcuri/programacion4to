<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 1 - Toma de contacto con C</title>

    
    <meta name="description" content="Tutorial de C - Tema 1 - Toma de contacto con C - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="C,main,compilar,enlazar,printf" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 1 - Toma de contacto con C          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc01d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc01f.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h3>1.5. Identificadores</h3>

<p>Estos nombres de variable (lo que se conoce como &ldquo;<b>identificadores</b>&rdquo;) pueden estar formados por letras, n&uacute;meros o el s&iacute;mbolo de subrayado (_) y deben comenzar por letra o subrayado. No deben tener espacios entre medias, y hay que recordar que las vocales acentuadas y la e&ntilde;e son problem&aacute;ticas, porque no son letras &quot;est&aacute;ndar&quot; en todos los idiomas. Algunos compiladores permiten otros s&iacute;mbolos, como el $, pero es aconsejable no usarlos, de modo que el programa sea m&aacute;s portable (funcione con facilidad en distintos sistemas).</p>

<p>Por eso, no son nombres de variable v&aacute;lidos:</p>

<ul>
  <li> 1numero (empieza por n&uacute;mero)</li>
  <li> un numero (contiene un espacio)</li>
  <li> A&ntilde;o1 (tiene una e&ntilde;e)</li>
  <li> M&aacute;sDatos (tiene una vocal acentuada)<br />
    </li>
</ul>

<p>Tampoco podremos usar como identificadores las <b>palabras reservadas</b> de C. Por ejemplo, la palabra &quot;int&quot; se refiere a que cierta variable guardar&aacute; un n&uacute;mero entero, as&iacute; que esa palabra &quot;int&quot; no la podremos usar tampoco como nombre de variable (pero no vamos a incluir ahora una lista de palabras reservadas de C, ya nos iremos encontrando con ellas).</p>

<p>De momento, intentaremos usar nombres de variables que a nosotros nos resulten claros, y que no parezca que puedan ser alguna orden de C.</p>

<p>Hay que recordar que en C las <b>may&uacute;sculas y min&uacute;sculas</b> se consideran diferentes, de modo que si intentamos hacer</p>

<p><pre><code class='language-c'>PrimerNumero = 0; 
primernumero = 0;</code></pre></p>  
<p>o cualquier variaci&oacute;n similar, el compilador protestar&aacute; y nos dir&aacute; que no conoce esa variable, porque la hab&iacute;amos declarado como</p>

<p><pre><code class='language-c'>int primerNumero; 
</code></pre></p>
<p>El <b>n&uacute;mero de letras</b> que puede tener un &quot;identificador&quot; (el nombre de una variable, por ejemplo) depende del compilador que usemos. Es frecuente que permitan cualquier longitud, pero que realmente s&oacute;lo se fijen en unas cuantas letras (por ejemplo, en las primeras 8 o en las primeras 32). Eso quiere decir que puede que alg&uacute;n compilador considerase como iguales las variables NumeroParaAnalizar1 y NumeroParaAnalizar2, porque tienen las primeras 18 letras iguales. El C est&aacute;ndar (ANSI C) permite cualquier longitud, pero s&oacute;lo considera las<b> primeras 31</b>.</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   22698 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc01d.php">Anterior</a></li>
                    <li><a href="cc01f.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        