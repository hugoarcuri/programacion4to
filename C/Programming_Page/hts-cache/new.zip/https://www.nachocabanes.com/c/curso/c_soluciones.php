<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Soluciones a los ejercicios</title>

    
    <meta name="description" content="Tutorial de C - Soluciones a los ejercicios - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="C,ejercicios,problemas,soluciones" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Soluciones a los ejercicios          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="index.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="index.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        <h2>Soluciones a los ejercicios propuestos</h2>


<p>(Ejercicios incluidos hasta el momento: 170, resueltos: 42)</p>
<ul>
<li>Apartado 0.1.1 (Sin resolver todav&iacute;a): Localiza en Internet el intérprete de BASIC llamado Bywater Basic, en su versión para el sistema operativo que estés utilizando (o algún otro intérprete de BASIC clásico, como un emulador de un Amstrad CPC, un MSX o un Commodore 64) y prueba el primer programa de ejemplo que se ha visto en el apartado 0.1. (Nota: no es imprescindible para seguir el curso; puedes omitir este ejercicio si no quieres instalar en tu equipo software que quizá no vuelvas a utilizar).</li>
<li>Apartado 0.1.2 (Sin resolver todav&iacute;a): Localiza en Internet el compilador de Pascal llamado Free Pascal, en su versión para el sistema operativo que estés utilizando y prueba el segundo programa de ejemplo que se ha visto en el apartado 0.1. (Nota: no es imprescindible para seguir el curso; puedes omitir este ejercicio si no quieres instalar nada en tu equipo).</li>
<li><a href="#0102"> Apartado 1.2</a>: Crea un programa que diga el resultado de sumar 118 y 56.</li>
<li>Apartado 1.2b (Sin resolver todav&iacute;a): Un programa que calcule la diferencia entre 12345 y 998.</li>
<li>Apartado 1.2c (Sin resolver todav&iacute;a): Un programa que calcule y muestre el resultado de dividir 3765 entre 18 y el resto de esa división.</li>
<li><a href="#010301"> Apartado 1.3.1</a>: Calcular (a mano y despu&eacute;s comprobar desde C) el resultado de estas operaciones:	-2 + 3 * 5 ; (20+5) % 6 ; 	15 + -5*6 / 10 ; 2 + 10 / 5 * 2 - 7 % 1</li>
<li><a href="#010403"> Apartado 1.4.3</a>: Hacer un programa que calcule el producto de los n&uacute;meros 121 y 132, usando variables.</li>
<li><a href="#010701a"> Apartado 1.7.1a</a>: Multiplicar dos n&uacute;meros tecleados por usuario</li>
<li><a href="#010701b"> Apartado 1.7.1b</a>: El usuario teclear&aacute; dos n&uacute;meros (x e y), y el programa deber&aacute; calcular cual es el resultado de su divisi&oacute;n y el resto de esa divisi&oacute;n.</li>
<li><a href="#010701c"> Apartado 1.7.1c</a>: El usuario teclear&aacute; dos n&uacute;meros (a y b), y el programa mostrar el resultado de la operaci&oacute;n (a+b)*(a-b) y el resultado de la operaci&oacute;n a2-b2.</li>
<li><a href="#020101"> Apartado 2.1.1</a>: Multiplicar dos n&uacute;meros de 4 cifras que teclee el usuario, usando el modificador "long".</li>
<li>Apartado 2.1.3a (Sin resolver todav&iacute;a): Crea un programa que te diga cuántos bytes son 3 megabytes.</li>
<li>Apartado 2.1.8a (Sin resolver todav&iacute;a): Crea un programa en C que exprese en el sistema decimal los números octales 162, 76, 241, 102.</li>
<li>Apartado 2.1.8b (Sin resolver todav&iacute;a): Crea un programa en C que exprese en el sistema decimal los números hexadecimales 1B2, 76, E1, 2A.</li>
<li><a href="#020110a"> Apartado 2.1.10a</a>: Crear un programa que use tres variables x,y,z. Sus valores iniciales ser&aacute;n 15, -10, 2.147.483.647. Se deber&aacute; incrementar el valor de estas variables. &iquest;Qu&eacute; valores esperas que se obtengan? Contr&aacute;stalo con el resultado obtenido por el programa.</li>
<li><a href="#020110b"> Apartado 2.1.10b</a>: &iquest;Cu&aacute;l ser&iacute;a el resultado de las siguientes operaciones?  a=5; b=++a; c=a++; b=b*5; a=a*2;</li>
<li><a href="#020111a"> Apartado 2.1.11a</a>: Crear un programa que use tres variables x,y,z. Sus valores iniciales ser&aacute;n 15, -10, 214. Se deber&aacute; incrementar el valor de estas variables en 12, usando el formato abreviado. &iquest;Qu&eacute; valores esperas que se obtengan? Contr&aacute;stalo con el resultado obtenido por el programa.</li>
<li><a href="#020111b"> Apartado 2.1.11b</a>: &iquest;Cu&aacute;l ser&iacute;a el resultado de las siguientes operaciones?  a=5; b=a+2; b-=3; c=-3; c*=2; ++c; a*=b;</li>
<li><a href="#020202a"> Apartado 2.2.02a</a>: El usuario de nuestro programa podr&aacute; teclear dos n&uacute;meros de hasta 8 cifras significativas. El programa deber&aacute; mostrar el resultado de dividir el primer n&uacute;mero entre el segundo, utilizando tres cifras decimales.</li>
<li><a href="#020202b"> Apartado 2.2.02b</a>: Crear un programa que use tres variables x,y,z. Las tres ser&aacute;n n&uacute;meros reales, y nos bastar&aacute; con dos cifras decimales. Deber&aacute; pedir al usuario los valores para las tres variables y mostrar en pantalla cual es el mayor de los tres n&uacute;meros tecleados.</li>
<li><a href="#0203"> Apartado 2.3</a>: Descubrir cual es el espacio ocupado por un "int" en el sistema operativo y compilador que utilizas.</li>
<li><a href="#020501"> Apartado 2.5.1</a>: Crear un programa que pida al usuario que teclee cuatro letras y las muestre en pantalla juntas, pero en orden inverso, y entre comillas dobles. Por ejemplo si las letras que se teclean son a, l, o, h, escribir&iacute;a &quot;hola&quot;.</li>
<li><a href="#030101a"> Apartado 3.1.1a</a>: Crear un programa que pida al usuario un n&uacute;mero entero y diga si es par (pista: habr&aacute; que comprobar si el resto que se obtiene al dividir entre dos es cero: if (x % 2 == 0) ...</li>
<li>Apartado 3.1.1b (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario dos n&uacute;meros enteros y diga cual es el mayor de ellos.</li>
<li>Apartado 3.1.1c (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario dos n&uacute;meros enteros y diga si el primero es m&uacute;ltiplo del segundo (pista: igual que antes, habr&aacute; que ver si el resto de la divisi&oacute;n es cero: a % b == 0).</li>
<li>Apartado 3.1.3a (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que multiplique dos n&uacute;meros enteros de la siguiente forma: pedir&aacute; al usuario un primer n&uacute;mero entero. Si el n&uacute;mero que se que teclee es 0, escribir&aacute; en pantalla "El producto de 0 por cualquier n&uacute;mero es 0". Si se ha tecleado un n&uacute;mero distinto de cero, se pedir&aacute; al usuario un segundo n&uacute;mero y se mostrar&aacute; el producto de ambos.</li>
<li><a href="#030103b"> Apartado 3.1.3b</a>: Crear un programa que pida al usuario dos n&uacute;meros reales. Si el segundo no es cero, mostrar&aacute; el resultado de dividir entre el primero y el segundo. Por el contrario, si el segundo n&uacute;mero es cero, escribir&aacute; &quot;Error: No se puede dividir entre cero&quot;.</li>
<li>Apartado 3.1.4a (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que multiplique dos n&uacute;meros enteros de la siguiente forma: pedir&aacute; al usuario un primer n&uacute;mero entero. Si el n&uacute;mero que se que teclee es 0, escribir&aacute; en pantalla "El producto de 0 por cualquier n&uacute;mero es 0". Si se ha tecleado un n&uacute;mero distinto de cero, se pedir&aacute; al usuario un segundo n&uacute;mero y se mostrar&aacute; el producto de ambos. (Variante con &quot;else&quot;)</li>
<li><a href="#030104b"> Apartado 3.1.4b</a>: Crear un programa que pida al usuario dos n&uacute;meros reales. Si el segundo no es cero, mostrar&aacute; el resultado de dividir entre el primero y el segundo. Por el contrario, si el segundo n&uacute;mero es cero, escribir&aacute; &quot;Error: No se puede dividir entre cero&quot;. (Variante con &quot;else&quot;)</li>
<li><a href="#030105a"> Apartado 3.1.5a</a>: Crear un programa que pida una letra al usuario y diga si se trata de una vocal.</li>
<li>Apartado 3.1.5b (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario dos n&uacute;meros enteros y diga "Uno de los n&uacute;meros es positivo", "Los dos n&uacute;meros son positivos" o bien "Ninguno de los n&uacute;meros es positivo", seg&uacute;n corresponda.</li>
<li>Apartado 3.1.5c (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario tres n&uacute;meros reales y muestre cu&aacute;l es el mayor de los tres.</li>
<li>Apartado 3.1.5d (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario dos n&uacute;meros enteros cortos y diga si son iguales o, en caso contrario, cu&aacute;l es el mayor de ellos.</li>
<li>Apartado 3.1.9a (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que use el operador condicional para mostrar un el valor absoluto de un n&uacute;mero de la siguiente forma: si el n&uacute;mero es positivo, se mostrar&aacute; tal cual; si es negativo, se mostrar&aacute; cambiado de signo.</li>
<li>Apartado 3.1.9b (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que use el operador condicional para dar a una variable llamada "iguales" (entera) el valor 1 si los dos n&uacute;meros que ha tecleado el usuario son iguales, o el valor 0 si son distintos.</li>
<li><a href="#030109c"> Apartado 3.1.9c</a>: Usar el operador condicional para calcular el mayor de dos n&uacute;meros.</li>
<li>Apartado 3.2.1a (Sin resolver todav&iacute;a): Crear un programa que pida al usuario su contrase&ntilde;a (num&eacute;rica). Deber&aacute; terminar cuando introduzca como contrase&ntilde;a el n&uacute;mero 4567, pero volv&eacute;rsela a pedir tantas veces como sea necesario.</li>
<li>Apartado 3.2.1b (Sin resolver todav&iacute;a): Crea un programa que escriba en pantalla los n&uacute;meros del 1 al 10, usando "while".</li>
<li>Apartado 3.2.1c (Sin resolver todav&iacute;a): Crea un programa que escriba en pantalla los n&uacute;meros pares del 26 al 10 (descendiendo), usando "while".</li>
<li><a href="#030201d"> Apartado 3.2.1d</a>: Crear un programa calcule cuantas cifras tiene un n&uacute;mero entero positivo (pista: se puede hacer dividiendo varias veces entre 10).</li>
<li>Apartado 3.2.2a (Sin resolver todav&iacute;a): Crear un programa que pida n&uacute;meros positivos al usuario, y vaya calculando la suma de todos ellos (terminar&aacute; cuando se teclea un n&uacute;mero negativo o cero).</li>
<li>Apartado 3.2.2b (Sin resolver todav&iacute;a): Crea un programa que escriba en pantalla los n&uacute;meros del 1 al 10, usando &quot;do..while&quot;.</li>
<li>Apartado 3.2.2c (Sin resolver todav&iacute;a): Crea un programa que escriba en pantalla los n&uacute;meros pares del 26 al 10 (descendiendo), usando &quot;do..while&quot;.</li>
<li>Apartado 3.2.2d (Sin resolver todav&iacute;a): Crea un programa que pida al usuario su c&oacute;digo de usuario (un n&uacute;mero entero) y su contrase&ntilde;a num&eacute;rica (otro n&uacute;mero entero), y no le permita seguir hasta que introduzca como c&oacute;digo 1024 y como contrase&ntilde;a 4567.</li>
<li>Apartado 3.2.3a (Sin resolver todav&iacute;a): Crear un programa que muestre los n&uacute;meros del 15 al 5, descendiendo (pista: en cada pasada habr&aacute; que descontar 1, por ejemplo haciendo i--).</li>
<li>Apartado 3.2.3b (Sin resolver todav&iacute;a): Crear un programa que muestre los primeros ocho n&uacute;meros pares (pista: en cada pasada habr&aacute; que aumentar de 2 en 2, o bien mostrar el doble del valor que hace de contador).</li>
<li>Apartado 3.2.3c (Sin resolver todav&iacute;a): Crear un programa que muestre las letras de la Z (may&uacute;scula) a la A (may&uacute;scula, descendiendo).</li>
<li>Apartado 3.2.3d (Sin resolver todav&iacute;a): Crear un programa que escriba en pantalla la tabla de multiplicar del 6.</li>
<li>Apartado 3.2.3e (Sin resolver todav&iacute;a): Crear un programa que escriba en pantalla los n&uacute;meros del 1 al 50 que sean m&uacute;ltiplos de 3 (pista: habr&aacute; que recorrer todos esos n&uacute;meros y ver si el resto de la divisi&oacute;n entre 3 resulta 0).</li>
<li>Apartado 3.3a (Sin resolver todav&iacute;a): Crear un programa que pida un número al usuario (entre 1 y 100) y muestre tantas letras A como indique ese número, usando "break" para terminar.</li>
<li>Apartado 3.4a (Sin resolver todav&iacute;a): Crear un programa que pida un número al usuario (entre 1 y 20) y muestre los números el 1 al 20, excepto el indicado por el usuario, usando "continue" para evitar ese valor.</li>
<li>Apartado 3.7a (Sin resolver todav&iacute;a): Crear un programa que d&eacute; al usuario la oportunidad de adivinar un n&uacute;mero del 1 al 100 (prefijado en el programa) en un m&aacute;ximo de 6 intentos. En cada pasada deber&aacute; avisar de si se ha pasado o se ha quedado corto.</li>
<li>Apartado 3.7b (Sin resolver todav&iacute;a): Crear un programa que descomponga un n&uacute;mero (que teclee el usuario) como producto de sus factores primos. Por ejemplo, 60 = 2 &bull; 2 &bull; 3 &bull; 5</li>
<li>Apartado 4.1a (Sin resolver todav&iacute;a): Un programa que pida al usuario un n&uacute;mero entero y muestre sus equivalentes en formato hexadecimal y en octal. Deber&aacute; seguir pidiendo (y convirtiendo) n&uacute;meros hasta que se introduzca 0.</li>
<li>Apartado 4.1b (Sin resolver todav&iacute;a): Un programa que pida al usuario 2 n&uacute;meros reales y muestre su divisi&oacute;n con 2 decimales (excepto si el segundo es 0; en ese caso, deber&aacute; decir "no se puede dividir").</li>
<li>Apartado 4.2a (Sin resolver todav&iacute;a): Un programa que pida al usuario un n&uacute;mero hexadecimal y muestre su equivalente en base 10. </li>
<li>Apartado 4.2b (Sin resolver todav&iacute;a): Un programa que pida al usuario un n&uacute;mero octal y muestre su equivalente en base 10. </li>
<li>Apartado 4.2c (Sin resolver todav&iacute;a): Un programa que pida al usuario una letra, despu&eacute;s le pida una segunda letra, y las muestre en el orden contrario al que se introdujeron. </li>
<li>Apartado 4.3 (Sin resolver todav&iacute;a): Un programa que escriba las letras de la A (a may&uacute;scula) a la Z (z may&uacute;scula), usando "for" y "putchar".</li>
<li>Apartado 4.4 (Sin resolver todav&iacute;a): Un programa que pida al usuario 4 letras (usando "getchar") y las muestre en orden inverso (por ejemplo, si las letras son "h o l a", escribir&iacute;a "aloh").</li>
<li><a href="#050101a"> Apartado 5.1.1a</a>: Un programa que pida al usuario 4 n&uacute;meros, los memorice (utilizando una tabla), calcule su media aritm&eacute;tica y despu&eacute;s muestre en pantalla la media y los datos tecleados.</li>
<li><a href="#_050101b"> Apartado 5.1.1b</a>: Un programa que pida al usuario 5 n&uacute;meros reales y luego los muestre en el orden contrario al que se introdujeron.</li>
<li><a href="#050102a"> Apartado 5.1.2a</a>: Un programa que almacene en una tabla el n&uacute;mero de d&iacute;as que tiene cada mes (supondremos que es un a&ntilde;o no bisiesto), pida al usuario que le indique un mes (1=enero, 12=diciembre) y muestre en pantalla el n&uacute;mero de d&iacute;as que tiene ese mes.</li>
<li>Apartado 5.1.2b (Queda propuesto, por ser muy parecido a otros ya resueltos): Un programa que almacene en una tabla el n&uacute;mero de d&iacute;as que tiene cada mes (a&ntilde;o no bisiesto), pida al usuario que le indique un mes (ej. 2 para febrero) y un d&iacute;a (ej. el d&iacute;a 15) y diga qu&eacute; n&uacute;mero de d&iacute;a es dentro del a&ntilde;o (por ejemplo, el 15 de febrero ser&iacute;a el d&iacute;a n&uacute;mero 46, el 31 de diciembre ser&iacute;a el d&iacute;a 365).</li>
<li>Apartado 5.1.3a (Sin resolver todav&iacute;a): A partir del programa propuesto en 5.1.2, que almacenaba en una tabla el n&uacute;mero de d&iacute;as que tiene cada mes, crear otro que pida al usuario que le indique la fecha, detallando el d&iacute;a (1 al 31) y el mes (1=enero, 12=diciembre), como respuesta muestre en pantalla el n&uacute;mero de d&iacute;as que quedan hasta final de a&ntilde;o.</li>
<li><a href="#050103b"> Apartado 5.1.3b</a>: Crear un programa que pida al usuario 10 n&uacute;meros y luego los muestre en orden inverso (del &uacute;ltimo al primero).</li>
<li>Apartado 5.1.3c (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario 10 n&uacute;meros, calcule su media y luego muestre los que est&aacute;n por encima de la media.</li>
<li>Apartado 5.1.3d (Sin resolver todav&iacute;a): Un programa que pida al usuario 10 n&uacute;meros enteros y calcule (y muestre) cu&aacute;l es el mayor de ellos.</li>
<li><a href="#050201a"> Apartado 5.2.1a</a>: Un programa que te pida tu nombre y una cifra numérica, y escriba tu nombre tantas veces como indique esa cifra numérica.</li>
<li><a href="#050201b"> Apartado 5.2.1b</a>: Un programa similar al anterior, pero que pida en primer lugar la cifra numérica y después tu nombre, y luego escriba el nombre tantas veces como indique esa cifra numérica.</li>
<li>Apartado 5.2.2 (Sin resolver todav&iacute;a): Un programa que pida al usuario que introduzca una palabra, cambie su primera letra por una "A" y muestre la palabra resultante.</li>
<li><a href="#050203a"> Apartado 5.2.3a</a>: Un programa que te pida tu nombre y lo muestre en pantalla separando cada letra de la siguiente con un espacio. Por ejemplo, si tu nombre es "Juan", deber&iacute;a aparecer en pantalla "J u a n".</li>
<li>Apartado 5.2.3b (Queda propuesto, por ser muy parecido a otros ya resueltos): Un programa que te pida tu nombre y lo muestre en pantalla separando al rev&eacute;s. Por ejemplo, si tu nombre es "Juan", deber&iacute;a aparecer en pantalla "nauJ".</li>
<li><a href="#050204a"> Apartado 5.2.4a</a>: Un programa que te pida una frase y la muestre en pantalla sin espacios. Por ejemplo, si la frase es "Hola, como est&aacute;s", deber&iacute;a aparecer en pantalla "Hola,comoest&aacute;s".</li>
<li><a href="#050204b"> Apartado 5.2.4b</a>: Un programa que te pida tu nombre (usando "gets") y una cifra numérica, y escriba tu nombre tantas veces como indique esa cifra numérica.</li>
<li><a href="#050204c"> Apartado 5.2.4c</a>: Un programa similar al anterior, pero que pida en primer lugar la cifra numérica y después tu nombre (con "gets"), y luego escriba el nombre tantas veces como indique esa cifra numérica.</li>
<li>Apartado 5.2.5 (Sin resolver todav&iacute;a): Un programa que te pida una palabra, y la almacene en la variable llamada "texto". Luego deber&aacute; pedir una segunda palabra, y a&ntilde;adirla al final de "texto". Finalmente, deber&aacute; pedir una tercera palabra, y guardarla en la variable "texto" y en otra variable llamada "texto2".</li>
<li><a href="#050206a"> Apartado 5.2.6a</a>: Crear un programa que pida al usuario su contrase&ntilde;a. Deber&aacute; terminar cuando introduzca como contrase&ntilde;a la palabra &quot;clave&quot;, pero volv&eacute;rsela a pedir tantas veces como sea necesario.</li>
<li>Apartado 5.2.6b (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear un programa que pida al usuario su nombre y su contrase&ntilde;a, y no le permita seguir hasta que introduzca como nombre &quot;Pedro&quot; y como contrase&ntilde;a &quot;Peter&quot;.</li>
<li>Apartado 5.2.7 (Sin resolver todav&iacute;a): Un programa que pida tu nombre, tu d&iacute;a de nacimiento y tu mes de nacimiento y lo junte todo en una cadena, separando el nombre de la fecha por una coma y el d&iacute;a del mes por una barra inclinada, as&iacute;: "Juan, nacido el 31/12".</li>
<li><a href="#0503a"> Apartado 5.3a</a>: Un programa guarde los nombres de los meses. El usuario deber&aacute; indicar un n&uacute;mero de mes (por ejemplo, 3) y se le mostrar&aacute; el nombre de dicho mes (por ejemplo, Marzo).</li>
<li>Apartado 5.3b (Sin resolver todav&iacute;a): Usar un array de 3 dimensiones para guardar los nombres de los meses en espa&ntilde;ol e ingl&eacute;s. El usuario deber&aacute; indicar un n&uacute;mero de mes (por ejemplo, 3) y se le mostrar&aacute; el nombre de dicho mes en espa&ntilde;ol (Marzo) y en ingl&eacute;s (March).</li>
<li><a href="#0504a"> Apartado 5.4a</a>: Un programa que pida 10 nombres y los memorice. Después deberá pedir que se teclee un nombre y dirá si se encuentra o no entre los 10 que se han tecleado antes. Volverá  a pedir otro nombre y a decir si se encuentra entre ellos, y así sucesivamente hasta que se teclee "fin".</li>
<li>Apartado 5.4b (Sin resolver todav&iacute;a): Un programa que prepare espacio para un máximo de 100 nombres (de un máximo de 80 letras cada uno). El usuario deberá ir introduciendo un nombre cada vez, hasta que se pulse Intro sin teclear nada, momento en el que dejarán de pedirse más nombres y se mostrará en pantalla la lista de los nombres que se han introducido hasta entonces.</li>
<li>Apartado 5.5.1 (Sin resolver todav&iacute;a): Un "struct" que almacene datos de una canci&oacute;n en formato MP3: Artista, T&iacute;tulo, Duraci&oacute;n (en segundos), Tama&ntilde;o del fichero (en KB). Un programa debe pedir los datos de una canci&oacute;n al usuario, almacenarlos en dicho "struct" y despu&eacute;s mostrarlos en pantalla.</li>
<li>Apartado 5.5.2a (Queda propuesto, por ser muy parecido a otros ya resueltos): Ampliar el programa del apartado 5.5.1, para que almacene datos de hasta 100 canciones. Deber&aacute; tener un men&uacute; que permita las opciones: a&ntilde;adir una nueva canci&oacute;n, mostrar el t&iacute;tulo de todas las canciones, buscar la canci&oacute;n que contenga un cierto texto (en el artista o en el t&iacute;tulo).</li>
<li><a href="#050502b"> Apartado 5.5.2b</a>: Un programa que permita guardar datos de &quot;im&aacute;genes&quot; (ficheros de ordenador que contengan fotograf&iacute;as o cualquier otro tipo de informaci&oacute;n gr&aacute;fica). De cada imagen se debe guardar: nombre (texto), ancho en p&iacute;xeles (por ejemplo 2000), alto en p&iacute;xeles (por ejemplo, 3000), tama&ntilde;o en Kb (por ejemplo 145,6). El programa debe ser capaz de almacenar hasta 700 im&aacute;genes (deber&aacute; avisar cuando su capacidad est&eacute; llena). Debe permitir las opciones: a&ntilde;adir una ficha nueva, ver todas las fichas (n&uacute;mero y nombre de cada imagen), buscar la ficha que tenga un cierto nombre.</li>
<li>Apartado 5.5.3 (Sin resolver todav&iacute;a): Ampliar el programa del apartado 5.5.2, para que el campo "duraci&oacute;n" se almacene como minutos y segundos, usando un "struct" anidado que contenga a su vez estos dos campos.</li>
<li>Apartado 5.6a (Sin resolver todav&iacute;a): Un programa que pida el nombre, el apellido y la edad de una persona, los almacene en un "struct" y luego muestre los tres datos en una misma l&iacute;nea, separados por comas.</li>
<li>Apartado 5.6b (Sin resolver todav&iacute;a): Un programa que pida datos de 8 personas: nombre, dia de nacimiento, mes de nacimiento, y a&ntilde;o de nacimiento (que se deben almacenar en una tabla de structs). Despu&eacute;s deber&aacute; repetir lo siguiente: preguntar un n&uacute;mero de mes y mostrar en pantalla los datos de las personas que cumplan los a&ntilde;os durante ese mes. Terminar&aacute; de repetirse cuando se teclee 0 como n&uacute;mero de mes.</li>
<li>Apartado 5.6c (Sin resolver todav&iacute;a): Un programa que sea capaz de almacenar los datos de hasta 50 personas: nombre, direcci&oacute;n, tel&eacute;fono, edad (usando una tabla de structs). Deber&aacute; ir pidiendo los datos uno por uno, hasta que un nombre se introduzca vac&iacute;o (se pulse Intro sin teclear nada). Entonces deber&aacute; aparecer un men&uacute; que permita: Mostrar la lista de todos los nombres; Mostrar las personas de una cierta edad; Mostrar las personas cuya inicial sea la que el usuario indique; Salir del programa (l&oacute;gicamente, este men&uacute; debe repetirse hasta que se escoja la opci&oacute;n de "salir").</li>
<li>Apartado 5.6d (Sin resolver todav&iacute;a): Mejorar la base de datos de ficheros (ejemplo 53) para que no permita introducir tama&ntilde;os incorrectos (n&uacute;meros negativos) ni nombres de fichero vac&iacute;os.</li>
<li>Apartado 5.6e (Sin resolver todav&iacute;a): Ampliar la base de datos de ficheros (ejemplo 53) para que incluya una opci&oacute;n de b&uacute;squeda parcial, en la que el usuario indique parte del nombre y se muestre todos los ficheros que contienen ese fragmento (usando "strstr").</li>
<li>Apartado 5.6f (Sin resolver todav&iacute;a): Ampliar la base de datos de ficheros (ejemplo 53) para que se pueda borrar un cierto dato (habr&aacute; que "mover hacia atr&aacute;s" todos los datos que hab&iacute;a despu&eacute;s de ese, y disminuir el contador de la cantidad de datos que tenemos).</li>
<li>Apartado 5.6g (Sin resolver todav&iacute;a): Mejorar la base de datos de ficheros (ejemplo 53) para que se pueda modificar un cierto dato a partir de su n&uacute;mero (por ejemplo, el dato n&uacute;mero 3). En esa modificaci&oacute;n, se deber&aacute; permitir al usuario pulsar Intro sin teclear nada, para indicar que no desea modificar un cierto dato, en vez de reemplazarlo por una cadena vac&iacute;a.</li>
<li>Apartado 5.6h (Sin resolver todav&iacute;a): Ampliar la base de datos de ficheros (ejemplo 53) para que se permita ordenar los datos por nombre. Para ello, deber&aacute;s buscar informaci&oacute;n sobre alg&uacute;n m&eacute;todo de ordenaci&oacute;n sencillo, como el &quot;m&eacute;todo de burbuja&quot;, y aplicarlo a este caso concreto.</li>
<li>Apartado 5.7 (Sin resolver todav&iacute;a): Un programa que cree un array de 7 n&uacute;meros enteros y lo ordene con cada uno de estos tres m&eacute;todos, mostrando el resultado de los pasos intermedios.</li>
<li><a href="#0601a"> Apartado 6.1</a>: Crea un programa que vaya leyendo las frases que el usuario teclea y las guarde en un fichero de texto. Terminar&aacute; cuando la frase introducida sea "fin" (esa frase no deber&aacute; guardarse en el fichero).</li>
<li>Apartado 6.2 (Sin resolver todav&iacute;a): Crea un programa que lea las tres primeras l&iacute;neas del fichero creado en el apartado anterior y las muestre en pantalla. Si el fichero no existe, se deber&aacute; mostrar un aviso.</li>
<li>Apartado 6.3a (Sin resolver todav&iacute;a): Un programa que pida al usuario que teclee frases, y las almacene en el fichero "frases.txt". Acabar&aacute; cuando el usuario pulse Intro sin teclear nada. Despu&eacute;s deber&aacute; mostrar el contenido del fichero.</li>
<li>Apartado 6.3b (Sin resolver todav&iacute;a): Un programa que pregunte un nombre de fichero y muestre en pantalla el contenido de ese fichero, haciendo una pausa despu&eacute;s de cada 25 l&iacute;neas, para que d&eacute; tiempo a leerlo. Cuando el usuario pulse intro, se mostrar&aacute;n las siguientes 25 l&iacute;neas, y as&iacute; hasta que termine el fichero. (Pista: puedes usar un contador, volverlo a poner a cero tras cada 25 l&iacute;neas o bien comprobar si has avanzado otras 25 l&iacute;neas usando la operaci&oacute;n "resto de la divisi&oacute;n", y hacer la pausa con "getchar()").</li>
<li>Apartado 6.4a (Sin resolver todav&iacute;a): Crear un "struct" que almacene los siguientes datos de una persona: nombre, edad, ciudad de residencia. Pedir al usuario esos datos de una persona y guardarlos en un fichero llamado "gente.dat". Cerrar el fichero, volverlo a abrir para lectura y mostrar los datos que se hab&iacute;an guardado.</li>
<li>Apartado 6.4b (Sin resolver todav&iacute;a): Ampliar el programa anterior para que use un "array de structs", de forma que se puedan tener datos de 10 personas. Se deber&aacute; pedir al usuario los datos de las 10 personas y guardarlos en el fichero. Despu&eacute;s se pedir&aacute; al usuario un n&uacute;mero del 1 al 10 y se mostrar&aacute;n los datos de la persona indicada por ese n&uacute;mero, que se deber&aacute;n leer de fichero (1 ser&aacute; la primera ficha, y 10 ser&aacute; la &uacute;ltima). Por ejemplo, si el usuario indica que quiere ver los datos de la persona 3 (tercera), se deber&aacute; leer las dos primeras, ignorando su contenido, y despu&eacute;s leer la tercera, que s&iacute; se deber&aacute; mostrar. </li>
<li><a href="#0604c"> Apartado 6.4c</a>: Una agenda que maneje los siguientes datos: nombre, direcci&oacute;n, tlf m&oacute;vil, email, y d&iacute;a, mes y a&ntilde;o de nacimiento (estos tres &uacute;ltimos datos deber&aacute;n ser n&uacute;meros enteros cortos). Deber&aacute; tener capacidad para 100 fichas. Se deber&aacute; poder a&ntilde;adir un dato nuevo, visualizar los nombres de las fichas existentes, o mostrar todos los datos de una persona (se preguntar&aacute; al usuario cual es el nombre de esa persona que quiere visualizar). Al empezar el programa, leer&aacute; los datos de un fichero llamado "agenda.dat" (si existe). Al terminar, guardar&aacute; todos los datos en ese fichero. </li>
<li>Apartado 6.6a (Sin resolver todav&iacute;a): Un programa que pida al usuario que teclee frases, y las almacene en el fichero "registro.txt", que puede existir anteriormente (y que no deber&aacute; borrarse, sino a&ntilde;adir al final de su contenido). Cada sesi&oacute;n acabar&aacute; cuando el usuario pulse Intro sin teclear nada. </li>
<li>Apartado 6.6b (Sin resolver todav&iacute;a): Crear un programa que pida al usuario pares de n&uacute;meros enteros y escriba su suma (con el formato "20 + 3 = 23") en pantalla y en un fichero llamado "sumas.txt", que se encontrar&aacute; en un subdirectorio llamado "resultados". Cada vez que se ejecute el programa, deber&aacute; a&ntilde;adir los nuevos resultados a continuaci&oacute;n de los resultados de las ejecuciones anteriores.</li>
<li>Apartado 6.8a (Sin resolver todav&iacute;a): Crear un "struct" que almacene los siguientes datos de una persona: nombre, edad, ciudad de residencia. Pedir al usuario esos datos de una persona y guardarlos en un fichero llamado "gente.dat", usando "fwrite". Cerrar el fichero, volverlo a abrir para lectura y mostrar los datos que se hab&iacute;an guardado, que se deben leer con "fread".</li>
<li>Apartado 6.8b (Sin resolver todav&iacute;a): Ampliar el programa anterior para que use un "array de structs", de forma que se puedan tener datos de 10 personas. Se deber&aacute; pedir al usuario los datos de las 10 personas y guardarlos en el fichero, usando "fwrite". Despu&eacute;s se pedir&aacute; al usuario un n&uacute;mero del 1 al 10 y se mostrar&aacute;n los datos de la persona indicada por ese n&uacute;mero, que se deber&aacute;n leer de fichero (1 ser&aacute; la primera ficha, y 10 ser&aacute; la &uacute;ltima). Por ejemplo, si el usuario indica que quiere ver los datos de la persona 3 (tercera), se deber&aacute; leer las dos primeras (con "fread"), ignorando su contenido, y despu&eacute;s leer la tercera, que s&iacute; se deber&aacute; mostrar.</li>
<li>Apartado 6.8c (Sin resolver todav&iacute;a): Mejorar la agenda anterior (del apartado 6.4), para guardar y leer cada "ficha" (struct) de una vez, usando fwrite/fread y sizeof, como en el &uacute;ltimo ejemplo. </li>
<li>Apartado 6.9a (Sin resolver todav&iacute;a): Ampliar el programa anterior (el "array de structs" con 10 personas) para que el dato que indique el usuario se lea sin leer y descartar antes los que le preceden, sino que se salte directamente a la ficha deseada usando "fseek".</li>
<li>Apartado 6.10a (Sin resolver todav&iacute;a): Mejorar la &uacute;ltima versi&oacute;n de la agenda anterior (la que usa fwrite, fread y sizeof) para que no lea todas las fichas a la vez, sino que lea una &uacute;nica ficha del disco cada vez que lo necesite, saltando a la posici&oacute;n en que se encuentra dicha ficha con "fseek".</li>
<li>Apartado 6.10b (Sin resolver todav&iacute;a): Hacer un programa que muestre informaci&oacute;n sobre una imagen en formato GIF (se deber&aacute; localizar en Internet los detalles sobre dicho formato): versi&oacute;n, ancho de la imagen (en p&iacute;xeles), alto de la imagen y cantidad de colores.</li>
<li>Apartado 6.10c (Sin resolver todav&iacute;a): Hacer un programa que muestre informaci&oacute;n sobre una imagen en formato PCX: ancho de la imagen (en p&iacute;xeles), alto de la imagen y cantidad de colores.</li>
<li>Apartado 6.10d (Sin resolver todav&iacute;a): Mejorar la base de datos de ficheros (ejemplo 53) para que los datos se guarden en disco al terminar la sesi&oacute;n de uso, y se lean de disco cuando comienza una nueva sesi&oacute;n.</li>
<li>Apartado 6.10e (Sin resolver todav&iacute;a): Mejorar la base de datos de ficheros (ejemplo 53) para que cada dato introducido se guarde inmediatamente en disco, sin esperar a que termine la sesi&oacute;n de uso. En vez de emplear un "array de structs", debe existir un solo "struct" en memoria cada vez, y para las b&uacute;squedas se recorra todo el contenido del fichero.</li>
<li>Apartado 6.10f (Sin resolver todav&iacute;a): Mejorar el ejercicio anterior (ejemplo 53 ampliado con ficheros, que se manejan ficha a ficha) para que se pueda modificar un cierto dato a partir de su n&uacute;mero (por ejemplo, el dato n&uacute;mero 3). En esa modificaci&oacute;n, se deber&aacute; permitir al usuario pulsar Intro sin teclear nada, para indicar que no desea modificar un cierto dato, en vez de reemplazarlo por una cadena vac&iacute;a. </li>
<li>Apartado 6.14a (Sin resolver todav&iacute;a): Pedir al usuario dos números y la operación (suma o resta) a realizar con ellos, y mostrar el resultado de dicha operación. Utilizar "fgets" y "sscanf" para la lectura de teclado.</li>
<li><a href="#0704a"> Apartado 7.4a</a>: Crear una funci&oacute;n que calcule el cubo de un n&uacute;mero real (float). El resultado deber&aacute; ser otro n&uacute;mero real. Probar esta funci&oacute;n para calcular el cubo de 3.2 y el de 5.</li>
<li><a href="#0704b"> Apartado 7.4b</a>: Crear una funci&oacute;n que calcule cual es el menor de dos n&uacute;meros enteros. El resultado ser&aacute; otro n&uacute;mero entero.</li>
<li><a href="#0704c"> Apartado 7.4c</a>: Crear una funci&oacute;n llamada "signo", que reciba un n&uacute;mero real, y devuelva un n&uacute;mero entero con el valor: -1 si el n&uacute;mero es negativo, 1 si es positivo o 0 si es cero.</li>
<li><a href="#0704d"> Apartado 7.4d</a>: Crear una funci&oacute;n que devuelva la primera letra de una cadena de texto. Probar esta funci&oacute;n para calcular la primera letra de la frase "Hola"</li>
<li>Apartado 7.4e (Queda propuesto, por ser muy parecido a otros ya resueltos): Crear una funci&oacute;n que devuelva la &uacute;ltima letra de una cadena de texto. Probar esta funci&oacute;n para calcular la &uacute;ltima letra de la frase "Hola".</li>
<li>Apartado 7.5a (Sin resolver todav&iacute;a): Crear una función "escribirGuiones" que escriba en pantalla tantos guiones ("-") como se indique como parámetro y no devuelva ningún valor.</li>
<li>Apartado 7.5b (Sin resolver todav&iacute;a): Crear una función "dibujarRectangulo", que reciba como parámetros la anchura y la altura del rectángulo a mostrar, y muestre en pantalla un rectángulo de ese tamaño, relleno de caracteres "#".</li>
<li><a href="#0705a"> Apartado 7.5c</a>: Crear una funci&oacute;n que borre la pantalla dibujando 25 l&iacute;neas en blanco. No debe devolver ning&uacute;n valor.</li>
<li>Apartado 7.5d (Sin resolver todav&iacute;a): Crear una funci&oacute;n que reciba un n&uacute;mero y muestre en pantalla el per&iacute;metro y la superficie de un cuadrado que tenga como lado el n&uacute;mero que se ha indicado como par&aacute;metro.</li>
<li>Apartado 7.5e (Sin resolver todav&iacute;a): Crear una función "escribirCentrado" que reciba un texto y lo escriba centrado en la siguiente línea de pantalla (suponiendo 80 columnas en pantalla). Por ejemplo, si el texto es "Hola", que tiene 4 letras, se escribirán 38 espacios antes de él.</li>
<li>Apartado 7.6a (Sin resolver todav&iacute;a): Crear una funci&oacute;n "pedirEntero", que reciba como par&aacute;metros el texto que se debe mostrar en pantalla, el valor m&iacute;nimo aceptable y el valor m&aacute;ximo aceptable. Deber&aacute; pedir al usuario que introduzca el valor tantas veces como sea necesario, volv&eacute;rselo a pedir en caso de error, y devolver un valor correcto. Probarlo con un programa que pida al usuario un a&ntilde;o entre 1800 y 2100.</li>
<li>Apartado 7.6b (Sin resolver todav&iacute;a): Crear una funci&oacute;n "escribirTablaMultiplicar", que reciba como par&aacute;metro un n&uacute;mero entero, y escriba la tabla de multiplicar de ese n&uacute;mero (por ejemplo, para el 3 deber&aacute; llegar desde 3x0=0 hasta 3x10=30).</li>
<li>Apartado 7.6c (Sin resolver todav&iacute;a): Crear una funci&oacute;n "esPrimo", que reciba un n&uacute;mero y devuelva el valor 1 si es un n&uacute;mero primo o 0 en caso contrario.</li>
<li>Apartado 7.6d (Sin resolver todav&iacute;a): Crear una funci&oacute;n que reciba una cadena y una letra, y devuelva la cantidad de veces que dicha letra aparece en la cadena. Por ejemplo, si la cadena es &quot;Barcelona&quot; y la letra es 'a', deber&iacute;a devolver 2 (aparece 2 veces).</li>
<li>Apartado 7.6e (Sin resolver todav&iacute;a): Crear una funci&oacute;n que reciba un n&uacute;mero cualquiera y que devuelva como resultado la suma de sus d&iacute;gitos. Por ejemplo, si el n&uacute;mero fuera 123 la suma ser&iacute;a 6.</li>
<li>Apartado 7.6f (Sin resolver todav&iacute;a): Crear una funci&oacute;n que reciba una letra y un n&uacute;mero, y escriba un "tri&aacute;ngulo" formado por esa letra, que tenga como anchura inicial la que se ha indicado. Por ejemplo, si la letra es * y la anchura es 4, deber&iacute;a escribir<br />****<br />***<br />**<br />*<br /></li>
<li>Apartado 7.9.1a (Sin resolver todav&iacute;a): Crea un programa que escriba varias veces "Hola" (entre 5 y 10 veces, al azar).</li>
<li>Apartado 7.9.1b (Sin resolver todav&iacute;a): Crear un programa que genere un número al azar entre 1 y 100. El usuario tendrá 6 oportunidades para acertarlo.</li>
<li>Apartado 7.9.1c (Sin resolver todav&iacute;a): Crea un programa que muestre un "fondo estrellado" en pantalla: mostrará 24 líneas, cada una de las cuales contendrá entre 1 y 78 espacios (al azar) seguidos por un asterisco ("*").</li>
<li>Apartado 7.9.2a (Sin resolver todav&iacute;a): Crear un programa que halle cualquier ra&iacute;z de un n&uacute;mero. El usuario deber&aacute; indicar el n&uacute;mero (por ejemplo, 2) y el &iacute;ndice de la raiz (por ejemplo, 3 para la ra&iacute;z c&uacute;bica). Pista: hallar la ra&iacute;z c&uacute;bica de 2 es lo mismo que elevar 2 a 1/3.</li>
<li>Apartado 7.9.2b (Sin resolver todav&iacute;a): Crear un programa que resuelva ecuaciones de segundo grado, del tipo ax2 + bx + c = 0 El usuario deber&aacute; introducir los valores de a, b y c. Pista: la soluci&oacute;n se calcula con  x = +- ra&iacute;z (b2 &ndash; 4&bull;a&bull;c)  / 2&bull;a</li>
<li>Apartado 7.9.2c (Sin resolver todav&iacute;a): Crear un programa que muestre el seno de los ángulos de 30 grados, 45 grados, 60 grados y 90 grados. Cuidado: la función "sin" espera que se le indique el ángulo en radianes, no en grados. Tendrás que recordar que 180 grados es lo mismo que Pi radianes (con Pi = 3,1415926535). Puedes crearte una función auxiliar que convierta de grados a radianes.</li>
<li>Apartado 7.9.3a (Sin resolver todav&iacute;a): Crea un programa que escriba la raíz cuadrada de 10 y muestre la cantidad de cifras que se han escrito en pantalla. (Pista: mira el valor devuelto por "printf").</li>
<li>Apartado 7.10a (Sin resolver todav&iacute;a): Crear una funci&oacute;n que calcule el valor de elevar un n&uacute;mero entero a otro n&uacute;mero entero (por ejemplo, 5 elevado a 3 = 5<sup>3</sup> = 5 &bull;5 &bull; 5 = 125). Esta funci&oacute;n se debe crear de forma recursiva.</li>
<li>Apartado 7.10b (Sin resolver todav&iacute;a): Como alternativa, crear una funci&oacute;n que calcule el valor de elevar un n&uacute;mero entero a otro n&uacute;mero entero de forma NO recursiva (lo que llamaremos "de forma iterativa"), usando la orden "for".</li>
<li>Apartado 7.10c (Sin resolver todav&iacute;a): Crear un programa que emplee recursividad para calcular un número de la serie Fibonacci (en la que los dos primeros elementos valen 1, y para los restantes, cada elemento es la suma de los dos anteriores).</li>
<li>Apartado 7.10d (Sin resolver todav&iacute;a): Crear un programa que emplee recursividad para calcular la suma de los elementos de un vector.</li>
<li>Apartado 7.10e (Sin resolver todav&iacute;a): Crear un programa que emplee recursividad para calcular el mayor de los elementos de un vector.</li>
<li>Apartado 7.10f (Sin resolver todav&iacute;a): Crear un programa que emplee recursividad para dar la vuelta a una cadena de caracteres (por ejemplo, a partir de &quot;Hola&quot; devolver&iacute;a &quot;aloH&quot;).</li>
<li>Apartado 7.10g (Sin resolver todav&iacute;a): Crear, tanto de forma recursiva como de forma iterativa, una funci&oacute;n diga si una cadena de caracteres es sim&eacute;trica (un pal&iacute;ndromo). Por ejemplo, \&quot;DABALEARROZALAZORRAELABAD\&quot; es un pal&iacute;ndromo.</li>
<li>Apartado 7.10h (Sin resolver todav&iacute;a): Crear un programa que encuentre el m&aacute;ximo com&uacute;n divisor de dos n&uacute;meros usando el algoritmo de Euclides: Dados dos n&uacute;meros enteros positivos m y n, tal que m &gt; n, para encontrar su m&aacute;ximo com&uacute;n divisor, es decir, el mayor entero positivo que divide a ambos: - Dividir m por n para obtener el resto r (0 = r &lt; n) ; - Si r = 0, el MCD es n.; - Si no, el m&aacute;ximo com&uacute;n divisor es MCD(n,r).</li>
<li>Apartado 9.5a (Sin resolver todav&iacute;a): Crear una funci&oacute;n que calcule las dos soluciones de una ecuaci&oacute;n de segundo grado (Ax2 + Bx + C = 0) y devuelva las dos soluciones como par&aacute;metros.</li>
<li>Apartado 9.8a (Sin resolver todav&iacute;a): Mejorar la versi&oacute;n de la agenda que le&iacute;a todos los datos al principio de la ejecuci&oacute;n y guardaba todos los datos cuando termin&aacute;bamos su uso (apartado 6.4). Esta nueva versi&oacute;n deber&aacute; estar preparada para manejar hasta 1000 fichas, pero s&oacute;lo reservar&aacute; espacio para las que realmente sean necesarias.</li>
<li>Apartado 9.9a (Sin resolver todav&iacute;a): Crear un programa llamado "suma", que calcule (y muestre) la suma de dos n&uacute;meros que se le indiquen como par&aacute;metro.  Por ejemplo, si se teclea "suma 2 3" deber&aacute; responder "5", y si se teclea "suma 2" deber&aacute; responder "no hay suficientes datos.</li>
<li>Apartado 9.9b (Sin resolver todav&iacute;a): Crear una calculadora b&aacute;sica, llamada "calcula", que deber&aacute; sumar, restar, multiplicar o dividir los dos n&uacute;meros que se le indiquen como par&aacute;metros. Ejemplos de su uso ser&iacute;a "calcula 2 + 3" o "calcula 5 * 60".</li>
<li>Apartado 9.10a (Sin resolver todav&iacute;a): Crea una "pila de enteros", que permitirá añadir un nuevo número (lo que llama¬remos "apilar") o bien extraer el número que se encuentra en la parte más alta de la pila ("desapilar"). En una primera aproximación, usa un array para guardar los datos.</li>
<li>Apartado 9.10b (Sin resolver todav&iacute;a): Crea una nueva versión de la "pila de enteros", que utilice memoria dinámica.</li>
<li>Apartado 9.10c (Sin resolver todav&iacute;a): Crea una "cola de enteros", que permitirá añadir un nuevo número al final de la cola (lo que llama¬remos "encolar") o bien extraer el número que se encuentra al principio de la cola ("desencolar"). En esta primera aproximación, usa un array para guardar los datos.</li>
<li>Apartado 9.10d (Sin resolver todav&iacute;a): Crea una nueva versión de la "cola de enteros", que utilice memoria dinámica.</li>
<li>Apartado 9.10e (Sin resolver todav&iacute;a): Implementa una lista doble enlazada que almacene n&uacute;meros enteros.</li>
<li>Apartado 10.4a (Sin resolver todav&iacute;a): Crea un men&uacute; para MsDos que muestre varias opciones en el centro de la pantalla, y el reloj en la parte superior derecha de la pantalla. Mientras el usuario no pulse una tecla, el reloj debe actualizarse continuamente.</li>
<li>Apartado 10.4b (Sin resolver todav&iacute;a): Crea, tanto para MsDos como para Linux, un "protector de pantalla" que muestre tu nombre rebotando en los laterales de la pantalla. Deber&aacute; avanzar de posici&oacute;n cada segundo.</li>
<li>Apartado 10.5.1a (Sin resolver todav&iacute;a): Crea (o busca en Internet) una imagen de fondo de tama&ntilde;o 800x600 que represente un cielo negro con estrellas, y tres im&aacute;genes de planetas con un tama&ntilde;o menor (cercano a 100x100, por ejemplo). Entra a modo gr&aacute;fico 800x600 con 24 bits de color usando SDL, dibuja la imagen de fondo, y sobre ella, las de los tres planetas. El t&iacute;tulo de la ventana deber&aacute; ser "Planetas". Las im&aacute;genes deber&aacute;n mostrarse durante  7 segundos.</li>
<li>Apartado 10.5.2a (Sin resolver todav&iacute;a): Ampl&iacute;a el ejercicio anterior, a&ntilde;adiendo la imagen de una nave espacial, que deber&aacute; moverse cada vez que el usuario pulse una de las flechas del cursor. Ya no se saldr&aacute; al cabo de varios segundos, sino cuando el usuario pulse la tecla ESC.</li>
<li>Apartado 10.5.3a (Sin resolver todav&iacute;a): Ampl&iacute;a el ejercicio anterior, para que la imagen de la nave espacial tenga el contorno transparente (y quiz&aacute; tambi&eacute;n alguna zona interior).</li>
<li>Apartado 10.5.3b (Sin resolver todav&iacute;a): Crea una imagen que contenga varias letras (al menos H, O, L, A), y &uacute;sala para escribir las frases HOLA y OH en modo gr&aacute;fico con SDL.</li>
<li>Apartado 10.5.4a (Sin resolver todav&iacute;a): Ampl&iacute;a el ejercicio de la nave, para que emplee un doble buffer que permita evitar parpadeos.</li>
<li>Apartado 10.5.5a (Sin resolver todav&iacute;a): Ampl&iacute;a el ejercicio de la nave, para que emplee tenga una funci&oacute;n "buclePrincipal", que siga la apariencia de un bucle de juego cl&aacute;sico, llamando a funciones con los nombres "comprobarTeclas", "dibujarElementos", "moverEstrellas", "mostrarPantallaOculta". Existir&aacute;n algunas estrellas, cuya posici&oacute;n cambiar&aacute; cuando se llame a "moverEstrellas" y que se dibujar&aacute;n, junto con los dem&aacute;s componentes, al llamar a en "dibujarElementos". Al final de cada "pasada" por el bucle principal habr&aacute; una pausa de 20 milisegundos, para que la velocidad del "juego" no dependa del ordenador en que se ejecute.</li>
<li>Apartado 10.5.5b (Sin resolver todav&iacute;a): Ampliar el ejercicio anterior, para que tambi&eacute;n exista un "enemigo" que se mueva de lado a lado de la pantalla.</li>
<li>Apartado 10.5.5c (Sin resolver todav&iacute;a): Ampliar el ejercicio anterior, para que haya 20 "enemigos" (un array) que se muevan de lado a lado de la pantalla.</li>
<li>Apartado 10.5.5d (Sin resolver todav&iacute;a): Ampliar el ejercicio anterior, para a&ntilde;adir la posibilidad de que nuestro personaje "dispare".</li>
<li>Apartado 10.5.5e (Sin resolver todav&iacute;a): Ampliar el ejercicio anterior, para que si un "disparo" toca a un "enemigo", &eacute;ste deje de dibujarse.</li>
<li>Apartado 10.5.5f (Sin resolver todav&iacute;a): Ampliar el ejercicio anterior, para que la partida termine si un "enemigo" toca a nustro personaje.</li>
</ul>
<p>&nbsp;</p>

<hr /><a name ="_no"></a>
<p><b>Apartado 0.1.1</b>: Localiza en Internet el intérprete de BASIC llamado Bywater Basic, en su versión para el sistema operativo que estés utilizando (o algún otro intérprete de BASIC clásico, como un emulador de un Amstrad CPC, un MSX o un Commodore 64) y prueba el primer programa de ejemplo que se ha visto en el apartado 0.1. (Nota: no es imprescindible para seguir el curso; puedes omitir este ejercicio si no quieres instalar en tu equipo software que quizá no vuelvas a utilizar).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 0.1.2</b>: Localiza en Internet el compilador de Pascal llamado Free Pascal, en su versión para el sistema operativo que estés utilizando y prueba el segundo programa de ejemplo que se ha visto en el apartado 0.1. (Nota: no es imprescindible para seguir el curso; puedes omitir este ejercicio si no quieres instalar nada en tu equipo).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0102"></a>
<p><b>Apartado 1.2</b>: Crea un programa que diga el resultado de sumar 118 y 56.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 1.2b</b>: Un programa que calcule la diferencia entre 12345 y 998.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 1.2c</b>: Un programa que calcule y muestre el resultado de dividir 3765 entre 18 y el resto de esa división.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="010301"></a>
<p><b>Apartado 1.3.1</b>: Calcular (a mano y despu&eacute;s comprobar desde C) el resultado de estas operaciones:	-2 + 3 * 5 ; (20+5) % 6 ; 	15 + -5*6 / 10 ; 2 + 10 / 5 * 2 - 7 % 1</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="010403"></a>
<p><b>Apartado 1.4.3</b>: Hacer un programa que calcule el producto de los n&uacute;meros 121 y 132, usando variables.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="010701a"></a>
<p><b>Apartado 1.7.1a</b>: Multiplicar dos n&uacute;meros tecleados por usuario</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="010701b"></a>
<p><b>Apartado 1.7.1b</b>: El usuario teclear&aacute; dos n&uacute;meros (x e y), y el programa deber&aacute; calcular cual es el resultado de su divisi&oacute;n y el resto de esa divisi&oacute;n.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="010701c"></a>
<p><b>Apartado 1.7.1c</b>: El usuario teclear&aacute; dos n&uacute;meros (a y b), y el programa mostrar el resultado de la operaci&oacute;n (a+b)*(a-b) y el resultado de la operaci&oacute;n a2-b2.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020101"></a>
<p><b>Apartado 2.1.1</b>: Multiplicar dos n&uacute;meros de 4 cifras que teclee el usuario, usando el modificador "long".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 2.1.3a</b>: Crea un programa que te diga cuántos bytes son 3 megabytes.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 2.1.8a</b>: Crea un programa en C que exprese en el sistema decimal los números octales 162, 76, 241, 102.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 2.1.8b</b>: Crea un programa en C que exprese en el sistema decimal los números hexadecimales 1B2, 76, E1, 2A.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020110a"></a>
<p><b>Apartado 2.1.10a</b>: Crear un programa que use tres variables x,y,z. Sus valores iniciales ser&aacute;n 15, -10, 2.147.483.647. Se deber&aacute; incrementar el valor de estas variables. &iquest;Qu&eacute; valores esperas que se obtengan? Contr&aacute;stalo con el resultado obtenido por el programa.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020110b"></a>
<p><b>Apartado 2.1.10b</b>: &iquest;Cu&aacute;l ser&iacute;a el resultado de las siguientes operaciones?  a=5; b=++a; c=a++; b=b*5; a=a*2;</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020111a"></a>
<p><b>Apartado 2.1.11a</b>: Crear un programa que use tres variables x,y,z. Sus valores iniciales ser&aacute;n 15, -10, 214. Se deber&aacute; incrementar el valor de estas variables en 12, usando el formato abreviado. &iquest;Qu&eacute; valores esperas que se obtengan? Contr&aacute;stalo con el resultado obtenido por el programa.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020111b"></a>
<p><b>Apartado 2.1.11b</b>: &iquest;Cu&aacute;l ser&iacute;a el resultado de las siguientes operaciones?  a=5; b=a+2; b-=3; c=-3; c*=2; ++c; a*=b;</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020202a"></a>
<p><b>Apartado 2.2.02a</b>: El usuario de nuestro programa podr&aacute; teclear dos n&uacute;meros de hasta 8 cifras significativas. El programa deber&aacute; mostrar el resultado de dividir el primer n&uacute;mero entre el segundo, utilizando tres cifras decimales.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020202b"></a>
<p><b>Apartado 2.2.02b</b>: Crear un programa que use tres variables x,y,z. Las tres ser&aacute;n n&uacute;meros reales, y nos bastar&aacute; con dos cifras decimales. Deber&aacute; pedir al usuario los valores para las tres variables y mostrar en pantalla cual es el mayor de los tres n&uacute;meros tecleados.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0203"></a>
<p><b>Apartado 2.3</b>: Descubrir cual es el espacio ocupado por un "int" en el sistema operativo y compilador que utilizas.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="020501"></a>
<p><b>Apartado 2.5.1</b>: Crear un programa que pida al usuario que teclee cuatro letras y las muestre en pantalla juntas, pero en orden inverso, y entre comillas dobles. Por ejemplo si las letras que se teclean son a, l, o, h, escribir&iacute;a &quot;hola&quot;.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="030101a"></a>
<p><b>Apartado 3.1.1a</b>: Crear un programa que pida al usuario un n&uacute;mero entero y diga si es par (pista: habr&aacute; que comprobar si el resto que se obtiene al dividir entre dos es cero: if (x % 2 == 0) ...</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.1b</b>: Crear un programa que pida al usuario dos n&uacute;meros enteros y diga cual es el mayor de ellos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.1c</b>: Crear un programa que pida al usuario dos n&uacute;meros enteros y diga si el primero es m&uacute;ltiplo del segundo (pista: igual que antes, habr&aacute; que ver si el resto de la divisi&oacute;n es cero: a % b == 0).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.3a</b>: Crear un programa que multiplique dos n&uacute;meros enteros de la siguiente forma: pedir&aacute; al usuario un primer n&uacute;mero entero. Si el n&uacute;mero que se que teclee es 0, escribir&aacute; en pantalla "El producto de 0 por cualquier n&uacute;mero es 0". Si se ha tecleado un n&uacute;mero distinto de cero, se pedir&aacute; al usuario un segundo n&uacute;mero y se mostrar&aacute; el producto de ambos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="030103b"></a>
<p><b>Apartado 3.1.3b</b>: Crear un programa que pida al usuario dos n&uacute;meros reales. Si el segundo no es cero, mostrar&aacute; el resultado de dividir entre el primero y el segundo. Por el contrario, si el segundo n&uacute;mero es cero, escribir&aacute; &quot;Error: No se puede dividir entre cero&quot;.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.4a</b>: Crear un programa que multiplique dos n&uacute;meros enteros de la siguiente forma: pedir&aacute; al usuario un primer n&uacute;mero entero. Si el n&uacute;mero que se que teclee es 0, escribir&aacute; en pantalla "El producto de 0 por cualquier n&uacute;mero es 0". Si se ha tecleado un n&uacute;mero distinto de cero, se pedir&aacute; al usuario un segundo n&uacute;mero y se mostrar&aacute; el producto de ambos. (Variante con &quot;else&quot;)</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="030104b"></a>
<p><b>Apartado 3.1.4b</b>: Crear un programa que pida al usuario dos n&uacute;meros reales. Si el segundo no es cero, mostrar&aacute; el resultado de dividir entre el primero y el segundo. Por el contrario, si el segundo n&uacute;mero es cero, escribir&aacute; &quot;Error: No se puede dividir entre cero&quot;. (Variante con &quot;else&quot;)</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="030105a"></a>
<p><b>Apartado 3.1.5a</b>: Crear un programa que pida una letra al usuario y diga si se trata de una vocal.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.5b</b>: Crear un programa que pida al usuario dos n&uacute;meros enteros y diga "Uno de los n&uacute;meros es positivo", "Los dos n&uacute;meros son positivos" o bien "Ninguno de los n&uacute;meros es positivo", seg&uacute;n corresponda.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.5c</b>: Crear un programa que pida al usuario tres n&uacute;meros reales y muestre cu&aacute;l es el mayor de los tres.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.5d</b>: Crear un programa que pida al usuario dos n&uacute;meros enteros cortos y diga si son iguales o, en caso contrario, cu&aacute;l es el mayor de ellos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.9a</b>: Crear un programa que use el operador condicional para mostrar un el valor absoluto de un n&uacute;mero de la siguiente forma: si el n&uacute;mero es positivo, se mostrar&aacute; tal cual; si es negativo, se mostrar&aacute; cambiado de signo.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 3.1.9b</b>: Crear un programa que use el operador condicional para dar a una variable llamada "iguales" (entera) el valor 1 si los dos n&uacute;meros que ha tecleado el usuario son iguales, o el valor 0 si son distintos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="030109c"></a>
<p><b>Apartado 3.1.9c</b>: Usar el operador condicional para calcular el mayor de dos n&uacute;meros.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.1a</b>: Crear un programa que pida al usuario su contrase&ntilde;a (num&eacute;rica). Deber&aacute; terminar cuando introduzca como contrase&ntilde;a el n&uacute;mero 4567, pero volv&eacute;rsela a pedir tantas veces como sea necesario.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.1b</b>: Crea un programa que escriba en pantalla los n&uacute;meros del 1 al 10, usando "while".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.1c</b>: Crea un programa que escriba en pantalla los n&uacute;meros pares del 26 al 10 (descendiendo), usando "while".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="030201d"></a>
<p><b>Apartado 3.2.1d</b>: Crear un programa calcule cuantas cifras tiene un n&uacute;mero entero positivo (pista: se puede hacer dividiendo varias veces entre 10).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.2a</b>: Crear un programa que pida n&uacute;meros positivos al usuario, y vaya calculando la suma de todos ellos (terminar&aacute; cuando se teclea un n&uacute;mero negativo o cero).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.2b</b>: Crea un programa que escriba en pantalla los n&uacute;meros del 1 al 10, usando &quot;do..while&quot;.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.2c</b>: Crea un programa que escriba en pantalla los n&uacute;meros pares del 26 al 10 (descendiendo), usando &quot;do..while&quot;.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.2d</b>: Crea un programa que pida al usuario su c&oacute;digo de usuario (un n&uacute;mero entero) y su contrase&ntilde;a num&eacute;rica (otro n&uacute;mero entero), y no le permita seguir hasta que introduzca como c&oacute;digo 1024 y como contrase&ntilde;a 4567.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.3a</b>: Crear un programa que muestre los n&uacute;meros del 15 al 5, descendiendo (pista: en cada pasada habr&aacute; que descontar 1, por ejemplo haciendo i--).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.3b</b>: Crear un programa que muestre los primeros ocho n&uacute;meros pares (pista: en cada pasada habr&aacute; que aumentar de 2 en 2, o bien mostrar el doble del valor que hace de contador).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.3c</b>: Crear un programa que muestre las letras de la Z (may&uacute;scula) a la A (may&uacute;scula, descendiendo).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.3d</b>: Crear un programa que escriba en pantalla la tabla de multiplicar del 6.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.2.3e</b>: Crear un programa que escriba en pantalla los n&uacute;meros del 1 al 50 que sean m&uacute;ltiplos de 3 (pista: habr&aacute; que recorrer todos esos n&uacute;meros y ver si el resto de la divisi&oacute;n entre 3 resulta 0).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.3a</b>: Crear un programa que pida un número al usuario (entre 1 y 100) y muestre tantas letras A como indique ese número, usando "break" para terminar.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.4a</b>: Crear un programa que pida un número al usuario (entre 1 y 20) y muestre los números el 1 al 20, excepto el indicado por el usuario, usando "continue" para evitar ese valor.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.7a</b>: Crear un programa que d&eacute; al usuario la oportunidad de adivinar un n&uacute;mero del 1 al 100 (prefijado en el programa) en un m&aacute;ximo de 6 intentos. En cada pasada deber&aacute; avisar de si se ha pasado o se ha quedado corto.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 3.7b</b>: Crear un programa que descomponga un n&uacute;mero (que teclee el usuario) como producto de sus factores primos. Por ejemplo, 60 = 2 &bull; 2 &bull; 3 &bull; 5</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.1a</b>: Un programa que pida al usuario un n&uacute;mero entero y muestre sus equivalentes en formato hexadecimal y en octal. Deber&aacute; seguir pidiendo (y convirtiendo) n&uacute;meros hasta que se introduzca 0.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.1b</b>: Un programa que pida al usuario 2 n&uacute;meros reales y muestre su divisi&oacute;n con 2 decimales (excepto si el segundo es 0; en ese caso, deber&aacute; decir "no se puede dividir").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.2a</b>: Un programa que pida al usuario un n&uacute;mero hexadecimal y muestre su equivalente en base 10. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.2b</b>: Un programa que pida al usuario un n&uacute;mero octal y muestre su equivalente en base 10. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.2c</b>: Un programa que pida al usuario una letra, despu&eacute;s le pida una segunda letra, y las muestre en el orden contrario al que se introdujeron. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.3</b>: Un programa que escriba las letras de la A (a may&uacute;scula) a la Z (z may&uacute;scula), usando "for" y "putchar".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 4.4</b>: Un programa que pida al usuario 4 letras (usando "getchar") y las muestre en orden inverso (por ejemplo, si las letras son "h o l a", escribir&iacute;a "aloh").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050101a"></a>
<p><b>Apartado 5.1.1a</b>: Un programa que pida al usuario 4 n&uacute;meros, los memorice (utilizando una tabla), calcule su media aritm&eacute;tica y despu&eacute;s muestre en pantalla la media y los datos tecleados.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_050101b"></a>
<p><b>Apartado 5.1.1b</b>: Un programa que pida al usuario 5 n&uacute;meros reales y luego los muestre en el orden contrario al que se introdujeron.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050102a"></a>
<p><b>Apartado 5.1.2a</b>: Un programa que almacene en una tabla el n&uacute;mero de d&iacute;as que tiene cada mes (supondremos que es un a&ntilde;o no bisiesto), pida al usuario que le indique un mes (1=enero, 12=diciembre) y muestre en pantalla el n&uacute;mero de d&iacute;as que tiene ese mes.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 5.1.2b</b>: Un programa que almacene en una tabla el n&uacute;mero de d&iacute;as que tiene cada mes (a&ntilde;o no bisiesto), pida al usuario que le indique un mes (ej. 2 para febrero) y un d&iacute;a (ej. el d&iacute;a 15) y diga qu&eacute; n&uacute;mero de d&iacute;a es dentro del a&ntilde;o (por ejemplo, el 15 de febrero ser&iacute;a el d&iacute;a n&uacute;mero 46, el 31 de diciembre ser&iacute;a el d&iacute;a 365).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.1.3a</b>: A partir del programa propuesto en 5.1.2, que almacenaba en una tabla el n&uacute;mero de d&iacute;as que tiene cada mes, crear otro que pida al usuario que le indique la fecha, detallando el d&iacute;a (1 al 31) y el mes (1=enero, 12=diciembre), como respuesta muestre en pantalla el n&uacute;mero de d&iacute;as que quedan hasta final de a&ntilde;o.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050103b"></a>
<p><b>Apartado 5.1.3b</b>: Crear un programa que pida al usuario 10 n&uacute;meros y luego los muestre en orden inverso (del &uacute;ltimo al primero).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 5.1.3c</b>: Crear un programa que pida al usuario 10 n&uacute;meros, calcule su media y luego muestre los que est&aacute;n por encima de la media.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.1.3d</b>: Un programa que pida al usuario 10 n&uacute;meros enteros y calcule (y muestre) cu&aacute;l es el mayor de ellos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050201a"></a>
<p><b>Apartado 5.2.1a</b>: Un programa que te pida tu nombre y una cifra numérica, y escriba tu nombre tantas veces como indique esa cifra numérica.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050201b"></a>
<p><b>Apartado 5.2.1b</b>: Un programa similar al anterior, pero que pida en primer lugar la cifra numérica y después tu nombre, y luego escriba el nombre tantas veces como indique esa cifra numérica.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.2.2</b>: Un programa que pida al usuario que introduzca una palabra, cambie su primera letra por una "A" y muestre la palabra resultante.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050203a"></a>
<p><b>Apartado 5.2.3a</b>: Un programa que te pida tu nombre y lo muestre en pantalla separando cada letra de la siguiente con un espacio. Por ejemplo, si tu nombre es "Juan", deber&iacute;a aparecer en pantalla "J u a n".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 5.2.3b</b>: Un programa que te pida tu nombre y lo muestre en pantalla separando al rev&eacute;s. Por ejemplo, si tu nombre es "Juan", deber&iacute;a aparecer en pantalla "nauJ".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050204a"></a>
<p><b>Apartado 5.2.4a</b>: Un programa que te pida una frase y la muestre en pantalla sin espacios. Por ejemplo, si la frase es "Hola, como est&aacute;s", deber&iacute;a aparecer en pantalla "Hola,comoest&aacute;s".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050204b"></a>
<p><b>Apartado 5.2.4b</b>: Un programa que te pida tu nombre (usando "gets") y una cifra numérica, y escriba tu nombre tantas veces como indique esa cifra numérica.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050204c"></a>
<p><b>Apartado 5.2.4c</b>: Un programa similar al anterior, pero que pida en primer lugar la cifra numérica y después tu nombre (con "gets"), y luego escriba el nombre tantas veces como indique esa cifra numérica.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.2.5</b>: Un programa que te pida una palabra, y la almacene en la variable llamada "texto". Luego deber&aacute; pedir una segunda palabra, y a&ntilde;adirla al final de "texto". Finalmente, deber&aacute; pedir una tercera palabra, y guardarla en la variable "texto" y en otra variable llamada "texto2".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050206a"></a>
<p><b>Apartado 5.2.6a</b>: Crear un programa que pida al usuario su contrase&ntilde;a. Deber&aacute; terminar cuando introduzca como contrase&ntilde;a la palabra &quot;clave&quot;, pero volv&eacute;rsela a pedir tantas veces como sea necesario.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 5.2.6b</b>: Crear un programa que pida al usuario su nombre y su contrase&ntilde;a, y no le permita seguir hasta que introduzca como nombre &quot;Pedro&quot; y como contrase&ntilde;a &quot;Peter&quot;.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.2.7</b>: Un programa que pida tu nombre, tu d&iacute;a de nacimiento y tu mes de nacimiento y lo junte todo en una cadena, separando el nombre de la fecha por una coma y el d&iacute;a del mes por una barra inclinada, as&iacute;: "Juan, nacido el 31/12".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0503a"></a>
<p><b>Apartado 5.3a</b>: Un programa guarde los nombres de los meses. El usuario deber&aacute; indicar un n&uacute;mero de mes (por ejemplo, 3) y se le mostrar&aacute; el nombre de dicho mes (por ejemplo, Marzo).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.3b</b>: Usar un array de 3 dimensiones para guardar los nombres de los meses en espa&ntilde;ol e ingl&eacute;s. El usuario deber&aacute; indicar un n&uacute;mero de mes (por ejemplo, 3) y se le mostrar&aacute; el nombre de dicho mes en espa&ntilde;ol (Marzo) y en ingl&eacute;s (March).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0504a"></a>
<p><b>Apartado 5.4a</b>: Un programa que pida 10 nombres y los memorice. Después deberá pedir que se teclee un nombre y dirá si se encuentra o no entre los 10 que se han tecleado antes. Volverá  a pedir otro nombre y a decir si se encuentra entre ellos, y así sucesivamente hasta que se teclee "fin".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.4b</b>: Un programa que prepare espacio para un máximo de 100 nombres (de un máximo de 80 letras cada uno). El usuario deberá ir introduciendo un nombre cada vez, hasta que se pulse Intro sin teclear nada, momento en el que dejarán de pedirse más nombres y se mostrará en pantalla la lista de los nombres que se han introducido hasta entonces.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.5.1</b>: Un "struct" que almacene datos de una canci&oacute;n en formato MP3: Artista, T&iacute;tulo, Duraci&oacute;n (en segundos), Tama&ntilde;o del fichero (en KB). Un programa debe pedir los datos de una canci&oacute;n al usuario, almacenarlos en dicho "struct" y despu&eacute;s mostrarlos en pantalla.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 5.5.2a</b>: Ampliar el programa del apartado 5.5.1, para que almacene datos de hasta 100 canciones. Deber&aacute; tener un men&uacute; que permita las opciones: a&ntilde;adir una nueva canci&oacute;n, mostrar el t&iacute;tulo de todas las canciones, buscar la canci&oacute;n que contenga un cierto texto (en el artista o en el t&iacute;tulo).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="050502b"></a>
<p><b>Apartado 5.5.2b</b>: Un programa que permita guardar datos de &quot;im&aacute;genes&quot; (ficheros de ordenador que contengan fotograf&iacute;as o cualquier otro tipo de informaci&oacute;n gr&aacute;fica). De cada imagen se debe guardar: nombre (texto), ancho en p&iacute;xeles (por ejemplo 2000), alto en p&iacute;xeles (por ejemplo, 3000), tama&ntilde;o en Kb (por ejemplo 145,6). El programa debe ser capaz de almacenar hasta 700 im&aacute;genes (deber&aacute; avisar cuando su capacidad est&eacute; llena). Debe permitir las opciones: a&ntilde;adir una ficha nueva, ver todas las fichas (n&uacute;mero y nombre de cada imagen), buscar la ficha que tenga un cierto nombre.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.5.3</b>: Ampliar el programa del apartado 5.5.2, para que el campo "duraci&oacute;n" se almacene como minutos y segundos, usando un "struct" anidado que contenga a su vez estos dos campos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6a</b>: Un programa que pida el nombre, el apellido y la edad de una persona, los almacene en un "struct" y luego muestre los tres datos en una misma l&iacute;nea, separados por comas.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6b</b>: Un programa que pida datos de 8 personas: nombre, dia de nacimiento, mes de nacimiento, y a&ntilde;o de nacimiento (que se deben almacenar en una tabla de structs). Despu&eacute;s deber&aacute; repetir lo siguiente: preguntar un n&uacute;mero de mes y mostrar en pantalla los datos de las personas que cumplan los a&ntilde;os durante ese mes. Terminar&aacute; de repetirse cuando se teclee 0 como n&uacute;mero de mes.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6c</b>: Un programa que sea capaz de almacenar los datos de hasta 50 personas: nombre, direcci&oacute;n, tel&eacute;fono, edad (usando una tabla de structs). Deber&aacute; ir pidiendo los datos uno por uno, hasta que un nombre se introduzca vac&iacute;o (se pulse Intro sin teclear nada). Entonces deber&aacute; aparecer un men&uacute; que permita: Mostrar la lista de todos los nombres; Mostrar las personas de una cierta edad; Mostrar las personas cuya inicial sea la que el usuario indique; Salir del programa (l&oacute;gicamente, este men&uacute; debe repetirse hasta que se escoja la opci&oacute;n de "salir").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6d</b>: Mejorar la base de datos de ficheros (ejemplo 53) para que no permita introducir tama&ntilde;os incorrectos (n&uacute;meros negativos) ni nombres de fichero vac&iacute;os.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6e</b>: Ampliar la base de datos de ficheros (ejemplo 53) para que incluya una opci&oacute;n de b&uacute;squeda parcial, en la que el usuario indique parte del nombre y se muestre todos los ficheros que contienen ese fragmento (usando "strstr").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6f</b>: Ampliar la base de datos de ficheros (ejemplo 53) para que se pueda borrar un cierto dato (habr&aacute; que "mover hacia atr&aacute;s" todos los datos que hab&iacute;a despu&eacute;s de ese, y disminuir el contador de la cantidad de datos que tenemos).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6g</b>: Mejorar la base de datos de ficheros (ejemplo 53) para que se pueda modificar un cierto dato a partir de su n&uacute;mero (por ejemplo, el dato n&uacute;mero 3). En esa modificaci&oacute;n, se deber&aacute; permitir al usuario pulsar Intro sin teclear nada, para indicar que no desea modificar un cierto dato, en vez de reemplazarlo por una cadena vac&iacute;a.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.6h</b>: Ampliar la base de datos de ficheros (ejemplo 53) para que se permita ordenar los datos por nombre. Para ello, deber&aacute;s buscar informaci&oacute;n sobre alg&uacute;n m&eacute;todo de ordenaci&oacute;n sencillo, como el &quot;m&eacute;todo de burbuja&quot;, y aplicarlo a este caso concreto.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 5.7</b>: Un programa que cree un array de 7 n&uacute;meros enteros y lo ordene con cada uno de estos tres m&eacute;todos, mostrando el resultado de los pasos intermedios.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0601a"></a>
<p><b>Apartado 6.1</b>: Crea un programa que vaya leyendo las frases que el usuario teclea y las guarde en un fichero de texto. Terminar&aacute; cuando la frase introducida sea "fin" (esa frase no deber&aacute; guardarse en el fichero).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.2</b>: Crea un programa que lea las tres primeras l&iacute;neas del fichero creado en el apartado anterior y las muestre en pantalla. Si el fichero no existe, se deber&aacute; mostrar un aviso.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.3a</b>: Un programa que pida al usuario que teclee frases, y las almacene en el fichero "frases.txt". Acabar&aacute; cuando el usuario pulse Intro sin teclear nada. Despu&eacute;s deber&aacute; mostrar el contenido del fichero.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.3b</b>: Un programa que pregunte un nombre de fichero y muestre en pantalla el contenido de ese fichero, haciendo una pausa despu&eacute;s de cada 25 l&iacute;neas, para que d&eacute; tiempo a leerlo. Cuando el usuario pulse intro, se mostrar&aacute;n las siguientes 25 l&iacute;neas, y as&iacute; hasta que termine el fichero. (Pista: puedes usar un contador, volverlo a poner a cero tras cada 25 l&iacute;neas o bien comprobar si has avanzado otras 25 l&iacute;neas usando la operaci&oacute;n "resto de la divisi&oacute;n", y hacer la pausa con "getchar()").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.4a</b>: Crear un "struct" que almacene los siguientes datos de una persona: nombre, edad, ciudad de residencia. Pedir al usuario esos datos de una persona y guardarlos en un fichero llamado "gente.dat". Cerrar el fichero, volverlo a abrir para lectura y mostrar los datos que se hab&iacute;an guardado.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.4b</b>: Ampliar el programa anterior para que use un "array de structs", de forma que se puedan tener datos de 10 personas. Se deber&aacute; pedir al usuario los datos de las 10 personas y guardarlos en el fichero. Despu&eacute;s se pedir&aacute; al usuario un n&uacute;mero del 1 al 10 y se mostrar&aacute;n los datos de la persona indicada por ese n&uacute;mero, que se deber&aacute;n leer de fichero (1 ser&aacute; la primera ficha, y 10 ser&aacute; la &uacute;ltima). Por ejemplo, si el usuario indica que quiere ver los datos de la persona 3 (tercera), se deber&aacute; leer las dos primeras, ignorando su contenido, y despu&eacute;s leer la tercera, que s&iacute; se deber&aacute; mostrar. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0604c"></a>
<p><b>Apartado 6.4c</b>: Una agenda que maneje los siguientes datos: nombre, direcci&oacute;n, tlf m&oacute;vil, email, y d&iacute;a, mes y a&ntilde;o de nacimiento (estos tres &uacute;ltimos datos deber&aacute;n ser n&uacute;meros enteros cortos). Deber&aacute; tener capacidad para 100 fichas. Se deber&aacute; poder a&ntilde;adir un dato nuevo, visualizar los nombres de las fichas existentes, o mostrar todos los datos de una persona (se preguntar&aacute; al usuario cual es el nombre de esa persona que quiere visualizar). Al empezar el programa, leer&aacute; los datos de un fichero llamado "agenda.dat" (si existe). Al terminar, guardar&aacute; todos los datos en ese fichero. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.6a</b>: Un programa que pida al usuario que teclee frases, y las almacene en el fichero "registro.txt", que puede existir anteriormente (y que no deber&aacute; borrarse, sino a&ntilde;adir al final de su contenido). Cada sesi&oacute;n acabar&aacute; cuando el usuario pulse Intro sin teclear nada. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.6b</b>: Crear un programa que pida al usuario pares de n&uacute;meros enteros y escriba su suma (con el formato "20 + 3 = 23") en pantalla y en un fichero llamado "sumas.txt", que se encontrar&aacute; en un subdirectorio llamado "resultados". Cada vez que se ejecute el programa, deber&aacute; a&ntilde;adir los nuevos resultados a continuaci&oacute;n de los resultados de las ejecuciones anteriores.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.8a</b>: Crear un "struct" que almacene los siguientes datos de una persona: nombre, edad, ciudad de residencia. Pedir al usuario esos datos de una persona y guardarlos en un fichero llamado "gente.dat", usando "fwrite". Cerrar el fichero, volverlo a abrir para lectura y mostrar los datos que se hab&iacute;an guardado, que se deben leer con "fread".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.8b</b>: Ampliar el programa anterior para que use un "array de structs", de forma que se puedan tener datos de 10 personas. Se deber&aacute; pedir al usuario los datos de las 10 personas y guardarlos en el fichero, usando "fwrite". Despu&eacute;s se pedir&aacute; al usuario un n&uacute;mero del 1 al 10 y se mostrar&aacute;n los datos de la persona indicada por ese n&uacute;mero, que se deber&aacute;n leer de fichero (1 ser&aacute; la primera ficha, y 10 ser&aacute; la &uacute;ltima). Por ejemplo, si el usuario indica que quiere ver los datos de la persona 3 (tercera), se deber&aacute; leer las dos primeras (con "fread"), ignorando su contenido, y despu&eacute;s leer la tercera, que s&iacute; se deber&aacute; mostrar.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.8c</b>: Mejorar la agenda anterior (del apartado 6.4), para guardar y leer cada "ficha" (struct) de una vez, usando fwrite/fread y sizeof, como en el &uacute;ltimo ejemplo. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.9a</b>: Ampliar el programa anterior (el "array de structs" con 10 personas) para que el dato que indique el usuario se lea sin leer y descartar antes los que le preceden, sino que se salte directamente a la ficha deseada usando "fseek".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.10a</b>: Mejorar la &uacute;ltima versi&oacute;n de la agenda anterior (la que usa fwrite, fread y sizeof) para que no lea todas las fichas a la vez, sino que lea una &uacute;nica ficha del disco cada vez que lo necesite, saltando a la posici&oacute;n en que se encuentra dicha ficha con "fseek".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.10b</b>: Hacer un programa que muestre informaci&oacute;n sobre una imagen en formato GIF (se deber&aacute; localizar en Internet los detalles sobre dicho formato): versi&oacute;n, ancho de la imagen (en p&iacute;xeles), alto de la imagen y cantidad de colores.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.10c</b>: Hacer un programa que muestre informaci&oacute;n sobre una imagen en formato PCX: ancho de la imagen (en p&iacute;xeles), alto de la imagen y cantidad de colores.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.10d</b>: Mejorar la base de datos de ficheros (ejemplo 53) para que los datos se guarden en disco al terminar la sesi&oacute;n de uso, y se lean de disco cuando comienza una nueva sesi&oacute;n.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.10e</b>: Mejorar la base de datos de ficheros (ejemplo 53) para que cada dato introducido se guarde inmediatamente en disco, sin esperar a que termine la sesi&oacute;n de uso. En vez de emplear un "array de structs", debe existir un solo "struct" en memoria cada vez, y para las b&uacute;squedas se recorra todo el contenido del fichero.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.10f</b>: Mejorar el ejercicio anterior (ejemplo 53 ampliado con ficheros, que se manejan ficha a ficha) para que se pueda modificar un cierto dato a partir de su n&uacute;mero (por ejemplo, el dato n&uacute;mero 3). En esa modificaci&oacute;n, se deber&aacute; permitir al usuario pulsar Intro sin teclear nada, para indicar que no desea modificar un cierto dato, en vez de reemplazarlo por una cadena vac&iacute;a. </p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 6.14a</b>: Pedir al usuario dos números y la operación (suma o resta) a realizar con ellos, y mostrar el resultado de dicha operación. Utilizar "fgets" y "sscanf" para la lectura de teclado.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0704a"></a>
<p><b>Apartado 7.4a</b>: Crear una funci&oacute;n que calcule el cubo de un n&uacute;mero real (float). El resultado deber&aacute; ser otro n&uacute;mero real. Probar esta funci&oacute;n para calcular el cubo de 3.2 y el de 5.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0704b"></a>
<p><b>Apartado 7.4b</b>: Crear una funci&oacute;n que calcule cual es el menor de dos n&uacute;meros enteros. El resultado ser&aacute; otro n&uacute;mero entero.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0704c"></a>
<p><b>Apartado 7.4c</b>: Crear una funci&oacute;n llamada "signo", que reciba un n&uacute;mero real, y devuelva un n&uacute;mero entero con el valor: -1 si el n&uacute;mero es negativo, 1 si es positivo o 0 si es cero.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0704d"></a>
<p><b>Apartado 7.4d</b>: Crear una funci&oacute;n que devuelva la primera letra de una cadena de texto. Probar esta funci&oacute;n para calcular la primera letra de la frase "Hola"</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_prop"></a>
<p><b>Apartado 7.4e</b>: Crear una funci&oacute;n que devuelva la &uacute;ltima letra de una cadena de texto. Probar esta funci&oacute;n para calcular la &uacute;ltima letra de la frase "Hola".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.5a</b>: Crear una función "escribirGuiones" que escriba en pantalla tantos guiones ("-") como se indique como parámetro y no devuelva ningún valor.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.5b</b>: Crear una función "dibujarRectangulo", que reciba como parámetros la anchura y la altura del rectángulo a mostrar, y muestre en pantalla un rectángulo de ese tamaño, relleno de caracteres "#".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="0705a"></a>
<p><b>Apartado 7.5c</b>: Crear una funci&oacute;n que borre la pantalla dibujando 25 l&iacute;neas en blanco. No debe devolver ning&uacute;n valor.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.5d</b>: Crear una funci&oacute;n que reciba un n&uacute;mero y muestre en pantalla el per&iacute;metro y la superficie de un cuadrado que tenga como lado el n&uacute;mero que se ha indicado como par&aacute;metro.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.5e</b>: Crear una función "escribirCentrado" que reciba un texto y lo escriba centrado en la siguiente línea de pantalla (suponiendo 80 columnas en pantalla). Por ejemplo, si el texto es "Hola", que tiene 4 letras, se escribirán 38 espacios antes de él.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.6a</b>: Crear una funci&oacute;n "pedirEntero", que reciba como par&aacute;metros el texto que se debe mostrar en pantalla, el valor m&iacute;nimo aceptable y el valor m&aacute;ximo aceptable. Deber&aacute; pedir al usuario que introduzca el valor tantas veces como sea necesario, volv&eacute;rselo a pedir en caso de error, y devolver un valor correcto. Probarlo con un programa que pida al usuario un a&ntilde;o entre 1800 y 2100.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.6b</b>: Crear una funci&oacute;n "escribirTablaMultiplicar", que reciba como par&aacute;metro un n&uacute;mero entero, y escriba la tabla de multiplicar de ese n&uacute;mero (por ejemplo, para el 3 deber&aacute; llegar desde 3x0=0 hasta 3x10=30).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.6c</b>: Crear una funci&oacute;n "esPrimo", que reciba un n&uacute;mero y devuelva el valor 1 si es un n&uacute;mero primo o 0 en caso contrario.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.6d</b>: Crear una funci&oacute;n que reciba una cadena y una letra, y devuelva la cantidad de veces que dicha letra aparece en la cadena. Por ejemplo, si la cadena es &quot;Barcelona&quot; y la letra es 'a', deber&iacute;a devolver 2 (aparece 2 veces).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.6e</b>: Crear una funci&oacute;n que reciba un n&uacute;mero cualquiera y que devuelva como resultado la suma de sus d&iacute;gitos. Por ejemplo, si el n&uacute;mero fuera 123 la suma ser&iacute;a 6.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.6f</b>: Crear una funci&oacute;n que reciba una letra y un n&uacute;mero, y escriba un "tri&aacute;ngulo" formado por esa letra, que tenga como anchura inicial la que se ha indicado. Por ejemplo, si la letra es * y la anchura es 4, deber&iacute;a escribir<br />****<br />***<br />**<br />*<br /></p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.1a</b>: Crea un programa que escriba varias veces "Hola" (entre 5 y 10 veces, al azar).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.1b</b>: Crear un programa que genere un número al azar entre 1 y 100. El usuario tendrá 6 oportunidades para acertarlo.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.1c</b>: Crea un programa que muestre un "fondo estrellado" en pantalla: mostrará 24 líneas, cada una de las cuales contendrá entre 1 y 78 espacios (al azar) seguidos por un asterisco ("*").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.2a</b>: Crear un programa que halle cualquier ra&iacute;z de un n&uacute;mero. El usuario deber&aacute; indicar el n&uacute;mero (por ejemplo, 2) y el &iacute;ndice de la raiz (por ejemplo, 3 para la ra&iacute;z c&uacute;bica). Pista: hallar la ra&iacute;z c&uacute;bica de 2 es lo mismo que elevar 2 a 1/3.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.2b</b>: Crear un programa que resuelva ecuaciones de segundo grado, del tipo ax2 + bx + c = 0 El usuario deber&aacute; introducir los valores de a, b y c. Pista: la soluci&oacute;n se calcula con  x = +- ra&iacute;z (b2 &ndash; 4&bull;a&bull;c)  / 2&bull;a</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.2c</b>: Crear un programa que muestre el seno de los ángulos de 30 grados, 45 grados, 60 grados y 90 grados. Cuidado: la función "sin" espera que se le indique el ángulo en radianes, no en grados. Tendrás que recordar que 180 grados es lo mismo que Pi radianes (con Pi = 3,1415926535). Puedes crearte una función auxiliar que convierta de grados a radianes.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.9.3a</b>: Crea un programa que escriba la raíz cuadrada de 10 y muestre la cantidad de cifras que se han escrito en pantalla. (Pista: mira el valor devuelto por "printf").</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10a</b>: Crear una funci&oacute;n que calcule el valor de elevar un n&uacute;mero entero a otro n&uacute;mero entero (por ejemplo, 5 elevado a 3 = 5<sup>3</sup> = 5 &bull;5 &bull; 5 = 125). Esta funci&oacute;n se debe crear de forma recursiva.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10b</b>: Como alternativa, crear una funci&oacute;n que calcule el valor de elevar un n&uacute;mero entero a otro n&uacute;mero entero de forma NO recursiva (lo que llamaremos "de forma iterativa"), usando la orden "for".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10c</b>: Crear un programa que emplee recursividad para calcular un número de la serie Fibonacci (en la que los dos primeros elementos valen 1, y para los restantes, cada elemento es la suma de los dos anteriores).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10d</b>: Crear un programa que emplee recursividad para calcular la suma de los elementos de un vector.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10e</b>: Crear un programa que emplee recursividad para calcular el mayor de los elementos de un vector.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10f</b>: Crear un programa que emplee recursividad para dar la vuelta a una cadena de caracteres (por ejemplo, a partir de &quot;Hola&quot; devolver&iacute;a &quot;aloH&quot;).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10g</b>: Crear, tanto de forma recursiva como de forma iterativa, una funci&oacute;n diga si una cadena de caracteres es sim&eacute;trica (un pal&iacute;ndromo). Por ejemplo, \&quot;DABALEARROZALAZORRAELABAD\&quot; es un pal&iacute;ndromo.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 7.10h</b>: Crear un programa que encuentre el m&aacute;ximo com&uacute;n divisor de dos n&uacute;meros usando el algoritmo de Euclides: Dados dos n&uacute;meros enteros positivos m y n, tal que m &gt; n, para encontrar su m&aacute;ximo com&uacute;n divisor, es decir, el mayor entero positivo que divide a ambos: - Dividir m por n para obtener el resto r (0 = r &lt; n) ; - Si r = 0, el MCD es n.; - Si no, el m&aacute;ximo com&uacute;n divisor es MCD(n,r).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.5a</b>: Crear una funci&oacute;n que calcule las dos soluciones de una ecuaci&oacute;n de segundo grado (Ax2 + Bx + C = 0) y devuelva las dos soluciones como par&aacute;metros.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.8a</b>: Mejorar la versi&oacute;n de la agenda que le&iacute;a todos los datos al principio de la ejecuci&oacute;n y guardaba todos los datos cuando termin&aacute;bamos su uso (apartado 6.4). Esta nueva versi&oacute;n deber&aacute; estar preparada para manejar hasta 1000 fichas, pero s&oacute;lo reservar&aacute; espacio para las que realmente sean necesarias.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.9a</b>: Crear un programa llamado "suma", que calcule (y muestre) la suma de dos n&uacute;meros que se le indiquen como par&aacute;metro.  Por ejemplo, si se teclea "suma 2 3" deber&aacute; responder "5", y si se teclea "suma 2" deber&aacute; responder "no hay suficientes datos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.9b</b>: Crear una calculadora b&aacute;sica, llamada "calcula", que deber&aacute; sumar, restar, multiplicar o dividir los dos n&uacute;meros que se le indiquen como par&aacute;metros. Ejemplos de su uso ser&iacute;a "calcula 2 + 3" o "calcula 5 * 60".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.10a</b>: Crea una "pila de enteros", que permitirá añadir un nuevo número (lo que llama¬remos "apilar") o bien extraer el número que se encuentra en la parte más alta de la pila ("desapilar"). En una primera aproximación, usa un array para guardar los datos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.10b</b>: Crea una nueva versión de la "pila de enteros", que utilice memoria dinámica.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.10c</b>: Crea una "cola de enteros", que permitirá añadir un nuevo número al final de la cola (lo que llama¬remos "encolar") o bien extraer el número que se encuentra al principio de la cola ("desencolar"). En esta primera aproximación, usa un array para guardar los datos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.10d</b>: Crea una nueva versión de la "cola de enteros", que utilice memoria dinámica.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 9.10e</b>: Implementa una lista doble enlazada que almacene n&uacute;meros enteros.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.4a</b>: Crea un men&uacute; para MsDos que muestre varias opciones en el centro de la pantalla, y el reloj en la parte superior derecha de la pantalla. Mientras el usuario no pulse una tecla, el reloj debe actualizarse continuamente.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.4b</b>: Crea, tanto para MsDos como para Linux, un "protector de pantalla" que muestre tu nombre rebotando en los laterales de la pantalla. Deber&aacute; avanzar de posici&oacute;n cada segundo.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.1a</b>: Crea (o busca en Internet) una imagen de fondo de tama&ntilde;o 800x600 que represente un cielo negro con estrellas, y tres im&aacute;genes de planetas con un tama&ntilde;o menor (cercano a 100x100, por ejemplo). Entra a modo gr&aacute;fico 800x600 con 24 bits de color usando SDL, dibuja la imagen de fondo, y sobre ella, las de los tres planetas. El t&iacute;tulo de la ventana deber&aacute; ser "Planetas". Las im&aacute;genes deber&aacute;n mostrarse durante  7 segundos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.2a</b>: Ampl&iacute;a el ejercicio anterior, a&ntilde;adiendo la imagen de una nave espacial, que deber&aacute; moverse cada vez que el usuario pulse una de las flechas del cursor. Ya no se saldr&aacute; al cabo de varios segundos, sino cuando el usuario pulse la tecla ESC.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.3a</b>: Ampl&iacute;a el ejercicio anterior, para que la imagen de la nave espacial tenga el contorno transparente (y quiz&aacute; tambi&eacute;n alguna zona interior).</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.3b</b>: Crea una imagen que contenga varias letras (al menos H, O, L, A), y &uacute;sala para escribir las frases HOLA y OH en modo gr&aacute;fico con SDL.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.4a</b>: Ampl&iacute;a el ejercicio de la nave, para que emplee un doble buffer que permita evitar parpadeos.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.5a</b>: Ampl&iacute;a el ejercicio de la nave, para que emplee tenga una funci&oacute;n "buclePrincipal", que siga la apariencia de un bucle de juego cl&aacute;sico, llamando a funciones con los nombres "comprobarTeclas", "dibujarElementos", "moverEstrellas", "mostrarPantallaOculta". Existir&aacute;n algunas estrellas, cuya posici&oacute;n cambiar&aacute; cuando se llame a "moverEstrellas" y que se dibujar&aacute;n, junto con los dem&aacute;s componentes, al llamar a en "dibujarElementos". Al final de cada "pasada" por el bucle principal habr&aacute; una pausa de 20 milisegundos, para que la velocidad del "juego" no dependa del ordenador en que se ejecute.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.5b</b>: Ampliar el ejercicio anterior, para que tambi&eacute;n exista un "enemigo" que se mueva de lado a lado de la pantalla.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.5c</b>: Ampliar el ejercicio anterior, para que haya 20 "enemigos" (un array) que se muevan de lado a lado de la pantalla.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.5d</b>: Ampliar el ejercicio anterior, para a&ntilde;adir la posibilidad de que nuestro personaje "dispare".</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.5e</b>: Ampliar el ejercicio anterior, para que si un "disparo" toca a un "enemigo", &eacute;ste deje de dibujarse.</p>
<p><pre><code class='language-c'></code></pre></p>

<hr /><a name ="_no"></a>
<p><b>Apartado 10.5.5f</b>: Ampliar el ejercicio anterior, para que la partida termine si un "enemigo" toca a nustro personaje.</p>
<p><pre><code class='language-c'></code></pre></p>

           </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   179022 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="index.php">Anterior</a></li>
                    <li><a href="index.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        