<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 11 - Caracteristicas avanzadas</title>

    
    <meta name="description" content="Curso de C - Tema 11 - Caracteristicas avanzadas - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="or,and,not,desplazamiento,directiva,preprocesador,makefile,coma" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 11 - Caracteristicas avanzadas          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc11c.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc11e.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>11.4 Uniones y campos de bits</h3>
<p>Conocemos lo que es un struct: un dato formado por varios &ldquo;trozos&rdquo; de informaci&oacute;n de distinto tipo. Pero C tambi&eacute;n tiene dos tipos especiales de &ldquo;struct&rdquo;, de manejo m&aacute;s avanzado. Son las uniones y los campos de bits.</p>
<p>Una <strong>uni&oacute;n</strong> recuerda a un &ldquo;struct&rdquo; normal, con la diferencia de que sus &ldquo;campos&rdquo; comparten el mismo espacio de memoria:</p>
<p> <span class="nsource">union {<br />
 &nbsp;&nbsp; char letra; /* 1 byte */<br />
 &nbsp;&nbsp; int numero; /* 4 bytes */<br />
  } ejemplo;</span></p>
<p>En este caso, la variable &ldquo;ejemplo&rdquo; ocupa 4 bytes en memoria (suponiendo que estemos trabajando en un compilador de 32 bits, como lo son la mayor&iacute;a de los de Windows y Linux). El primer byte est&aacute; compartido por &ldquo;letra&rdquo; y por &ldquo;numero&rdquo;, y los tres &uacute;ltimos bytes s&oacute;lo pertenecen a &ldquo;numero&rdquo;.</p>
<p>Si hacemos</p>
<p> ejemplo.numero = 25;<br />
  ejemplo.letra = 50;<br />
  printf(&quot;%d&quot;, ejemplo.numero);</p>
<p>Veremos que &ldquo;ejemplo.numero&rdquo; ya no vale 25, puesto que al modificar &ldquo;ejemplo.letra&rdquo; estamos cambiando su primer byte. Ahora &ldquo;ejemplo.numero&rdquo; valdr&iacute;a 50 o un n&uacute;mero mucho m&aacute;s grande, seg&uacute;n si el ordenador que estamos utilizando almacena en primer lugar el byte m&aacute;s significativo o el menos significativo.<br />
</p>
<p>Un <strong>campo de bits</strong> es un elemento de un registro (struct), que se define bas&aacute;ndose en su tama&ntilde;o en bits. Se define de forma muy parecida (pero no igual) a un &quot;struct&quot; normal, indicando el n&uacute;mero de bits que se debe reservar a cada elemento:</p>
<p class="nsource"> struct campo_de_bits {<br />
 &nbsp;&nbsp; int bit_1 : 1;<br />
 &nbsp;&nbsp; int bits_2_a_5 : 4;<br />
 &nbsp;&nbsp; int bit_6 : 1;<br />
 &nbsp;&nbsp; int bits_7_a_16 : 10;<br />
  } variableDeBits;</p>
<p>Esta variable ocupar&iacute;a 1+4+1+10 = 16 bits (2 bytes). Los campos de bits pueden ser interesantes cuando queramos optimizar al m&aacute;ximo el espacio ocupado por nuestro datos.</p>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   8223 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc11c.php">Anterior</a></li>
                    <li><a href="cc11e.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        
