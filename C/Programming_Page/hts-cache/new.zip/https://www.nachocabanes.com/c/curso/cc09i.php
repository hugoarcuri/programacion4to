<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 9 - Punteros</title>

    
    <meta name="description" content="Curso de C - Tema 9 - Punteros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="punteros,malloc,free,argc,argv,pointer,null" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 9 - Punteros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc09g.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc09j.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>9.9. Par&aacute;metros de &ldquo;main&rdquo;</h3>
<p>Es muy frecuente que un programa que usamos desde la &ldquo;l&iacute;nea de comandos&rdquo; tenga ciertas opciones que le indicamos como argumentos. Por ejemplo, bajo Linux o cualquier otro sistema operativo de la familia Unix, podemos ver la lista detallada de ficheros que terminan en .c haciendo</p>
<p>ls &ndash;l *.c</p>
<p>En este caso, la orden ser&iacute;a &ldquo;ls&rdquo;, y las dos opciones (argumentos o par&aacute;metros) que le indicamos son &ldquo;-l&rdquo; y &ldquo;*.c&rdquo;.</p>
<p>Pues bien, estas opciones que se le pasan al programa se pueden leer desde C. La forma de hacerlo es con dos par&aacute;metros. El primero (que por convenio se suele llamar &ldquo;argc&rdquo;) ser&aacute; un n&uacute;mero entero que indica cuantos argumentos se han tecleado. El segundo (que se suele llamar &ldquo;argv&rdquo;) es una tabla de cadenas de texto, que contiene cada uno de esos argumentos.</p>
<p>Por ejemplo, si bajo Windows o MsDos tecleamos la orden &ldquo;DIR *.EXE P&rdquo;, tendr&iacute;amos que:<br />
    <br />
    * argc es la cantidad de par&aacute;metros, incluyendo el nombre del propio programa (3, en este ejemplo).<br />
    * argv[0] es el nombre del programa (DIR, en este caso).<br />
    * argv[1] es el primer argumento (*.EXE).<br />
    * argv[2] es el segundo argumento (/P).<br />
</p>
<p>Un fuente en C de ejemplo, que mostrara todos los par&aacute;metros que se han tecleado ser&iacute;a:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 80:      */
/*  C080.C                   */
/*                           */
/*  Argumentos de "main"     */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main (int argc, char *argv[])
{
  int i;

  printf ("Nombre del programa:\"%s\".\n",argv[0]);
  if (argc > 0)
      for (i = 1; i<argc; i++)
           printf("Parámetro %d = %s\n", i, argv[i]);
  else
      printf("No se han indicado parámetros.\n");
  return 0;
}
</code></pre></p>

<p>Ejercicios propuestos:</p>
<ul>
  <li>  Crear un programa llamado &ldquo;suma&rdquo;, que calcule (y muestre) la suma de dos n&uacute;meros que se le indiquen como par&aacute;metro. Por ejemplo, si se teclea &ldquo;suma 2 3&rdquo; deber&aacute; responder &ldquo;5&rdquo;, y si se teclea &ldquo;suma 2&rdquo; deber&aacute; responder &ldquo;no hay suficientes datos.<br />
    </li>
  <li> Crear una calculadora b&aacute;sica, llamada &ldquo;calcula&rdquo;, que deber&aacute; sumar, restar, multiplicar o dividir los dos n&uacute;meros que se le indiquen como par&aacute;metros. Ejemplos de su uso ser&iacute;a &ldquo;calcula 2 + 3&rdquo; o &ldquo;calcula 5 * 60&rdquo;.<br />
      </p>
  </li>
</ul>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   7891 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc09g.php">Anterior</a></li>
                    <li><a href="cc09j.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        