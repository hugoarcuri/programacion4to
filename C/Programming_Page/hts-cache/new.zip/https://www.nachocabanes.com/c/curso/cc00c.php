<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 0 - Conceptos basicos</title>

    
    <meta name="description" content="Tutorial de C - Tema 1 - Toma de contacto con C - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="interprete,compilador,ensamblador,c,pascal,basic" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 0 - Conceptos basicos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc00b.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc01.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>0.3. Pseudocódigo</h3>

<p>A pesar de que los lenguajes de alto nivel se acercan al lenguaje 
natural, que nosotros empleamos, es habitual no usar ningún lenguaje 
de programación concreto cuando queremos plantear inicialmente los pasos necesarios para 
resolver un problema, sino emplear un lenguaje de programaci ón ficticio, no 
tan estricto, muchas veces escrito incluso en español. Este lenguaje recibe 
el nombre de <b>pseudocódigo</b>.</p>

<p>Esa secuencia de pasos para resolver un problema es lo que se conoce como 
<b>algoritmo</b> (realmente hay alguna condición m&aacute;s, por ejemplo, 
debe ser un número finito de pasos). Por tanto, un programa de ordenador es 
un algoritmo expresado usando un lenguaje de programación.</p>

<p>Por ejemplo, un algoritmo que controlase los pagos que se realizan en una 
tienda con tarjeta de cr&eacute;dito, escrito en pseudocódigo, podr&iacute;a 
ser algo como:</p>

<p><pre><code class='language-txt'>Leer banda magnÃ©tica de la tarjeta
Conectar con central de cobros
Si hay conexiÃ³n y la tarjeta es correcta:
    Pedir cÃ³digo PIN
    Si el PIN es correcto
        Comprobar saldo_existente
        Si saldo_existente > importe_compra
            Aceptar la venta
            Descontar importe del saldo.
        Fin Si
    Fin Si
Fin Si</code></pre></p>
<p>Como se ve en este ejemplo, es habitual que el pseudocódigo sea todavía 
de más alto nivel que un lenguaje de programación real, y que cada paso 
corresponda a más de una orden. Por ejemplo ese “conectar con central de 
cobros” podría suponer varios pasos como: establecer una conexión 
encriptada, comprobar la identidad del servidor al que conectamos, enviar la 
identificación de nuestro comercio y esperar aceptación, etc.</p>

<p>&nbsp;</p>
<p><b>Ejercicios propuestos</b></p>
<ol>
<li>Localizar en Internet el int&eacute;rprete de Basic llamado Bywater Basic, en su versión para el sistema operativo que se est&eacute; utilizando y probar el primer programa de ejemplo que se ha visto en el apartado 0.1.</li>
<li>Localizar en Internet el compilador de Pascal llamado Free Pascal, en su versión para el sistema operativo que se est&eacute; utilizando, instalarlo y probar el segundo programa de ejemplo que se ha visto en el apartado 0.1.</li>
<li>Localizar un compilador de C para el sistema operativo que se est&eacute; utilizando (si es Linux o alguna otra versión de Unix, es f&aacute;cil que se encuentre ya instalado) y probar el tercer programa de ejemplo que se ha visto en el apartado 0.1.</li>
</ol>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   23369 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc00b.php">Anterior</a></li>
                    <li><a href="cc01.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        