<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 0 - Conceptos basicos</title>

    
    <meta name="description" content="Tutorial de C - Tema 1 - Toma de contacto con C - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="interprete,compilador,ensamblador,c,pascal,basic" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 0 - Conceptos basicos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc00.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc00b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>0.1. Lenguajes de alto nivel y de bajo nivel.</h3>
<p>Vamos a ver en primer lugar alg&uacute;n ejemplo de lenguaje de alto nivel, para despu&eacute;s comparar con lenguajes de bajo nivel, que son los m&aacute;s cercanos al ordenador.</p>

<p>Uno de los lenguajes de alto nivel m&aacute;s sencillos es el lenguaje BASIC. En este lenguaje, escribir el texto Hola en pantalla, ser&iacute;a tan sencillo como usar la orden</p>

<p><pre><code class='language-qbasic'>PRINT "Hola"</code></pre></p>
<p>Otros lenguajes, como Pascal, nos obligan a ser algo m&aacute;s estrictos, pero a cambio hacen m&aacute;s f&aacute;cil descubrir errores:</p>

<p><pre><code class='language-pascal'>program Saludo;

begin
  write('Hola');
end.</code></pre></p>

<p>El equivalente en lenguaje C resulta algo m&aacute;s dif&iacute;cil de leer, por motivos que iremos comentando un poco m&aacute;s adelante:</p>

<p><pre><code class='language-c'>#include <stdio.h>
 
int main() 
{
  printf("Hola");
  return 0;
}</code></pre></p>


<p>Los lenguajes de <b>bajo nivel</b> son m&aacute;s cercanos al ordenador que a los lenguajes humanos. Eso hace que sean m&aacute;s dif&iacute;ciles de aprender y tambi&eacute;n que los fallos sean m&aacute;s dif&iacute;ciles de descubrir y corregir, a cambio de que podemos optimizar al m&aacute;ximo la velocidad (si sabemos c&oacute;mo), e incluso llegar a un nivel de control del ordenador que a veces no se puede alcanzar con otros lenguajes. Por ejemplo, escribir Hola en lenguaje ensamblador de un ordenador equipado con el sistema operativo MsDos y con un procesador de la familia Intel x86 ser&iacute;a algo como</p>

<p><pre><code class='language-asm'>dosseg
.model small
.stack 100h

.data
hello_message db 'Hola',0dh,0ah,'$'

.code
main  proc
      mov    ax,@data
      mov    ds,ax

      mov    ah,9
      mov    dx,offset hello_message
      int    21h

      mov    ax,4C00h
      int    21h
main  endp
end   main</code></pre></p>

<p>Resulta bastante m&aacute;s dif&iacute;cil de seguir. Pero eso todav&iacute;a no es lo que el ordenador entiende, aunque tiene una equivalencia casi directa. Lo que el ordenador realmente es capaz de comprender son secuencias de ceros y unos. Por ejemplo, las &oacute;rdenes "mov ds, ax" y "mov ah, 9" (en cuyo significado no vamos a entrar) se convertir&iacute;an a lo siguiente:</p>

<p><pre><code class='language-txt'>1000 0011 1101 1000 1011 0100 0000 1001</code></pre></p>
<p>(Nota: los colores de los ejemplos anteriores son una ayuda que nos dan 
algunos entornos de programaci&oacute;n, para que nos sea m&aacute;s 
f&aacute;cil descubrir errores. No todos los entornos mostrarán nuestros 
programas con colores, ni existe un único estándar de paleta de colores universalmente 
aceptados).<br /> </p>

<p><b>Ejercicios propuestos:</b></p>
<ul>

<li><b>0.1.1</b>: Localiza en Internet el intérprete de BASIC llamado Bywater Basic, en su versión para el sistema operativo que estés utilizando (o algún otro intérprete de BASIC clásico, como un emulador de un Amstrad CPC, un MSX o un Commodore 64) y prueba el primer programa de ejemplo que se ha visto en el apartado 0.1. (Nota: no es imprescindible para seguir el curso; puedes omitir este ejercicio si no quieres instalar en tu equipo software que quizá no vuelvas a utilizar).</li>
<li><b>0.1.2</b>: Localiza en Internet el compilador de Pascal llamado Free Pascal, en su versión para el sistema operativo que estés utilizando y prueba el segundo programa de ejemplo que se ha visto en el apartado 0.1. (Nota: no es imprescindible para seguir el curso; puedes omitir este ejercicio si no quieres instalar nada en tu equipo).</li>
</ul>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   24286 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc00.php">Anterior</a></li>
                    <li><a href="cc00b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        