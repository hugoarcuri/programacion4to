<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 6 - Ficheros</title>

    
    <meta name="description" content="Curso de C - Tema 6 - Ficheros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="aleatorio,fichero,texto,fopen,fclose,eof,feof,fgets,fprintf,fscanf,fread,fwrite" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 6 - Ficheros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc06l.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc06n.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>6.13. Un ejemplo de lectura y escritura: TAG de un MP3</h3>
<p>Los ficheros de sonido en formato MP3 pueden contener informaci&oacute;n sobre el autor, el t&iacute;tulo, etc. Si la contienen, se encontrar&iacute;a a 128 bytes del final del fichero. Los primeros 3 bytes de esos 128 deber&iacute;an ser las letras TAG. A continuaci&oacute;n, tendr&iacute;amos otros 30 bytes que ser&iacute;an el t&iacute;tulo de la canci&oacute;n, y otros 30 bytes que ser&iacute;an el nombre del autor. Con esto ya podr&iacute;amos crear un programa que lea esa informaci&oacute;n de un fichero MP3 (si la contiene) e incluso que la modifique.</p>
<p>Estos textos (t&iacute;tulo, autor y otros) deber&iacute;an estar rellenos con caracteres nulos al final, pero es algo de lo que no tenemos la certeza, porque algunas aplicaciones lo rellenan con espacios (es el caso de alguna versi&oacute;n de WinAmp). Por eso, leeremos los datos con &ldquo;fread&rdquo; y a&ntilde;adiremos un car&aacute;cter nulo al final de cada uno.</p>
<p>Adem&aacute;s, haremos que el programa nos muestre la informaci&oacute;n de varios ficheros: nos pedir&aacute; un nombre, y luego otro, y as&iacute; sucesivamente hasta que pulsemos Intro sin teclear nada m&aacute;s.<br />
</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 62:      */
/*  C062.C                   */
/*                           */
/*  Lectura y escritura en   */
/*  un fichero               */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>
#include <string.h>

int main() {
    FILE* fich;
    char temp[31];
    int i;

    do {
    /* Pido el nombre del fichero */    
    printf("\nEscribe el nombre del fichero MP3 a comprobar: ");
    gets(temp);
    /* Si no teclea nada, terminaré */    
    if (strcmp(temp,"")==0) 
        puts("\nAplicacion finalizada.");
    /* Si existe nombre, intento abrir */
    else if ( (fich=fopen(temp,"r+b"))!=NULL ){
        /* Si he podido abrir, muestro el nombre */
        printf("Nombre del fichero: %s\n",temp);
        /* Miro el tamaño del fichero */
        fseek(fich,0,SEEK_END);            
        printf("Tamaño: %d\n",ftell(fich));
        /* A 128 bytes está la marca "TAG" */
        fseek(fich,-128,SEEK_END);
        fread(temp,3,1,fich);
        /* Son 3 letras, añado caracter nulo al final */
        temp[3]='\0';
        if (strcmp(temp,"TAG")!=0) 
            puts("No se encontró información válida.");
        else {
            /* Si existe la marca, leo los datos */
            /* Primero, 30 letras de titulo */
            fread(temp,30,1,fich);
            temp[strlen(temp)]='\0';
            printf("Titulo: %s\n",temp);
            /* Luego 30 letras de autor */
            fread(temp,30,1,fich);
            temp[strlen(temp)]='\0';
            printf("Artista: %s\n",temp);
            /* Ahora vamos a modificar el titulo */
            printf("\nIntroduce el nuevo titulo: ");
            gets(temp);
            /* Lo rellenamos con ceros, para seguir el estándar */
            for (i=strlen(temp); i<=29; i++)
                temp[i]='\0';               
            /* Y lo guardamos en su posición */
            fseek(fich,-125,SEEK_END);
            fwrite(&temp, 30, 1, fich);
            printf("Titulo actualizado.\n");
            fclose(fich);
            } /* Fin del "else" de MP3 con informacion */
    } /* Fin del "else" de fichero existente */
    else puts("No se pudo abrir el fichero\n");
    } /* Fin del "do..while" que repite hasta que no se escriba nombre */
    while (strcmp(temp,"")!=0);
    
    return 0;
}
</code></pre></p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   21748 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc06l.php">Anterior</a></li>
                    <li><a href="cc06n.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        