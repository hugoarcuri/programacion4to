<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 1 - Toma de contacto con C</title>

    
    <meta name="description" content="Tutorial de C - Tema 1 - Toma de contacto con C - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="C,main,compilar,enlazar,printf" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 1 - Toma de contacto con C          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc00c.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc01a.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        <h2>1. Toma de contacto con C</h2>

<p>Dentro de los lenguajes de programaci&oacute;n, C es un lenguaje que tiene un cierto &ldquo;<b>prestigio</b>&rdquo;. Esto se debe fundamentalmente a dos razones:</p>
<ul>
  <li> Es bastante &ldquo;<b>portable</b>&rdquo;: un programa bien hecho en C se podr&aacute; llevar a un ordenador distinto o incluso a un sistema operativo distinto (de MsDos a Windows o a Linux, por ejemplo) con muy pocos cambios o quiz&aacute;s incluso sin ning&uacute;n cambio. El motivo es que existe un est&aacute;ndar: el <b>ANSI C</b>, que soportan casi todos los compiladores. Por eso, si nos ce&ntilde;imos al est&aacute;ndar, es seguro que nuestros programas funcionar&aacute;n en distintos sistemas; cuanto m&aacute;s nos separemos del est&aacute;ndar (en ocasiones podremos hacerlo), m&aacute;s dif&iacute;cil ser&aacute; que funcionen en otro sistema distinto.</li>
  </ul>
<p>&nbsp;</p>
<ul>
  <li>Permite hacer &ldquo;<b>casi de todo</b>&rdquo;: podemos usar &oacute;rdenes de alto nivel (muy cercanas al lenguaje humano), pero tambi&eacute;n de bajo nivel (m&aacute;s cercanas a lo que realmente entiende el ordenador). De hecho, podremos incluso incorporar &oacute;rdenes en lenguaje ensamblador en medio de un programa escrito en C, aunque eso supone que ganemos en control de la m&aacute;quina que estamos manejando, a costa de perder en portabilidad (el programa ya no se podr&aacute; llevar a otros ordenadores que no usen el mismo lenguaje ensamblador).</li>
</ul>
<p>&nbsp;</p>
<p><b>En su contra</b>, el lenguaje C tiene que es m&aacute;s dif&iacute;cil de aprender que otros y que puede resultar dif&iacute;cil de leer (por lo que ciertos errores pueden tardar m&aacute;s en encontrarse).<br />
</p>
<p>Los <b>pasos</b> que seguiremos para crear un programa en C ser&aacute;n:</p>
<ol>
  <li> Escribir el programa en lenguaje C (<b>fichero fuente</b>), con cualquier editor de textos.</li>
  <li>Compilarlo con nuestro compilador. Esto crear&aacute; un &ldquo;<b>fichero objeto</b>&rdquo;, ya convertido a un lenguaje que el ordenador es capaz de entender.</li>
  <li> Enlazarlo con otros ficheros del compilador, unas bibliotecas auxiliares que incluir&aacute;n en nuestro programa aquellas posibilidades que hayamos empleado nosotros pero que realmente no sean parte del lenguaje C b&aacute;sico, sino ampliaciones de alg&uacute;n tipo. Esto dar&aacute; lugar al <b>fichero ejecutable</b>, que ya podremos usar desde MsDos o el sistema operativo que estemos manejando, en nuestro ordenador o en cualquier otro, aunque ese otro ordenador no tenga el compilador que nosotros hemos utilizado.</li>
</ol>
<p>La mayor&iacute;a de los compiladores actuales permiten dar todos estos pasos desde un &uacute;nico <b>entorno</b>, en el que escribimos nuestros programas, los compilamos, y los depuramos en caso de que exista alg&uacute;n fallo.</p>
<p>En el siguiente apartado veremos un ejemplo de uno de estos entornos, d&oacute;nde localizarlo y c&oacute;mo instalarlo.</p>
<p></p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   28167 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc00c.php">Anterior</a></li>
                    <li><a href="cc01a.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        