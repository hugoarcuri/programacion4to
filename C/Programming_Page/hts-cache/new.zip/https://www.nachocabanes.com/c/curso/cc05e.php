<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema  5 - Arrays y estructuras</title>

    
    <meta name="description" content="Curso de C - Tema  5 - Arrays y estructuras - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="array,arreglo,struct,vector,matriz,estructura,registro" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema  5 - Arrays y estructuras          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc05d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc05f.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>5.5. Estructuras</h3>
<h4>5.5.1. Definici&oacute;n y acceso a los datos</h4>
<p>Un <strong>registro</strong> es una agrupaci&oacute;n de datos, los cuales no necesariamente son del mismo tipo. Se definen con la palabra &ldquo;<strong>struct</strong>&rdquo;.</p>
<p>Para acceder a cada uno de los datos que forman el registro, tanto si queremos leer su valor como si queremos cambiarlo, se debe indicar el nombre de la variable y el del dato (o campo) separados por un punto:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 50:      */
/*  C050.C                   */
/*                           */
/*  Registros (struct)       */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

int main()
{
  struct 
  {
    char  inicial;
    int   edad;
    float nota;
  } persona;

  persona.inicial = 'J';
  persona.edad = 20;
  persona.nota = 7.5;
  printf("La edad es %d", persona.edad);
          
  return 0;
}
</code></pre></p>

<p>Como es habitual en C, para declarar la variable hemos indicado primero el tipo de datos (struct { ...} ) y despu&eacute;s el nombre que tendr&aacute; esa variable (persona). </p>
<p>Tambi&eacute;n podemos declarar primero c&oacute;mo van a ser nuestros registros, y m&aacute;s adelante definir variables de ese tipo: </p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 51:      */
/*  C051.C                   */
/*                           */
/*  Registros (2)            */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

struct datosPersona 
{
  char  inicial;
  int   edad;
  float nota;
};

int main()
{
  struct datosPersona ficha;

  ficha.inicial = 'J';
  ficha.edad = 20;
  ficha.nota = 7.5;
  printf("La edad es %d", ficha.edad);
          
  return 0;
}
</code></pre></p>

<p><strong>Ejercicios propuestos: </strong></p>
<ul>
  <li> Un “struct” que almacene datos de una canci&oacute;n en formato MP3: Artista, T&iacute;tulo, Duraci&oacute;n (en segundos), Tama&ntilde;o del fichero (en KB). Un programa debe pedir los datos de una canci&oacute;n al usuario, almacenarlos en dicho “struct” y despu&eacute;s mostrarlos en pantalla. </li>
</ul>
<h4>5.5.2. Arrays de estructuras</h4>
<p>Hemos guardado varios datos de una persona. Se pueden almacenar los de <strong>varias personas</strong> si combinamos el uso de los &ldquo;struct&rdquo; con las tablas (arrays) que vimos anteriormente. Por ejemplo, si queremos guardar los datos de 100 alumnos podr&iacute;amos hacer:</p>

<p><pre><code class='language-c'>struct
{ 
  char inicial; 
  int edad; 
  float nota; 
} alumnos[100]; 
</code></pre></p>
<p>La inicial del primer alumno ser&iacute;a &ldquo;alumnos[0].inicial&rdquo;, y la edad del &uacute;ltimo ser&iacute;a &ldquo;alumnos[99].edad&rdquo;.</p>
<p><strong>Ejercicios propuestos: </strong></p>
<ul>
  <li> Ampliar el programa del apartado 5.5.1, para que almacene datos de hasta 100 canciones. Deber&aacute; tener un men&uacute; que permita las opciones: a&ntilde;adir una nueva canci&oacute;n, mostrar el t&iacute;tulo de todas las canciones, buscar la canci&oacute;n que contenga un cierto texto (en el artista o en el t&iacute;tulo). </li>
  <li> Un programa que permita guardar datos de &quot;im&aacute;genes&quot; (ficheros de ordenador que contengan fotograf&iacute;as o cualquier otro tipo de informaci&oacute;n gr&aacute;fica). De cada imagen se debe guardar: nombre (texto), ancho en p&iacute;xeles (por ejemplo 2000), alto en p&iacute;xeles (por ejemplo, 3000), tama&ntilde;o en Kb (por ejemplo 145,6). El programa debe ser capaz de almacenar hasta 700 im&aacute;genes (deber&aacute; avisar cuando su capacidad est&eacute; llena). Debe permitir las opciones: a&ntilde;adir una ficha nueva, ver todas las fichas (n&uacute;mero y nombre de cada imagen), buscar la ficha que tenga un cierto nombre. </li>
</ul>
<p>&nbsp;</p>
<h4>5.5.3. Estructuras anidadas</h4>
<p>Podemos encontrarnos con un registo que tenga varios datos, y que a su vez ocurra que uno de esos datos est&eacute; formado por varios datos m&aacute;s sencillos. Para hacerlo desde C, incluir&iacute;amos un &ldquo;struct&rdquo; dentro de otro, as&iacute;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 52:      */
/*  C052.C                   */
/*                           */
/*  Registros anidados       */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>

struct fechaNacimiento 
{
  int  dia;
  int  mes;
  int anyo;
};

struct 
{
  char  inicial;
  struct fechaNacimiento diaDeNacimiento;
  float nota;
} persona;

int main()
{
  persona.inicial = 'I';
  persona.diaDeNacimiento.mes = 8;
  persona.nota = 7.5;
  printf("La nota es %f", persona.nota);
          
  return 0;
}
</code></pre></p>
<p><strong>Ejercicios propuestos: </strong></p>
<ul>
  <li> Ampliar el programa del primer apartado de 5.5.2, para que el campo “duraci&oacute;n” se almacene como minutos y segundos, usando un “struct” anidado que contenga a su vez estos dos campos. </li>
  </ul>
<p>&nbsp;</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   42656 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc05d.php">Anterior</a></li>
                    <li><a href="cc05f.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        