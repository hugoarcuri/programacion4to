<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 6 - Ficheros</title>

    
    <meta name="description" content="Curso de C - Tema 6 - Ficheros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="aleatorio,fichero,texto,fopen,fclose,eof,feof,fgets,fprintf,fscanf,fread,fwrite" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 6 - Ficheros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc06h.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc06j.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>6.9 Acceder a cualquier posici&oacute;n de un fichero</h3>
<p>Cuando trabajamos con un fichero, es posible que necesitemos <strong>acceder</strong> directamente a una cierta posici&oacute;n del mismo. Para ello usamos &ldquo;<strong>fseek</strong>&rdquo;, que tiene el formato:</p>
<p> int fseek(FILE *fichero, long posicion, int desde);<br />
</p>
<p> Como siempre, comentemos qu&eacute; es cada cosa:</p>
<ul>
  <li>  Es de tipo &ldquo;int&rdquo;, lo que quiere decir que nos va a devolver un valor, para que comprobemos si realmente se ha podido saltar a la direcci&oacute;n que nosotros le hemos pedido: si el valor es 0, todo ha ido bien; si es otro, indicar&aacute; un error (normalmente, que no hemos abierto el fichero).</li>
  <li>&ldquo;fichero&rdquo; indica el fichero dentro de el que queremos saltar. Este fichero debe estar abierto previamente (con fopen).</li>
  <li>&ldquo;posici&oacute;n&rdquo; nos permite decir a qu&eacute; posici&oacute;n queremos saltar (por ejemplo, a la 5010).</li>
  <li>&ldquo;desde&rdquo; es para poder afinar m&aacute;s: la direcci&oacute;n que hemos indicado con posic puede estar referida al comienzo del fichero, a la posici&oacute;n en la que nos encontramos actualmente, o al final del fichero (entonces posic deber&aacute; ser negativo). Para no tener que recordar que un 0 quiere decir que nos referimos al principio, un 1 a la posici&oacute;n actual y un 2 a la final, tenemos definidas las constantes:</li>
</ul>
<blockquote>
  <p> SEEK_SET (0): Principio<br />
      SEEK_CUR (1): Actual<br />
      SEEK_END (2): Final</p>
</blockquote>
<p>&nbsp;</p>
<p>Vamos a ver tres ejemplos de su uso:</p>
<ul>
  <li> Ir a la posici&oacute;n 10 del fichero: fseek(miFichero, 10, SEEK_SET);</li>
  <li>Avanzar 5 posiciones a partir de la actual: fseek(miFichero, 5, SEEK_CUR);</li>
  <li> Ir a la posici&oacute;n 8 antes del final del fichero: fseek(miFichero, -8, SEEK_END);<br />
  </li>
</ul>
<p>Finalmente, si queremos saber en<strong> qu&eacute; posici&oacute;n</strong> de un fichero nos encontramos, podemos usar &ldquo;<strong>ftell</strong>(fichero)&rdquo;.</p>
<p>Esta orden nos permite saber tambi&eacute;n la <strong>longitud</strong> de un fichero: nos posicionamos primero al final con &ldquo;fseek&rdquo; y luego comprobamos con &ldquo;ftell&rdquo; en qu&eacute; posici&oacute;n estamos:</p>
<p> fseek(fichero, 0, SEEK_END);<br />
  longitud = ftell(fichero);</p>
<p><strong>Ejercicios propuestos </strong>: </p>
<ul>
  <li> Ampliar el programa anterior (el “array de structs” con 10 personas) para que el dato que indique el usuario se lea sin leer y descartar antes los que le preceden, sino que se salte directamente a la ficha deseada usando “fseek”. </li>
</ul>
<p>&nbsp;</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   21808 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc06h.php">Anterior</a></li>
                    <li><a href="cc06j.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        