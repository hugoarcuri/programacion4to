<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de C - Tema 9 - Punteros</title>

    
    <meta name="description" content="Curso de C - Tema 9 - Punteros - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="punteros,malloc,free,argc,argv,pointer,null" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de C - Tema 9 - Punteros          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cc09j.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cc09l.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #000080;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #000080;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h3>9.11. Estructuras din&aacute;micas habituales 2: los &aacute;rboles binarios</h3>
<p>En las listas, despu&eacute;s de cada elemento hab&iacute;a otro, el &ldquo;siguiente&rdquo; (o ninguno, si hab&iacute;amos llegado al final). </p>
<p>Pero tambi&eacute;n nos puede interesar tener varias posibilidades despu&eacute;s de cada elemento, varios &ldquo;hijos&rdquo;, por ejemplo 3. De cada uno de estos 3 &ldquo;hijos&rdquo; saldr&iacute;an otros 3, y as&iacute; sucesivamente. Obtendr&iacute;amos algo que recuerda a un &aacute;rbol: un tronco del que nacen 3 ramas, que a su veces se subdividen en otras 3 de menor tama&ntilde;o, y as&iacute; sucesivamente hasta llegar a las hojas.</p>
<p>Pues eso mismo ser&aacute; un &aacute;rbol: una estructura din&aacute;mica en la que cada nodo (elemento) puede tener m&aacute;s de un &ldquo;siguiente&rdquo;. Nos centraremos en los <strong>&aacute;rboles binarios</strong>, en los que cada nodo puede tener un hijo izquierdo, un hijo derecho, ambos o ninguno (dos hijos como m&aacute;ximo). </p>
<p align="center"><img src="cc_arbol.jpg" width="211" height="166" /></p>
<p>Para puntualizar aun m&aacute;s, trataremos los &aacute;rboles binarios de <strong>b&uacute;squeda</strong>, en los que tenemos prefijado un cierto orden, que nos ayudar&aacute; a encontrar un cierto dato dentro de un &aacute;rbol con mucha rapidez.</p>
<p>Este &quot;<strong>orden</strong> prefijado&quot; ser&aacute; el siguiente: para cada nodo tendremos que<br />
  * la rama de la izquierda contendr&aacute; elementos menores que &eacute;l.<br />
  * la rama de la derecha contendr&aacute; elementos mayores que &eacute;l.</p>
<p>Para que se entienda mejor, vamos a introducir en un &aacute;rbol binario de b&uacute;squeda los datos 5,3,7,2,4,8,9</p>
<p> Primer n&uacute;mero: 5 (directo)</p>
<p> 5</p>
<p> Segundo n&uacute;mero: 3 (menor que 5)</p>
<p> <span class="nsource">&nbsp;5<br />
  /<br />
  3</span></p>
<p> Tercer n&uacute;mero: 7 (mayor que 5)</p>
<p> <span class="nsource">&nbsp;5<br />
  / \<br />
  3 7</span></p>
<p> Cuarto: 2 (menor que 5, menor que 3)</p>
<p class="nsource"> &nbsp;&nbsp; 5<br />
 &nbsp; / \<br />
 &nbsp; 3 7<br />
  /<br />
  2</p>
<p> Quinto: 4 (menor que 5, mayor que 3)<br />
  </p>
<p><span class="nsource"> &nbsp;&nbsp; 5<br />
   &nbsp; / \<br />
   &nbsp; 3 7<br />
   &nbsp;/ \<br />
   &nbsp;2 4</span></p>
<p> Sexto: 8 (mayor que 5, mayor que 7)</p>
<p class="nsource"> 5<br />
  / \<br />
  3 7<br />
  / \ \<br />
  2 4 8</p>
<p> S&eacute;ptimo: 9 (mayor que 5, mayor que 7, mayor que 8)</p>
<p> <span class="nsource">&nbsp;&nbsp; 5<br />
 &nbsp; / \<br />
 &nbsp;3&nbsp; 7<br />
 &nbsp;/ \ \<br />
 &nbsp;2 4&nbsp; 8<br />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \<br />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9</span><br />
&iquest;Qu&eacute; <strong>ventajas</strong> tiene esto? La rapidez: tenemos 7 elementos, lo que en una lista supone que si buscamos un dato que casualmente est&aacute; al final, haremos 7 comparaciones; en este &aacute;rbol, tenemos 4 alturas =&gt; 4 comparaciones como m&aacute;ximo.</p>
<p>Y si adem&aacute;s hubi&eacute;ramos &ldquo;<strong>equilibrado</strong>&rdquo; el &aacute;rbol (irlo recolocando, de modo que siempre tenga la menor altura posible), ser&iacute;an 3 alturas. Esto es lo que se hace en la pr&aacute;ctica cuando en el &aacute;rbol se va a hacer muchas m&aacute;s lecturas que escrituras: se reordena internamente despu&eacute;s de a&ntilde;adir cada nuevo dato, de modo que la altura sea m&iacute;nima en cada caso. De este modo, el n&uacute;mero m&aacute;ximo de comparaciones que tendr&iacute;amos que hacer ser&iacute;a log2(n), lo que supone que si tenemos 1000 datos, en una lista podr&iacute;amos llegar a tener que hacer 1000 comparaciones, y en un &aacute;rbol binario, log2(1000) =&gt; 10 comparaciones como m&aacute;ximo. La ganancia en velocidad de b&uacute;squeda es clara.</p>
<p>No vamos a ver c&oacute;mo se hace eso de los &ldquo;equilibrados&rdquo;, que ser&iacute;a propio de un curso de programaci&oacute;n m&aacute;s avanzado, pero s&iacute; vamos a empezar a ver rutinas para manejar estos &aacute;rboles binarios de b&uacute;squeda.</p>
<p>Recordemos que la idea importante es que todo dato menor estar&aacute; a la izquierda del nodo que miramos, y los datos mayores estar&aacute;n a su derecha.</p>
<p>Ahora la estructura de cada <strong>nodo</strong> (dato) ser&aacute;:</p>
<p class="nsource">struct arbol { /* El tipo base en s&iacute;: */<br />
 &nbsp;&nbsp; int dato; /* - un dato (entero) */<br />
 &nbsp;&nbsp; struct arbol* hijoIzq; /* - puntero a su hijo izquierdo */<br />
 &nbsp;&nbsp; struct arbol* hijoDer; /* - puntero a su hijo derecho */<br />
  };<br />
</p>
<p>Y las rutinas de inserci&oacute;n, b&uacute;squeda, escritura, borrado, etc., podr&aacute;n ser recursivas. Como primer ejemplo, la de <strong>escritura</strong> de todo el &aacute;rbol en orden ser&iacute;a:<br />
    <br />
    <span class="nsource">void Escribir(struct arbol *punt)<br />
    {<br />
 &nbsp;&nbsp; if (punt) /* Si no hemos llegado a una hoja */<br />
 &nbsp;&nbsp; {<br />
 &nbsp;&nbsp;&nbsp;&nbsp; Escribir(punt-&gt;hijoIzq); /* Mira la izqda recursivamente */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; printf(&quot;%d &quot;,punt-&gt;dato); /* Escribe el dato del nodo */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; Escribir(punt-&gt;hijoDer); /* Y luego mira por la derecha */<br />
 &nbsp;&nbsp; };<br />
  };<br />
  </span></p>
<p>Quien no se crea que funciona, deber&iacute;a coger l&aacute;piz y papel comprobarlo con el &aacute;rbol que hemos visto antes como ejemplo. Es muy importante que esta funci&oacute;n quede clara antes de seguir leyendo, porque los dem&aacute;s ser&aacute;n muy parecidos.</p>
<p>La rutina de <strong>inserci&oacute;n</strong> ser&iacute;a parecida, aunque algo m&aacute;s &quot;pesada&quot; porque tenemos que pasar el puntero por referencia, para que se pueda modificar el puntero:</p>
<p class="nsource">void Insertar(struct arbol **punt, int valor)<br />
  {<br />
 &nbsp;&nbsp; struct arbol * actual= *punt;<br />
 &nbsp;&nbsp; if (actual == NULL) /* Si hemos llegado a una hoja */<br />
 &nbsp;&nbsp; {<br />
 &nbsp;&nbsp;&nbsp;&nbsp; *punt = (struct arbol *) <br />
 &nbsp;&nbsp;&nbsp;&nbsp; malloc (sizeof(struct arbol)); /* Reservamos memoria */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; actual= *punt;<br />
 &nbsp;&nbsp;&nbsp;&nbsp; actual-&gt;dato = valor; /* Guardamos el dato */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; actual-&gt;hijoIzq = NULL; /* No tiene hijo izquierdo */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; actual-&gt;hijoDer = NULL; /* Ni derecho */<br />
 &nbsp;&nbsp; }<br />
 &nbsp;&nbsp; else /* Si no es hoja */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; if (actual-&gt;dato &gt; valor) /* Y encuentra un dato mayor */<br />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Insertar(&amp;actual-&gt;hijoIzq, valor); /* Mira por la izquierda */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; else /* En caso contrario (menor) */</p>
<p class="nsource"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Insertar(&amp;actual-&gt;hijoDer, valor); /* Mira por la derecha */<br />
  };</p>
<p>Y finalmente, la de <strong>borrado</strong> de todo el &aacute;rbol, casi igual que la de escritura, s&oacute;lo que en vez de borrar la izquierda, luego el nodo y luego la derecha, borraremos primero las dos ramas y en &uacute;ltimo lugar el nodo, para evitar incongruencias (intentar borrar el hijo de algo que ya no existe):</p>
<p class="nsource">void Borrar(struct arbol *punt)<br />
  {<br />
 &nbsp;&nbsp; if (punt) /* Si no hemos llegado a una hoja */<br />
 &nbsp;&nbsp; {<br />
 &nbsp;&nbsp;&nbsp;&nbsp; Borrar(punt-&gt;hijoIzq); /* Va a la izqda recursivamente */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; Borrar(punt-&gt;hijoDer); /* Y luego a la derecha */<br />
 &nbsp;&nbsp;&nbsp;&nbsp; free (punt); /* Finalmente, libera lo que ocupa el nodo */<br />
 &nbsp;&nbsp; };<br />
  };<br />
</p>
<p>Vamos a juntar todo esto en un ejemplo &quot;que funcione&quot;:</p>

<p><pre><code class='language-c'>/*---------------------------*/
/*  Ejemplo en C nº 83:      */
/*  C083.C                   */
/*                           */
/*  Arbol binario de         */
/*  búsqueda                 */
/*                           */
/*  Curso de C,              */
/*    Nacho Cabanes          */
/*---------------------------*/

#include <stdio.h>
#include <stdlib.h>

struct arbol {             /*  El tipo base en sí: */
      int dato;               /*    - un dato (entero) */
      struct arbol* hijoIzq;  /*    - puntero a su hijo izquierdo */
      struct arbol* hijoDer;  /*    - puntero a su hijo derecho */
 };

void Escribir(struct arbol *punt)
{
    if (punt)                  /*  Si no hemos llegado a una hoja */
    {
        Escribir(punt->hijoIzq);   /*  Mira la izqda recursivamente */
        printf("%d ",punt->dato);  /*  Escribe el dato del nodo */
        Escribir(punt->hijoDer);   /*  Y luego mira por la derecha */
    }
}

void Insertar(struct arbol **punt, int valor)
{
    struct arbol * actual= *punt;
    if (actual == NULL)              /*  Si hemos llegado a una hoja */
    {
      *punt = (struct arbol *) 
         malloc (sizeof(struct arbol));  /* Reservamos memoria */
      actual= *punt;
      actual->dato = valor;         /* Guardamos el dato */
      actual->hijoIzq = NULL;       /* No tiene hijo izquierdo */
      actual->hijoDer = NULL;       /* Ni derecho */
    }
    else                                   /*      Si no es hoja      */
   if (actual->dato > valor)              /* Y encuentra un dato mayor */
      Insertar(&actual->hijoIzq, valor);  /* Mira por la izquierda */
   else                                   /* En caso contrario (menor) */

      Insertar(&actual->hijoDer, valor);  /* Mira por la derecha */
}

/*  Cuerpo del programa  */
int main()
{
    struct arbol *arbol = NULL;
    Insertar(&arbol, 5);
    Insertar(&arbol, 3);
    Insertar(&arbol, 7);
    Insertar(&arbol, 2);
    Insertar(&arbol, 4);
    Insertar(&arbol, 8);
    Insertar(&arbol, 9);
    Escribir(arbol);
    return 0;
}
</code></pre></p>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   8217 visitas desde el 29-01-2007</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cc09j.php">Anterior</a></li>
                    <li><a href="cc09l.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        