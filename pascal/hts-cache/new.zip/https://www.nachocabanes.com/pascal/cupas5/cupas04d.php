<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 4 - Arrays, cadenas, registros y conjuntos (4: conjuntos y otros).</title>

    
    <meta name="description" content="4 - Arrays, cadenas, registros y conjuntos (4: conjuntos y otros). - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="array,record,set,string" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 4 - Arrays, cadenas, registros y conjuntos (4: conjuntos y otros).          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas04c.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas05.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2>4.4. Otros tipos de datos: conjuntos, enumerados y subrangos</h2>

<p>Vamos a ver algún otro tipo de datos, quizá menos utilizado que los anteriores,
pero que ayudan a que nuestros programas sean más elegantes y más legibles.</p>

<h3>4.4.1. Subrangos</h3>

<p>Podemos indicar los posibles valores que puede tomar
una variable, indicándolo en forma de <b>subrango</b>, al igual
que se hace con los índices de un array:
</p>

<p><pre><code class='language-pascal'>
var
  dia: 1..31;
</code></pre></p>
<p>Un ejemplo completo podría ser así:</p>

<p><pre><code class='language-pascal'>(* SUBRANGO1.PAS, Variables de tipo "subrango"  *)
(* Parte de CUPAS5, por Nacho Cabanes           *)

program SubRango1;

var
  dia: 1..31;

begin
    write('Introduce el dia: ');
    readLn(dia);
    
    writeLn('Has tecleado ', dia);
end. 

(* 
Ejemplo de ejecucion 1:
Introduce el dia: 12
Has tecleado 12

Ejemplo de ejecucion 2:
Introduce el dia: 45
Has tecleado 45
*)
</code></pre></p>
<p>Pero hay que tener una precaución: estas construcciones hacen nuestro programa más legible,
pero es frecuente que el compilador no haga comprobaciones para asegurarse de que los
valores realmente deban estar en ese rango, de modo que se nos permitirá 
introducir valores mayores o menores, como se ve en ese ejemplo.</p>

<p>Como alternativa, en algunos compiladores podemos forzar que se comprueben errores
de valores fuera de rango en tiempo de ejecución, de modo que el programa se
interrumpiría con un código de error (que más adelante veremos cómo
interceptar) si ese valor introducido no es correcto. En Turbo Pascal y Free Pascal,
esto se consigue incluyendo en nuestro programa la directiva {$R+}, así:</p>

<p><pre><code class='language-pascal'>(* SUBRANGO2.PAS, Variables de tipo "subrango"  *)
(* Version con comprobacion de rangos           *)
(* Parte de CUPAS5, por Nacho Cabanes           *)

{$R+}

program SubRango2;

var
  dia: 1..31;

begin
    write('Introduce el dia: ');
    readLn(dia);
    
    writeLn('Has tecleado ', dia);
end. 

(* Ejemplo de ejecucion:
Introduce el dia: 45
Runtime error 201 at $080480FB
  $080480FB
  $08063733
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.4.1.1:</b> Crea un programa que pida un dato del 1 al 12 y muestre el nombre del mes
    correspondiente. El dato debe ser de tipo subrango, y los nombres deben estar guardados
    en un array de strings.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.4.1.2:</b> Usando subrangos, crea un programa que pida una hora (de 0 a 24),
    unos minutos (de 0 a 60) y unos segundos (de 0 a 60) y calcule cuántos
    segundos han pasado desde la medianoche.</i></blockquote>        


<h3>4.4.2. Datos enumerados</h3> 
 
<p>Podemos crear nuestros propios tipos de <b>datos enumerados</b>, detallando 
todos los valores que puede tomar una variable, así:
</p>

<p><pre><code class='language-pascal'>
var dia: (Lunes, Martes, Miercoles, Jueves, Viernes,
  Sabado, Domingo);
</code></pre></p>
<p>Podemos asignar uno de esos valores a la variable (sin comillas, porque no son
cadenas de texto), comprobar un valor, o incluso avanzar de un valor al 
siguiente con "succ" (sucesor) y retroceder al que le precede con "prec" (precedente):</p>

<p><pre><code class='language-pascal'>(* ENUMERADO1.PAS, Variables enumeradas  *)
(* Parte de CUPAS5, por Nacho Cabanes    *)

program Enumerado1;

var
  dia: (Lunes, Martes, Miercoles, Jueves, Viernes,
  Sabado, Domingo);

begin
    dia := Lunes;
    
    if (dia = Martes) then
        writeLn('El dia es Martes')
    else
        writeLn('No es Martes');
        
    dia := succ( dia );
    
    if (dia = Martes) then
        writeLn('Ahora el dia es Martes')
    else
        writeLn('Aun no es Martes')
end. 

(* Resultado:
No es Martes
Ahora el dia es Martes
*)
</code></pre></p>
<p>También se puede saber el "número de orden", con la función "ord". Por
ejemplo, "ord(Lunes)" valdría 1, porque es el primer dato de la lista.
De igual modo, podríamos recorrer todos los valores posibles usando "for":
"for dia := Lunes to Viernes do ..."</p>

<p>En algunos compiladores, como Free Pascal (pero no Turbo Pascal,
ni siquiera en su versión 7), se nos permite mostrar en pantalla el
valor de un dato enumerado, y habitualmente lo que ocurrirá es que
se mostrará la cadena de texto equivalente, como en este ejemplo:</p>

<p><pre><code class='language-pascal'>(* ENUMERADO2.PAS, Variables enumeradas  *)
(* Visualizacion (solo Free Pascal)      *)
(* Parte de CUPAS5, por Nacho Cabanes    *)

program Enumerado2;

var
  dia: (Lunes, Martes, Miercoles, Jueves, Viernes,
  Sabado, Domingo);

begin
    dia := Lunes;
    
    if (dia = Lunes) then
        writeLn('El dia es ', dia);
        
    dia := succ( dia ); { Avanzamos un dia }
    writeLn('Ahora el dia es ', dia);
end. 

(* Resultado:
El dia es Lunes
Ahora el dia es Martes
*)
</code></pre></p>
<p>Pero Free Pascal llega más allá, nos permite incluso introducir 
valores mediante teclado para una variable enumerada (nuevamente, esta
posibilidad no existe en Turbo Pascal):</p>

<p><pre><code class='language-pascal'>(* ENUMERADO3.PAS, Variables enumeradas  *)
(* Lectura desde teclado (Free Pascal)   *)
(* Parte de CUPAS5, por Nacho Cabanes    *)

program Enumerado3;

var
  dia1, dia2: (Lunes, Martes, Miercoles, Jueves, Viernes,
  Sabado, Domingo);

begin
    dia1 := Lunes;
    writeLn('Introduce un dia: ');
    readLn(dia2);
    
    if (dia1 = dia2) then
        writeLn('El dia es ', dia1)
    else
    begin
        writeLn('Mi dia es ', dia1);
        writeLn('Y el tuyo es ', dia2);
    end;
end. 

(* 
Ejemplo de ejecucion 1:
Introduce un dia: 
lunes
El dia es Lunes

Ejemplo de ejecucion 2:
Introduce un dia: 
martes
Mi dia es Lunes
Y el tuyo es Martes
*)
</code></pre></p>
<p>En compiladores más antiguos, deberemos usar otros tipos de datos 
(números, caracteres o cadenas de texto) para interactuar con el usuario,
y convertirlos posteriormente al tipo enumerado dentro de nuestro programa,
empleando "if" o "case".</p>



<blockquote><i><b>Ejercicio propuesto 4.4.2.1:</b> Crea un programa que permita al usuario sumar, restar,
    multiplicar o dividir dos números. Debe introducir un primer número, luego
    el segundo número y finalmente escoger la operación. Las posibles operaciones
    deben estar enumeradas. Debe funcionar en cualquier versión de Pascal, no
    sólo en Free Pascal.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.4.2.2:</b> Si usas Free Pascal, crea un tipo enumerado que contenga los nombres
    de los meses, y muestra sus valores usando "for".</i></blockquote>

<h3>4.4.3. Conjuntos</h3>

<p><a name="conjuntos"></a>También podemos crear y manipular <b>conjuntos</b> (sets). 
Un conjunto está formado por una serie de elementos de un tipo base,
que debe ser un ordinal de no más de 256 valores posibles, como
un "char", un "byte" o un enumerado.</p>


<p>Para construir un "<b>set</b>" utilizaremos los corchetes ( [ ] ), y dentro
de ellos enumeramos los valores posibles, uno a uno, o bien como rangos de valores
separados por ".." :
</p>

<p><pre><code class='language-pascal'>
var 
    letras: set of char; 
 
begin 
    letras := ['a', 'b', 'c', 'd']; 
    (* ... *)
end.
</code></pre></p>

<p>Las <b>operaciones</b> que podemos realizar con conjuntos son:</p>

<table border>
<tr><td> Operac  </td><td>  Nombre</td></tr>
<tr><td>   +     </td><td>  Unión</td></tr>
<tr><td>   -     </td><td>  Diferencia</td></tr>
<tr><td>   *     </td><td>  Intersección</td></tr>
<tr><td>   in    </td><td>  Pertenencia</td></tr>
</table>

<p>Así, un ejemplo que cree un conjunto a partir de dos subconjuntos y
que compruebe si un cierto dato pertenece o no al conjunto, podría quedar así:</p>

<p><pre><code class='language-pascal'>(* SET01.PAS, Ejemplo de conjuntos (Sets) *)
(* Parte de CUPAS5, por Nacho Cabanes     *)

program Set01; 

var 
    minusculasValidas, 
        mayusculasValidas, 
        letrasValidas: set of char; 
    letra: char; 

begin 
    minusculasValidas := ['a', 'b', 'c', 'd']; 
    mayusculasValidas := ['F', 'H', 'K', 'M']; 
    letrasValidas := minusculasValidas
        + mayusculasValidas; 
        
    repeat 
        writeLn( 'Introduce una letra...' ); 
        readLn( letra ); 
        if not (letra in letrasValidas) then 
            writeLn('No aceptada!'); 
    until letra in letrasValidas; 
end.

(* Ejemplo de ejecucion:
Introduce una letra...
e
No aceptada!
Introduce una letra...
t
No aceptada!
Introduce una letra...
n
No aceptada!
Introduce una letra...
m
No aceptada!
Introduce una letra...
M
*)
</code></pre></p>

<blockquote><i><b>Ejercicio propuesto 4.4.3.1:</b> Crea un programa que pida al usuario que pulse "s" o "n"
    y no le deje seguir hasta que escoja una de esas dos opciones. Usa
    un conjunto para los datos aceptables y el operador "in" para ver si lo
    que ha tecleado el usuario es uno de esos datos aceptables.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.4.3.2:</b> Crea un programa que muestre un menú y permita al usuario introducir letras
    en un conjunto (usando la operación "unión"), eliminarlas (usando la
    "diferencia") o ver si una cierta letra aparece en en el conjunto (con "in").</i></blockquote>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   7525 visitas desde el 31-03-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas04c.php">Anterior</a></li>
                    <li><a href="cupas05.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        