<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 6 - Procedimientos y funciones (5)</title>

    
    <meta name="description" content="6 - Procedimientos y funciones (5) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="recursividad,recursion" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 6 - Procedimientos y funciones (5)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas06d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas06f.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2><a name="recurs"></a>6.5. Recursividad</h2>

<p>La idea en sí es muy sencilla: un procedimiento o función
es recursivo si se llama a sí mismo. </p>

<p>¿Qué utilidad puede tener eso? Habrá muchos problemas que son más 
fáciles de resolver si se descomponen en pasos cada vez más sencillos. 
Y existen otros problemas en los que querremos probar todas las posibles
soluciones, para escoger la óptima, y en ciertos casos, 
la recursividad será casi el único modo de conseguirlo.</p>

<p>Vamos a empezar por ver un ejemplo clásico de función recursiva: el factorial de un número.</p>

<p>Partimos de la definición matemática del factorial de un número entero n:</p>

<p><pre><code class='language-txt'>n! = n * (n-1) * (n-2) * ... * 3 * 2 * 1</code></pre></p>
<p>Es decir, el factorial es el resultado de multiplicar ese número por el siguiente número más pequeño (n-1), luego
por el siguiente (n-2) y así sucesivamente hasta llegar a 1.</p>

<p>Por otra parte, el factorial del siguiente número más pequeño a éste, (n-1), se puede escribir como</p>

<p><pre><code class='language-txt'>(n-1)! = (n-1) * (n-2) *  (n-3) * ... * 3 * 2 * 1</code></pre></p>
<p>Se parecen mucho, de modo que podemos escribir el factorial de un número "n" en función del factorial
del siguiente número, "n-1":</p>

<p><pre><code class='language-txt'>n! = n * (n-1)!</code></pre></p>
<p>Esa es la definición recursiva del factorial: Vamos "delegando" para que el problema lo resuelva el siguiente número,
y este a su vez se lo pasa al siguiente, y este al otro, y así
sucesivamente hasta llegar a algún caso que sea muy fácil.</p> 

<p>Vamos a ver cómo se imitaría esa lógica mediante un programa: </p>

<p><pre><code class='language-pascal'>(* FACT.PAS, Factorial, ejemplo de recursividad *)
(* Parte de CUPAS5, por Nacho Cabanes           *)

program PruebaDeFactorial;

var numero: integer;

function factorial( num : integer) : integer;
begin
    if num = 1 then
        factorial := 1    (* Aseguramos que tenga salida (caso base) *)
    else
        factorial := num * factorial( num-1 );       (* Caso general *)
end;

begin
    writeLn( 'Introduce un numero entero (no muy grande)  ;-)' );
    readLn(numero);
    writeLn( 'Su factorial es ', factorial(numero) );
end. 
</code></pre></p> 

<p>Esto es lo que hay que tener presente de este programa:</p>

<ul>
    
    <li> Por una parte, hay que asegurarse de encontrar un caso
    "trivial", en el que la solución sea evidente. En este ejemplo,
    se trata del factorial del 1, cuyo valor es 1 (por convenio,
    se suele considerar que el factorial de 0 también es 1, pero
    no es un detalle que nos deba preocupar ahora). El resto de
    valores deberán acercarse a ese valor, para reducir un problema
    complejo a uno cada vez más simple.</li>
    
    <li> Por otra parte, hay que buscar una forma de "reducir el problema":
    el "caso general" debe indicar cómo se pasa de la solución para "n" a la
    solución para un caso más simple, que típicamente será "n-1". Si no
    nos vamos acercando al "caso base", nuestra función podría "quedarse
    colgada", y no salir nunca, o acabar "saturando la memoria" del ordenador,
    provocando un fallo conocido como "desbordamiento de pila".</li>

    <li> En el caso concreto del factorial, no deberíamos poner números demasiado <b>grandes</b>.  Los 
    enteros en Pascal estándar van desde -32768 hasta 32767, luego si el resultado es mayor 
    que este número, tendremos un desbordamiento y el resultado será erróneo. 
    El factorial de 8 es cerca de 40.000, 
    luego sólo podremos usar números del 1 al 7. Si empleamos enteros largos,
    ganaremos un poco de margen de maniobra, pero aun así enseguida desbordaremos su valor.</li>

</ul> 


<p>La recursividad suele ser "difícil de ver" en un principio. Una herramienta 
que puede ayudar es pensar cómo sería la "<b>traza del programa</b>", que es la
secuencia de órdenes que se van a ejecutar y los valores que van a tener las variables
a medida que el programa avanza. Vamos a ver cómo sería la traza del programa anterior si
es usuario introduce el valor 4:
</p>

<p><pre><code class='language-txt'>Primera llamada: factorial( 4 )
num = 1  ? No => devolver 4 * factorial( 3 )
    Segunda llamada: factorial( 3 )
    num = 1  ? No => devolver 3 * factorial( 2 )
        Tercera llamada: factorial( 3 )
        num = 1  ? No => devolver 2 * factorial( 1 )
            Cuarta llamada: factorial( 1 )
            num = 1  ? Si => devolver 1
        Comienza la "sustitucion regresiva", rellenando los datos
        que antes no se conocian y que han quedado pendientes:
        Resolucion de factorial( 2 ): 2 * factorial(1) = 2 * 1 = 2
    Resolucion de factorial( 3 ): 3 * factorial(2) = 3 * 2 = 6
Resolucion de factorial( 4 ): 4 * factorial(3) = 4 * 6 = 24</code></pre></p>
<p>Como se puede observar, muchos datos intermedios no tienen valor 
inicialmente  y quedan pendientes de ser "rellenados" cuando ya se ha llegado 
al caso base y se "regresa" desde él. Eso hace que las funciones recursivas 
sean "costosas" en uso de memoria, pero en ocasiones hacen que la solución del 
problema sea más sencilla y legible, y en ciertos casos puntuales una función 
recursiva será la única solución.</p>

<blockquote><i><b>Ejercicio propuesto 6.5.1:</b> Crear otra función que halle la potencia (a elevado a b) de dos números enteros positivos, de forma recursiva, usando varias multiplicaciones. Pista: el caso base, la potencia más sencilla, será si elevas un número a 1, caso en el que obtienes el mismo número. Para el caso general, tendrás que pensar cómo pasar de la potencia "n" a la "n-1", por ejemplo de 3<sup>6</sup> a 3<sup>5</sup>.</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.5.2:</b> Crea una función recursiva que halle el producto de dos números enteros positivos, usando sumas.</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.5.3:</b> Crea un programa que emplee recursividad para calcular un número de la serie Fibonacci (en la que los dos primeros elementos valen 1, y para los restantes, cada elemento es la suma de los dos anteriores).</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.5.4:</b> Crea una función recursiva que devuelva invertida la cadena de texto que se pase como parámetros (piensa cuántos elementos deberá tener la cadena más sencilla y de invertir, y cómo invertir una cadena de longitud "n" si ya sabes cómo quedan invertidas sus "n-1" primeras (o últimas) letras.</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.5.5:</b> Crea un programa que emplee recursividad para calcular la suma de los elementos de un vector (piensa cuántos elementos deberá tener el caso base, el más sencillo, y como pasar de los "n" primeros elementos a los "n+1" primeros (o últimos).</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.5.6:</b> Crear un programa que encuentre el máximo común divisor de dos números usando el algoritmo de Euclides: Dados dos números enteros positivos m y n, tal que m > n, para encontrar su máximo común divisor, es decir, el mayor entero positivo que divide a ambos: - Dividir m por n para obtener el resto r (0 ? r < n) ; - Si r = 0, el MCD es n.; - Si no, el máximo común divisor es MCD(n,r).</i></blockquote>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   6488 visitas desde el 16-03-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas06d.php">Anterior</a></li>
                    <li><a href="cupas06f.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        