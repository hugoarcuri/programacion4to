<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>9.7. Arrays dinámicos</title>

    
    <meta name="description" content="9.7. Arrays dinámicos - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="array,length,setlength" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            9.7. Arrays dinámicos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas09f.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas09h.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2>9.7. Arrays dinámicos</h2>

<p>¿Y no sería maravilloso poder usar un simple array, más sencillo que las 
listas que hemos visto, pero no estar forzados a conocer su tamaño en tiempo de 
compilación, y poderlo indicar más adelante, cuando ya sepamos cuántos datos 
realmente deberá almacenar? ¿Y no sería fantástico poder incluso cambiar su 
tamaño más adelante?</p>

<p>Esta <b>no es una posibilidad estándar</b> del lenguaje Pascal, pero sí una 
ampliación que incluyen Free Pascal y Delphi (no Turbo Pascal). En estos 
compiladores, podemos declarar un array sin indicar su tamaño, así:</p>

<p><pre><code class='language-pascal'>var datos : array of byte;</code></pre></p>


<p>Y en cualquier momento posterior podemos indicar el tamaño que queremos que tenga :</p>

<p><pre><code class='language-pascal'>SetLength(datos, 20);</code></pre></p>

<p>Incluso podríamos volverlo a hacer una segunda vez, con un tamaño distinto, 
y entonces el array se acortaría o se haría más grande, según corresponda:</p>


<p><pre><code class='language-pascal'>SetLength(datos, 30);</code></pre></p>
<p>El array se empieza a numerar desde 0, y en cualquier momento podríamos saber
la cantidad de datos que contiene con "Length". Así, un ejemplo completo sería:</p>

<p><pre><code class='language-pascal'>(* DINARRAY.PAS, Ejemplo de arrays dinámico en Pascal *)
(* Parte de CUPAS5, por Nacho Cabanes                 *)

program DinArray;

uses classes;

var
    lista: TStringList;
    dato: string;
    i: integer;

begin
    lista := TStringList.Create;
    repeat
        write('Introduce un dato (Intro para acabar): ');
        readLn(dato);
        if dato <> '' then
            lista.Add(dato);
    until dato = '';

    for i:= lista.Count-1 downto 0 do
        writeLn(lista[i]);

    writeLn('Ordenando alfabéticamente...');
    lista.Sort;

    writeLn('Y guardando en "lista.txt"...');
    lista.SaveToFile('lista.txt');
end.
</code></pre></p>
<p>Esto, que puede parecer muy útil, tiene una limitación: cada vez que hacemos 
SetLength, se crea una nueva copia del array y se vuelven a ella todos los 
elementos que se deben conservar, de modo que es una operación relativamente 
lenta, especialmente si se trata de un array grande y vamos a añadir datos de 
uno en uno, redimensionando cada vez.</p>

<blockquote><i><b>Ejercicio propuesto 9.7.1:</b> Crea un programa que permita al usuario guardar una lista de
    números reales. El usuario introducirá tantos datos como desee (usando
    99999 para terminar), y en ese momento se le mostrará la media de los
    valores, después todos los que están por encima de esa media (en una misma
    línea, separados por espacios en blanco) y finalmente todos los que están
    por debajo de esa media (en una nueva línea, también separados por espacios
    en blanco). Debes usar un array dinámico, que comenzará con tamaño 1 y
    aumentará en una nueva unidad cada vez que se introduzca un dato.</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.7.2:</b> Crea una nueva versión del programa 9.7.1, en la que el tamaño
    inicial del array sea 20, y aumente de 10 en 10 cada vez que sea necesario</i></blockquote>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   6337 visitas desde el 23-08-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas09f.php">Anterior</a></li>
                    <li><a href="cupas09h.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        