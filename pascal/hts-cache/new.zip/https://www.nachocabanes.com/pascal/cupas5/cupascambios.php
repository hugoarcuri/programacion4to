<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - Cambios</title>

    
    <meta name="description" content="Curso de Pascal - Cambios - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="cambios" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - Cambios          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="index.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="index.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>Curso de Pascal - Cambios</h1>


<div align="center">
<p style="margin-right:20%; margin-left:20%;";>Si el curso te 
está resultando útil, una pequeña donación ayudará al mantenimiento de
este sitio web y a que siga mejorando estos cursos y creando otros nuevos.<br />
Desde <a href="http://www.nachocabanes.com/cursos/donaciones.php">aquí puedes ver las (pocas) donaciones
anteriores y aportar la tuya</a>.</p>
</div>
    

<div class="row">    
<div class="large-6 columns">
    
<p>Las <b>pr&oacute;ximas mejoras</b> previstas son:</p>

<ul>    
  <li> Apartado 12a (contacto con modo gráfico). Previsto para octubre 2014 (si alguien muestra interés).</li>
  <li> Apartado 9.6 (árboles binarios): Previsto para octubre 2014 (ídem).</li>
  
  <li> Apartado 10a (programación orientada a objetos 1).</li>
  <li> Apartado 10b (programación orientada a objetos 2).</li>
  
  
  <li> (El avance real de estas mejoras depende de si recibo en los foros muestras
    de que hay gente interesada en seguir el curso y del tiempo libre que le
    pueda conseguir dedicar)</li>
</ul>
</div>

<div class="large-6 columns">
<p>Los <b>cambios</b> en la versi&oacute;n 5 del 
curso han sido (hasta ahora) estos, de más reciente a más antiguo: </p>


<ul>
    <li>06-10-2014: Apartado 6.6 (forward), 6.7 (funciones incorporadas). 136 fuentes de ejemplo y 245 ejercicios propuestos.</li>
    <li>12-09-2014: Apartado 9.5 (listas enlazadas ordenadas). 133 fuentes de ejemplo y 245 ejercicios propuestos.</li>
    <li>27-08-2014: Apartado 9.8 (listas de strings). Añadida una imagen al apartado 11. 131 fuentes de ejemplo y 242 ejercicios propuestos.</li>
    <li>23-08-2014: Apartado 9.7 (arrays dinámicos). Añadida una imagen al apartado 11. 130 fuentes de ejemplo y 238 ejercicios propuestos.</li>
    <li>14-08-2014: Apartado 11 (pantalla en modo texto). 129 fuentes de ejemplo y 236 ejercicios propuestos.</li>
    <li>07-08-2014: Apartado 13 (servicios del sistema). 128 fuentes de ejemplo y 228 ejercicios propuestos.</li>
    <li>14-07-2014: Apartado 9.4 (listas enlazadas no ordenadas). 120 fuentes de ejemplo y 220 ejercicios propuestos.</li>
    <li>06-07-2014: Apartado 9.3 (colas). Corregidas algunas erratas de poca importancia. ("varible", "definienndo", "procedimento", etc). 118 fuentes de ejemplo y 217 ejercicios propuestos.</li>
    <li>22-06-2014: Apartado 9.1 (contacto con estructuras dinámicas) y 9.2 (pilas). 116 fuentes de ejemplo y 215 ejercicios propuestos.</li>
    <li>13-06-2014: Apartado 8 (unidades). 114 fuentes de ejemplo y 210 ejercicios propuestos.</li>
    <li>05-06-2014: Apartado 7.3 (ficheros binarios). 107 fuentes de ejemplo y 205 ejercicios propuestos.</li>
    <li>25-05-2014: Apartado 7.2 (ficheros con tipo). 105 fuentes de ejemplo y 199 ejercicios propuestos.</li>
    <li>20-04-2014: Apartado 7.1 (ficheros de texto). 102 fuentes de ejemplo y 193 ejercicios propuestos.</li>
    <li>16-04-2014: Apartado 6.5 (recursividad). 96 fuentes de ejemplo y 175 ejercicios propuestos.</li>
    <li>13-04-2014: Apartado 6.3 (funciones) y 6.4 (modificación de parámetros). 85 fuentes de ejemplo y 169 ejercicios propuestos.</li>
    <li>09-04-2014: Apartado 6.1 (procedimientos) y 6.2 (parámetros). Ampliado el apartado 3.2.3 con un ejemplo y 4 ejercicios. 78 fuentes de ejemplo y 161 ejercicios propuestos.</li>
    <li>04-04-2014: Apartado 5b (tipos definidos por el usuario). 74 fuentes de ejemplo y 150 ejercicios propuestos.</li>
    <li>31-03-2014: Apartado 4d (subrangos, enumerados, conjuntos). Ampliado el apartado 4c (registros) con dos ejemplos básicos de agenda. 71 fuentes de ejemplo y 146 ejercicios propuestos.</li>
    <li>27-03-2014: Apartado 5a (constantes). 63 fuentes de ejemplo y 137 ejercicios propuestos.</li>
    <li>23-03-2014: Apartado 4c (registros). 59 fuentes de ejemplo y 128 ejercicios propuestos.</li>
    <li>19-03-2014: Apartado 4b (cadenas de texto). 54 fuentes de ejemplo y 117 ejercicios propuestos.</li>
    <li>15-03-2014: Apartado 4a (arrays). 45 fuentes de ejemplo y 101 ejercicios propuestos.</li>
    <li>12-03-2014: Completado el apartado 3 (estructuras repetivas), tratando "while" y "repeat". 37 fuentes de ejemplo y 75 ejercicios propuestos.</li>
    <li>08-03-2014: Completado el apartado 2 (condiciones), para hablar de booleanos (2.2) y de la orden "case" (2.3). Incluido el principio del apartado 3 (estructuras repetivas), para hablar de "for". 32 fuentes de ejemplo y 60 ejercicios propuestos.</li>
    <li>04-03-2014: Apartado 2a (2.1.1 a 2.1.5), y apartado 0.5 (Free Pascal y Geany en Linux). 27 fuentes de ejemplo y 47 ejercicios propuestos.</li>
    <li>28-02-2014: Apartado 1b (1.6.1 a 1.6.5), y apartado 0.4 (Lazarus en Windows) con 21 fuentes de ejemplo y 34 ejercicios propuestos.</li>
    <li>25-02-2014: Apartado 1a (1.1 a 1.5), con 11 fuentes de ejemplo y 20 ejercicios propuestos.</li>
    <li>23-02-2014: Apartado 0 (0.1 a 0.3) y estructura básica.</li>
</ul>
</div>

</div>
 

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   2142 visitas desde el 25-02-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="index.php">Anterior</a></li>
                    <li><a href="index.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        