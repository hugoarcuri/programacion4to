<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>5 - Constantes y tipos</title>

    
    <meta name="description" content="5 - Constantes y tipos - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="generalidades,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            5 - Constantes y tipos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas05.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas06.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2><a name="type"></a>5.2. Definición de tipos.</h2> 

<p>El "tipo" de una variable es lo que determina qué
clase de valores podremos guardar en ella. En los programas que hemos creado hasta
ahora, el "tipo" es lo que indicamos
junto al nombre de una variable cuando la declaramos. Por ejemplo, </p>

<p><pre><code class='language-pascal'>var PrimerNumero: real;</code></pre></p>
<p>indica que vamos a usar una variable que se va
a llamar PrimerNumero y que almacenará números reales (con decimales), mientras que </p>

<p><pre><code class='language-pascal'>const intentos: integer = 3;</code></pre></p>
<p>indica que vamos a usar una variable llamada intentos, que guardará números enteros y que tendrá como valor inicial 3. </p>

<p>También podemos <b>crear</b> nuestros tipos de datos, a partir de los tipos básicos que permite el lenguaje, usando la palabra "type". Así, por ejemplo, podemos crear una nueva versión del ejemplo de "array de records" del apartado 4.3.3, definiendo

<p><pre><code class='language-pascal'>(* ARR_REC2.PAS, "array" de varios "record" *)
(* Segunda version, con "const" y "type"    *)
(* Parte de CUPAS5, por Nacho Cabanes       *)
 
program RecordArray2;

const
    maxDatos = 10;

type
    ficha = record
        nombre: string[30];
        edad: byte;
    end;

var
    datos: array [1..maxDatos] of ficha;

begin
    datos[1].nombre := 'Ignacio';
    datos[1].edad := 23;
    write('El primer nombre es ', datos[1].nombre );
    write(' y la primera edad ', datos[1].edad);
end.

 
(* Resultado:
El primer nombre es Ignacio y la primera edad 23
*)
</code></pre></p>

<p>Esto añade legibilidad, pero no es imprescindible. Entonces... ¿no será necesario definir tipos? Sí, en algunas circunstancias concretas sí será necesario. Un primer ejemplo en cuando tenemos dos variables declaradas de igual forma en distintas partes del programa, como en este ejemplo:</p>

<p><pre><code class='language-pascal'>(* TIPOS1.PAS, asignacion INCORRECTA de tipos *)
(*            No compila !!!                  *)
(* Parte de CUPAS5, por Nacho Cabanes         *)

program Tipos1;

var
    ficha1: record
        nombre: string;
        email: string;
        anyoNacimiento: integer;
    end;
    
    ficha2: record
        nombre: string;
        email: string;
        anyoNacimiento: integer;
    end;

begin
    ficha1.nombre := 'Pepe';
    ficha1.email := 'p@p.com';
    ficha1.anyoNacimiento := 1990;
    
    ficha2 := ficha1;
    writeLn( ficha2.nombre );
end.  
</code></pre></p>
<p>Aunque a nuestros ojos parezca que ambas variables son del mismo tipo, para el compilador no es así, de modo que el programa anterior no compilará correctamente.</p>

<p>Podríamos declarar ambas a la vez, de la siguiente forma:</p>

<p><pre><code class='language-pascal'>var
    ficha1, ficha2: record
        nombre: string;
        email: string;
        anyoNacimiento: integer;
    end;</code></pre></p>
<p>pero eso no servirá si las variables están en zonas separadas del programa (algo que nos empezará a ocurrir pronto). En ese caso, no habrá más remedio que crear un nuevo tipo de datos, y declarar ambas variables como pertenecientes a dicho tipo:</p>

<p><pre><code class='language-pascal'>(* TIPOS2.PAS, asignacion correcta de tipos *)
(* Parte de CUPAS5, por Nacho Cabanes       *)

program Tipos2;

type TipoFicha = record 
        nombre: string;
        email: string;
        anyoNacimiento: integer;
    end;

var
    ficha1: TipoFicha;
    ficha2: TipoFicha;

begin
    ficha1.nombre := 'Pepe';
    ficha1.email := 'p@p.com';
    ficha1.anyoNacimiento := 1990;
    
    ficha2 := ficha1;
    writeLn( ficha2.nombre );
end.  
</code></pre></p>
<p>Y habrá más casos en los que sea imprescindible declarar tipos, como cuando vayamos a volcar nuestros "record" a fichero, pero eso lo veremos más adelante.</p>

<blockquote><i><b>Ejercicio propuesto 5.2.1:</b> Crea un tipo de datos "DiasSemana", con valores enumerados desde "lunes" hasta "domingo". Crea una variable de ese tipo y asígnale el valor "viernes".</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.2.2:</b> Crea un tipo de datos "DiasMes", que será un subrango del 1 al 31. Crea una variable de ese tipo, pide su valor al usuario y muestra el valor siguiente al introducido.</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.2.3:</b> Crea un tipo de datos "ConjuntoNumeros", que será un conjunto de datos tipo byte. Crea una variable de ese tipo, dándole un valor inicial vacío. Luego añade el número 35, el 43 y el 74.</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.2.4:</b> Crea una nueva versión de la "agenda0b" (apartado 4.3.3), llamada, "agenda1", que use una constante para la capacidad del array y que declare un tipo de datos "tipoPersona", que representará un "record" de nuestra agenda.</i></blockquote>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   3109 visitas desde el 23-02-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas05.php">Anterior</a></li>
                    <li><a href="cupas06.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        