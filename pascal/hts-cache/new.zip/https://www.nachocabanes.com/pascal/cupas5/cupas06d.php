<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 6 - Procedimientos y funciones (4)</title>

    
    <meta name="description" content="6 - Procedimientos y funciones (4) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="var,procedure" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 6 - Procedimientos y funciones (4)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas06c.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas06e.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2>6.4. Modificación de parámetros</h2>

<p>Ya habíamos visto qué son los <b>parámetros</b>: una serie
de datos extra, que indicábamos entre paréntesis en la cabecera
de un procedimiento o función.
</p>

<p>Es algo que estamos usando, casi sin darnos cuenta, desde
el primer apartado del curso, cuando empezamos a usar "WriteLn":</p>

<p><pre><code class='language-pascal'>writeLn( 'Hola' );</code></pre></p>
<p>Esta línea es una llamada al procedimiento "WriteLn", y como
parámetros le estamos indicando lo que queremos que escriba, en este
caso, el texto "Hola".

<p>Pero vamos a ver qué ocurre si modificamos un parámetro:
</p>

<p><pre><code class='language-pascal'>(* PROCMOD1.PAS, Procedimiento que modifica parametros *)
(* Primer intento: paso por valor                      *)
(* Parte de CUPAS5, por Nacho Cabanes                  *)
 
program ModificarParametros1;

var dato: integer;

procedure modifica( variable : integer);
begin
    variable := 3 ;
    writeLn( 'Dentro: ', variable );
end;

begin
    dato := 2;
    writeLn( 'Antes: ', dato );
    modifica( dato );
    writeLn( 'Después: ', dato );
end. 
</code></pre></p> 
<p>¿Qué podemos esperar que pase?  Vamos a ir siguiendo
cada instrucción:</p>

<ul>
    <li> Declaramos el nombre del programa</li>
    
    <li> Usaremos la variable "dato", de tipo entero.</li>

    <li> El procedimiento "modifica" toma una variable de tipo entero, le asigna
el valor 3 y la escribe.  Lógicamente, siempre escribirá
3.</li>

    <li> Empieza el cuerpo del programa: damos el valor 2 a "dato".</li>
    
    <li> Escribimos el valor de "dato".  Claramente,  será 2.</li>

    <li> Llamamos al procedimiento "modifica", que asigna el valor 3 a 
    "dato" y lo escribe.</li>

    <li> Finalmente volvemos a escribir el valor de "dato"...  ¿3?</li>
    
</ul> 

<p>Pues no es eso lo que ocurre: escribe <b>un 2</b>.  Las modificaciones
que hagamos a "dato" dentro del procedimiento "modifica" sólo son
válidas mientras estemos <b>dentro</b> de ese procedimiento 
(lo que realmente ocurre es que el procedimiento está recibiendo una copia de la variable, de modo que si hacemos algún
cambio, éstos no se cambios no afectan a la variable original, que existe fuera del procedimiento).</p>

<p>Eso es <b>pasar un parámetro</b> <b>por valor</b>: podemos leer su valor, pero no podemos alterarlo (los cambios se pierden 
al salir).</p>

<p>La alternativa es "<b>pasar parámetros por referencia</b>, añadiendo la palabra "var" delante de cada
parámetro que sea modificable dentro del procedimiento (o función):</p>

<p><pre><code class='language-pascal'>(* PROCMOD2.PAS, Procedimiento que modifica parametros *)
(* Segundo intento: paso por referencia                *)
(* Parte de CUPAS5, por Nacho Cabanes                  *)
 
program ModificarParametros2;

var dato: integer;

procedure modifica( var variable : integer);
begin
    variable := 3 ;
    writeLn( 'Dentro: ', variable );
end;

begin
    dato := 2;
    writeLn( 'Antes: ', dato );
    modifica( dato );
    writeLn( 'Después: ', dato );
end.
</code></pre></p>
<p>Esta vez la última línea del programa sí que escribe
un 3 y no un 2, porque hemos permitido que los cambios hechos a la variable
salgan del procedimiento (para eso hemos añadido la palabra "var").
</p>

<p>El nombre "<b>referencia</b>" alude a que no se pasa realmente al procedimiento
o función el valor de la variable, sino la dirección de memoria
en la que se encuentra, algo que más adelante llamaremos un "puntero".
</p>

<p>Una de las aplicaciones más habituales de pasar parámetros
por referencia es cuando debemos devolver <b>más
de un valor</b>: habíamos visto que una función era muy parecida a 
un procedimiento, pero además devolvía un valor (pero <b>sólo
uno</b>); cuando necesitamos obtener más de un valor de salida, la
forma habitual de conseguirlo es pasándolos como parámetros por referencia, (precedidos
por la palabra "var"). Existe alguna otra alternativa menos elegante, como 
devolver un array, cosas que no tiene mucho sentido si no se trata de datos relacionados..</p>

<p>Otra aplicación puede ser optimizar (ligeramente) velocidad: si pasamos datos
de gran tamaño, será algo más lento pasarlos por valor (hay que duplicar toda
su estructura) que pasarlos por referencia (sólo se pasa su dirección), pero
este tipo de consideraciones hay que tenerlas más adelante, no en la primera
implementación del programa, porque tratar de optimizar velocidad antes de
tener la certeza de que todo funciona correctamente puede dar lugar a errores
difíciles de detectar.</p>


<p>¿Y si la variable <b>tiene el mismo nombre</b> en la función y en el cuerpo del programa?
¿Conseguiremos "engañar" al compilador y modificar su valor sin necesidad de usar "var"?</p>

<p><pre><code class='language-pascal'>(* PROCMOD3.PAS, Procedimiento que modifica parametros *)
(* Tercer intento: paso por valor de variables con el  *)
(*     el mismo nombre                                 *)
(* Parte de CUPAS5, por Nacho Cabanes                  *)
 
program ModificarParametros3;

var dato: integer;

procedure modifica( dato : integer);
begin
    dato := 3 ;
    writeLn( 'Dentro: ', dato );
end;

begin
    dato := 2;
    writeLn( 'Antes: ', dato );
    modifica( dato );
    writeLn( 'Después: ', dato );
end.

</code></pre></p>
<p>Como se ve en este ejemplo, da igual el nombre que tengan las variables.
El comportamiento será el mismo: ambas variables son distintas, aunque el 
nombre parezca indicar lo contrario.</p>

<blockquote><i><b>Ejercicio propuesto 6.4.1:</b> Crea un procedimiento "Intercambia", que intercambie el valor de los dos números enteros que se le indiquen como parámetro.</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.4.2:</b> Crea un procedimiento "ObtenerIniciales", que reciba una cadena como "Nacho Cabanes" y devuelva las letras N y C (primera letra, y letra situada tras el primer espacio), usando parámetros por referencia.</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.4.3:</b> Crea un procedimiento "ResolverEcuacionCuadratica", que resuelva una ecuación de segundo grado en la forma y=ax<sup>2</sup>+bx+c. Recibirá como parámetros por valor a, b, y c, y devolverá las dos soluciones x1 y x2 (suponiendo que tenga dos soluciones reales) como parámetros por referencia.</i></blockquote>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   3317 visitas desde el 13-04-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas06c.php">Anterior</a></li>
                    <li><a href="cupas06e.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        