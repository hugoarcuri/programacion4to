<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 2. Condiciones (2)</title>

    
    <meta name="description" content="2. Condiciones (2) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="if,case" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 2. Condiciones (2)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas02.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas03.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h2>2.2. Variables booleanas</h2> 

<p> Una variable "<b>Boolean</b>" (llamadas así en honor al matemático George Boole) es una variable lógica,
que puede valer <b>TRUE</b> (verdadero) o <b>FALSE</b> (falso), y se pueden usar para hacer que las condiciones resulten más legibles:</li></ul>

<p><pre><code class='language-pascal'>(* IF5.PAS, "if" y booleanos             *)
(* Parte de CUPAS5, por Nacho Cabanes    *)

program if5;

var
    numero: integer;
    esPositivo: boolean;

begin
    writeLn('Escriba un numero');
    readLn(numero);
    esPositivo := numero>0;
    if esPositivo then writeLn('El numero es positivo');
end. 

(* Ejemplo de ejecucion:
Escriba un numero
2
El numero es positivo
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 2.2.1:</b> Crea un programa que cree una variable de tipo boolean, le asigne el valor TRUE y luego muestre dicho valor en pantalla.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.2.2:</b> Crea un programa que pida al usuario un número real y diga si es cero o no, usando una variable boolean.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.2.3:</b> Crea un programa que pida al usuario un número entero y diga si es positivo, negativo o cero, usando dos variables boolean (esPositivo y esNegativo).</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.2.4:</b> Crea un programa que pida al usuario un número entero y diga si es positivo, negativo o cero, usando tres variables boolean (esPositivo, esNegativo y esCero).</i></blockquote>  
 
<p> &nbsp;</p> 



<h2>2.3. Muchos posibles valores (case)</h2> 

<p>Cuando queremos comprobar entre <b>varios posibles
valores</b>, podemos hacerlo con muchos "if"
seguidos, pero puede resultar pesado y hacer que el programa sea poco legible. Hay una alternativa
que resulta mucho más cómoda en esas ocasiones: la orden <b>case</b>. Su sintaxis
es</p>

<p><pre><code class='language-pascal'>case expresion of 
  caso1: sentencia1; 
  caso2: sentencia2; 
  ... 
  casoN: sentenciaN; 
end;</code></pre></p>
<p><a name="caseelse"></a>o bien, si queremos indicar también lo que se debe hacer
si no coincide con ninguno de los valores que hemos enumerado, añadimos la
cláusula opcional <b>else</b>:
</p>

<p><pre><code class='language-pascal'>case expresion of 
  caso1: sentencia1; 
  caso2: sentencia2; 
  ... 
  casoN: sentenciaN; 
  else
    otraSentencia; 
end;</code></pre></p>
<p>(Nota: Esta es la sintaxis empleada por Turbo Pascal y Free Pascal. En 
<b>Pascal estándar</b>, esta construcción se empleaba con <b>otherwise</b> 
en lugar de "else" para expresar "en caso contrario".</p>

<p>Veamos un ejemplo:</p> 

<p><pre><code class='language-pascal'>(* CASE1.PAS, Condiciones múltiples con "case" *)
(* Parte de CUPAS5, por Nacho Cabanes          *)

program case1;

var
    letra: char;

begin
    WriteLn('Escriba un simbolo');
    ReadLn(letra);
    case letra of
        ' ':                 WriteLn('Un espacio');
        'A'..'Z', 'a'..'z':  WriteLn('Una letra');
        '0'..'9':            WriteLn('Un digito');
        '+', '-', '*', '/':  WriteLn('Un operador');
    else  { otherwise en SURPAS y otros compiladores }
        WriteLn('No es espacio, ni letra, ni digito, ni operador');
    end;
end. 

(* Ejemplo de ejecucion:
Escriba un simbolo
a
Una letra
*)
</code></pre></p>
<p>Una precaución: la "expresión" debe pertenecer
a un tipo de datos con un <b>número finito </b>de elementos, como
"integer" o "char", pero no "real".
</p>

<p>Y como se ve en el ejemplo, los "<b>casos</b>" posibles pueden ser valores
únicos, varios valores separados por comas, o un rango de valores
separados por .. (como los puntos suspensivos, pero <b>sólo dos</b>).</p>

<blockquote><i><b>Ejercicio propuesto 2.3.1:</b> Crea un programa que pida al usuario un símbolo y diga si es una letra en mayúsculas, una letra en minúsculas o algún otro símbolo.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.3.2:</b> Crea un programa que pida al usuario una letra y diga si es una vocal o una consonante.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.3.3:</b> Crea un programa que pida al usuario un número entero del 1 al 3, y escriba en pantalla "Uno", "Dos", "Tres" o "Número incorrecto" según corresponda.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.3.4:</b> Crea un programa que pida al usuario un número, una operación (+, -, * o /) y otro número, y muestre el resultado de aplicar esa operación a esos dos números.</i></blockquote>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   5669 visitas desde el 08-03-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas02.php">Anterior</a></li>
                    <li><a href="cupas03.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        