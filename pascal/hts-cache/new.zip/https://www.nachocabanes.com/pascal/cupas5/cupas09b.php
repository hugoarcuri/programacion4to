<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 9.2. Pilas</title>

    
    <meta name="description" content="9.2. Pilas - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="generalidades,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 9.2. Pilas          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas09.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas09c.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h2>9.2. Una pila</h2> 

<p>Una de las estructuras dinámicas más sencillas, y, por tanto, más fáciles de entender y de programar, es lo que se conoce como "<b>una pila</b>". Podemos compararla con una pila de libros: si queremos añadir un nuevo libro, lo ponemos encima de los que ya existen; si queremos tomar libros, debemos empezar por la parte superior (así, para llegar al tercer libro deberíamos retirar antes los dos primeros).</p>

<p>En informática, una "pila" es una estructura de datos que se comporta de forma similar: contiene una colección de datos, y se puede añadir un nuevo elemento mediante la operación "Apilar" (y quedará en la "cima" de la pila), o retirar el elemento de la cima (y sólo ese) con la operación "Desapilar".</p>

<p>Como primera aproximación, vamos a crear una pila, que almacenará números enteros, y lo haremos usando memoria estática (un array), de modo que tendrá un tamaño limitado y que será fácil desbordar (y, en ese caso, nuestro programa fallará). Eso nos ayudará a ver las ideas básicas, para luego intentar aplicarlas a una estructura dinámica.</p>

<p><pre><code class='language-pascal'>(* PILA1.PAS, Ejemplo de pila estatica  *)
(* Parte de CUPAS5, por Nacho Cabanes   *) 

program pilaEstatica;

var
    datos: array[1..10] of integer;
    cima: integer;
    
procedure InicializarPila;
begin
    cima := 0;
end;

procedure Apilar(nuevoDato: integer);
begin
    cima := cima + 1;
    datos[cima] := nuevoDato;
end;    

function Desapilar: integer;
begin
    Desapilar := datos[cima];
    cima := cima - 1;
end; 

function CantidadDatos: integer;
begin
    CantidadDatos := cima;
end;

{ --- Programa de prueba --- }

var
    n: integer;

begin
    InicializarPila;
    WriteLn('Guardando 3 y 2...');
    Apilar(3);
    Apilar(2);
    WriteLn('Los datos eran:');
    WriteLn( Desapilar );
    WriteLn( Desapilar );
    
    WriteLn('Ahora introduce datos, 0 para terminar...');
    repeat
        Write('Dato? ');
        ReadLn( n );
        if n <> 0 then
            Apilar(n);
    until n = 0;
    
    WriteLn('Los datos eran:');
    while CantidadDatos > 0 do
        WriteLn( Desapilar );
end.
</code></pre></p>

<p>Debería resultar fácil de seguir. Pero no es eficiente: si intentamos guardar más de 10 datos, el programa fallará. Si "sobredimensionamos", reservando espacio para (por ejemplo) 1000 datos, estaremos desperdiciando memoria en la gran mayoría de las ocasiones.</p>

<p>Si queremos crear esta pila usando <b>memoria dinámica</b>, de modo que pueda crecer tanto como sea necesario, necesitaremos varias ideas nuevas y un par de órdenes nuevas.</p>

<ul>

    <li>Por una parte, deberemos pensar en una serie de "nodos". Cada "<b>nodo</b>" contendrá el dato que realmente queremos guardar, pero también tendrá un "enlace" que nos permita saber dónde buscar el siguiente nodo.</li>
    
    <li>Necesitaremos una orden que nos permita "reservar memoria" para un nuevo nodo cada vez que lo necesitemos. Será la orden "<b>new</b>".</li>
    
    <li>Necesitaremos otra orden que nos permita "liberar memoria", cada vez que queramos eliminar un nodo. Será la orden "<b>dispose</b>".</li>

</ul>

<p>Ese "enlace" entre nodos será lo que llamaremos un "puntero" o "apuntador" (en inglés, "pointer"), la dirección de memoria en la que se encuentra el siguiente dato. Así, la apariencia de un "nodo" será la siguiente:</p>

<p><pre><code class='language-pascal'>type
    nodo = record
        dato: integer;
        siguiente:  puntero
    end; </code></pre></p>
<p>Donde ese tipo de datos "puntero" sería un "puntero a nodo", es decir, una dirección de memoria en la que habrá otro nodo, algo que se escribe así:</p>

<p><pre><code class='language-pascal'>type
    puntero = ^ nodo;</code></pre></p>
<p>Ahora sólo falta tener en cuenta que cuando "apilemos" un dato, deberemos reservar memoria para él, con la orden "new", y cuando "desapilemos" deberemos liberar esa memoria, con la orden "dispose",
de forma que el programa completo podría ser así:</p>

<p><pre><code class='language-pascal'>(* PILA2.PAS, Ejemplo de pila dinamica *)
(* Parte de CUPAS5, por Nacho Cabanes  *) 

program pilaDinamica;

type
    puntero = ^ nodo;

    nodo = record
        dato: integer;
        siguiente:  puntero
    end; 

var
    cima: puntero;
    contadorDeDatos: integer;
    
procedure InicializarPila;
begin
    cima := nil;
    contadorDeDatos := 0;
end;

procedure Apilar(nuevoDato: integer);
var
    nuevoNodo: puntero;
begin
    { Reservamos espacio para un nuevo nodo }
    new(nuevoNodo);
    { Guardamos el dato en él }
    nuevoNodo^.dato := nuevoDato;
    { Lo ponemos "encima" de la cima actual }
    nuevoNodo^.siguiente := cima;
    { Y hacemos que éste sea la nueva cima }
    cima := nuevoNodo;
    { Y anotamos que tenemos un dato más }
    contadorDeDatos := contadorDeDatos + 1;
end;    

function Desapilar: integer;
var
    nuevaCima: puntero;
begin
    { Tomamos el dato de la cima }
    Desapilar := cima^.dato;
    { Anotamos el siguiente, que será la nueva cima }
    nuevaCima := cima^.siguiente;
    { Liberamos el espacio que ocupaba este nodo }
    dispose(cima);
    { Y finalmente "movemos" la cima a su nueva posición }
    cima := nuevaCima;
    { Y anotamos que tenemos un dato menos }
    contadorDeDatos := contadorDeDatos - 1;
end; 

function CantidadDatos: integer;
begin
    CantidadDatos := contadorDeDatos;
end;

{ --- Programa de prueba --- }

var
    n: integer;

begin
    InicializarPila;
    WriteLn('Guardando 3 y 2...');
    Apilar(3);
    Apilar(2);
    WriteLn('Los datos eran:');
    WriteLn( Desapilar );
    WriteLn( Desapilar );
    
    WriteLn('Ahora introduce datos, 0 para terminar...');
    repeat
        Write('Dato? ');
        ReadLn( n );
        if n <> 0 then
            Apilar(n);
    until n = 0;
    
    WriteLn('Los datos eran:');
    while CantidadDatos > 0 do
        WriteLn( Desapilar );
end.
</code></pre></p>
<p>El cuerpo del programa no ha cambiado, se sigue manejando exactamente igual. 
Pero esta vez podemos almacenar tantos datos como queramos, sin tener que 
preocuparnos del tamaño del array, porque se reserva espacio para cada nuevo
dato (con "new") cuando es necesario, y se libera espacio de cada dato
(con "dispose") cuando ya no hace falta.</p>


<blockquote><i><b>Ejercicio propuesto 9.2.1:</b> Crea un programa que permita guardar una pila de "puntos". Cada
    punto tendrá dos coordenadas, llamadas X e Y. Ambas serán números reales.
    El programa pedirá datos de puntos al usuario, tanto como éste desee.
    Terminará cuando tanto la X como la Y valgan -1000. En ese momento, se
    mostrarán las coordenadas X e Y de todos los puntos almacenados.</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.2.2:</b> Crea una "pila de cadenas de texto". Utilízala para mostrar el
    contenido de un fichero de texto al revés (de la última línea a la
    primera).</i></blockquote>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   7739 visitas desde el 22-06-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas09.php">Anterior</a></li>
                    <li><a href="cupas09c.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        