<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Instalación de Lazarus, para Windows</title>

    
    <meta name="description" content="Instalación de Lazarus, para Windows - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="lazarus" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Instalación de Lazarus, para Windows          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas00.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas00linuxGeany.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>
<h2>0.4. Instalación de Lazarus, para Windows</h2>
    
<p>Posiblemente la mejor opción para aprender Pascal actualmente sea usar <b>Free Pascal</b>. Se trata de un entorno de desarrollo en Pascal gratuito (realmente más que eso, "de código abierto"), disponible para muchos sistemas operativos distintos, y que sigue la sintaxis del que fue un estándar de hecho, Turbo Pascal.</p>

<p>Free Pascal incluye un editor "en modo texto", al estilo de Turbo Pascal 7 para MsDos. Pero resulta más amigable usar un entorno "basado en Ventanas", como <b>Lazarus</b>. Este entorno permite crear también programas "de ventanas", pero es algo que no haremos hasta que lleguemos al final del curso. Por ahora nuestros programas serán "<b>de consola</b>" (en modo texto), para que podamos centrarnos en cómo hacer que las cosas funcionen, antes que en "hacerlas bonitas".</p>


<p>Podemos descargar Lazarus desde su página oficial (<a href="http://lazarus.freepascal.org/">lazarus.freepascal.org</a>): </p>

<p align="center"><img src="img/lazarus-web-2014-02.png"></p>

<p>La instalación debería ser poco más que hacer doble clic en el fichero descargado, y a partir de ahí ir haciendo clic en los botones que muestren el texto "Siguiente", pero aun así, vamos a ver los pasos básicos...</p>

<p>En primer lugar se nos preguntará el idioma que queremos usar para la instalación (las siguientes capturas corresponden a Lazarus 0.9.28, pero es esperable que no haya grandes diferencias en la instalación de versiones posteriores):</p>

<p align="center"><img src="img/lazarus_0_9_28_2-01.png"></p>

    
<p>Y comenzará la instalación en sí:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-02.png"></p>
    
<p>Deberemos elegir una carpeta en la que instalar. Es recomendable que su nombre no contenga espacios:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-03.png"></p>
    
<p>Podemos afinar los detalles sobre qué instalar o no, así como si asociar el doble clic de ciertos ficheros con Lazarus. Como es habitual, en caso de duda puede ser recomendable dejar todo tal y como se nos propone..</p>

<p align="center"><img src="img/lazarus_0_9_28_2-04.png"></p>
    
<p>Se creará una carpeta en el menú Inicio:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-05.png"></p>
    
<p>Y podemos crear un acceso también en el escritorio:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-06.png"></p>
    
<p>Se nos mostrará un resumen para que confirmemos los cambios que vamos a hacer:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-07.png"></p>
    
<p>Y comenzará la copia de ficheros...</p>

<p align="center"><img src="img/lazarus_0_9_28_2-08.png"></p>
    
<p>Debería estar listo en un instante:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-09.png"></p>
    
<p>A partir de ese momento, podremos entrar a Lazarus desde el menú de Inicio. Cuando lo hagamos, deberemos crear un "nuevo proyecto" para nuestro programa:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-11.png"></p>
    
<p>Se nos propondrán varios tipos de proyectos:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-12.png"></p>
    
<p>Nuestro proyecto será una "aplicación de consola":</p>

<p align="center"><img src="img/lazarus_0_9_28_2-14.png"></p>
    
<p>Y aparecerá un esqueleto de programa:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-15.png"></p>
    
<p>Pero nuestros programas serán por ahora más sencillos que eso, así que borraremos todo eso y escribiremos el nuestro:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-16.png"></p>
    
<p>Guardaremos el proyecto (puede ser interesante crear una carpeta llamada Pascal para todos ellos)</p>

<p align="center"><img src="img/lazarus_0_9_28_2-18.png"></p>
    
<p>Y ya podemos ponerlo en marcha ("ejecutarlo"):</p>

<p align="center"><img src="img/lazarus_0_9_28_2-19.png"></p>
    
<p>Obtendríamos algo como esto:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-22.png"></p>
    
<p>Pero es habitual que la ventana se abra y se cierre tan rápido que <b>no tengamos tiempo de leer lo que ha aparecido</b> en pantalla. Una solución simple es añadir al final de nuestro programa una orden "ReadLn" (que veremos con detalles más adelante), para forzar a que se haga una pausa:</p>

<p align="center"><img src="img/lazarus_0_9_28_2-24.png"></p>
    


           </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   5431 visitas desde el 25-02-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas00.php">Anterior</a></li>
                    <li><a href="cupas00linuxGeany.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        