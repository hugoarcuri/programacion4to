<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 7c. Manejo de ficheros (3: ficheros binarios)</title>

    
    <meta name="description" content="7c. Manejo de ficheros (3: ficheros binarios) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="generalidades,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 7c. Manejo de ficheros (3: ficheros binarios)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas07b.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas08.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

    
<h2>7.3. Ficheros binarios.</h2>

<p> 
Hemos visto cómo acceder a los ficheros de texto y a los fichero
"con tipo".  Pero en la práctica nos encontramos con muchos
ficheros que no son de texto y que tampoco tienen un tipo de datos claramente
repetitivo.
</p>

<p>Muchos formatos estándar como PCX, DBF o GIF están formados
por una cabecera en la que se dan detalles sobre el formato de los datos,
y a continuación ya se detallan los datos en sí.
</p>

<p>Esto claramente no es un fichero de texto, y tampoco se parece mucho
a lo que habíamos llamado ficheros con tipo.  Podríamos emplear
un fichero "de tipo byte", pero esto resulta muy lento a la hora de leer
ficheros de gran tamaño.
</p>

<p>Pero hay un alternativa: declarar un <b>fichero sin tipo</b> (o "fichero 
binario"), en el que nosotros mismos decidimos qué tipo de datos queremos 
leer en cada momento, a partir de lo que conozcamos sobre cómo se creó el fichero.</p>

<p><a name="blockread"></a>Ahora leeremos <b>bloques</b> de bytes, y los
almacenaremos en un "<b>buffer</b>" (memoria intermedia).  Para ello
tenemos la orden "<b>BlockRead</b>", cuyo formato es:
</p>

<p><pre><code class='language-pascal'>procedure BlockRead(var F: Fichero; var Buffer; Cuantos: Word
      [; var Resultado: Word]);</code></pre></p><p>donde</p>

<ul>
    
    <li>"F" es un fichero sin tipo (declarado como "var fichero: file" ).</li>

    <li>"Buffer" es la variable en la que queremos guardar los datos 
    leídos.</li>
    
    <li>"Cuantos" es el número de datos que queremos leer.</li>
    
    <li>"Resultado" (opcional) almacena un número que indica si ha habido
    algún error.</li>

</ul> 
 
<p>Existe <b>otra diferencia</b> con los ficheros que hemos visto hasta 
ahora, y es que cuando abrimos un fichero sin tipo con "reset", debemos 
indicar el tamaño de cada dato (normalmente diremos que 1, y así podemos 
leer variables más o menos grandes indicándolo con el dato "cuantos" que 
aparece en BlockRead). </p>

<p>Así, abriríamos el fichero con</p>

<p><pre><code class='language-pascal'>reset( fichero, 1 );</code></pre></p>
<p>En el caso de Turbo Pascal para MsDos, existe una limitación en cuanto a 
tamaño de los datos: los <b>bloques</b> que leemos con "BlockRead" deben 
tener un tamaño menor de 64K (el resultado de multiplicar "cuantos"por el 
tamaño de cada dato). </p>

<p>El significado de "Resultado" es el siguiente: nos indica cuantos datos 
ha leído realmente.  De este modo, si vemos que le hemos dicho que leyera 30 
fichas y sólo ha leído 15, podremos deducir que hemos llegado al final del 
fichero.  Si no usamos "resultado" y tratamos de leer las 30 fichas, el 
programa se interrumpirá, dando un error. </p>

<p>Para <b>escribir</b> bloques de datos, utilizaremos "<b>BlockWrite</b>", 
que tiene el mismo formato que BlockRead, pero esta vez si "resultado" es 
menor de lo esperado indicará que el disco está lleno. </p>

<p>Esta vez, es en "<b>rewrite</b>" (cuando abrimos el fichero para 
escritura) donde deberemos indicar el tamaño de los datos (normalmente 1 
byte). </p>

<p><a name="progCopiafic"></a>Vamos a ver un ejemplo, que crea una copia de 
un fichero leyendo bloques de 2K:</p>

<p><pre><code class='language-pascal'>(* COPIAFIC.PAS, Copia un fichero      *)
(* Parte de CUPAS5, por Nacho Cabanes  *)

 program CopiaFichero;
 { Sencillo y rápido programa de copia de ficheros, SIN comprobación
   de errores }

var
    Origen, Destino: file;
    CantLeida, CantEscrita: Word;
    NombreOrg, NombreDest: String;
    Buffer: array[1..2048] of Char;

begin
    Write( 'Introduzca el nombre del fichero ORIGEN... ' );
    ReadLn( NombreOrg );
    Write( 'Introduzca el nombre del fichero DESTINO... ' );
    ReadLn( NombreDest );
    Assign( Origen, NombreOrg );
    Reset( Origen, 1 );                                { Tamaño = 1 }
    Assign( Destino, NombreDest );
    Rewrite( Destino, 1 );                             { Lo mismo }
    WriteLn( 'Copiando ', FileSize(Origen), ' bytes...' );
    repeat
        BlockRead( Origen, Buffer, SizeOf(Buffer), CantLeida);
        BlockWrite( Destino, Buffer, CantLeida, CantEscrita);
    until (CantLeida = 0) or (CantEscrita <> CantLeida);
    Close( Origen );
    Close( Destino );
    WriteLn( 'Terminado.' )
end. 
</code></pre></p>

<p>Un último comentario: es habitual usar "<b>SizeOf</b>"
para descubrir el tamaño de una variable, en vez de calcularlo a
mano y escribir, por ejemplo, 2048.  Es más fiable y permite
modificar el tipo o el tamaño de la variable en la que almacenamos
los datos leídos sin que eso repercuta en el resto del programa.
</p>


<p>Antes de practicar con ejercicios, vamos a ver un segundo ejemplo más 
avanzado, que muestra parte de la información contenida en la cabecera de un 
fichero GIF, leyéndolo con la ayuda de un "record":</p>

<p><pre><code class='language-pascal'>(* GIFHEAD.PAS, Lee la cabecera de un fichero GIF *)
(* Parte de CUPAS5, por Nacho Cabanes             *)

program GifHeader;

Type
    Gif_Header = Record                 { Primeros 13 Bytes de un Gif }
        Firma, NumVer     : Array[1..3] of Char;
        Tam_X,
        Tam_Y             : Word;
        _Packed,
        Fondo,
        Aspecto           : Byte;
    end;

Var
    Fich: File;
    Cabecera: GIF_Header;
    Nombre: String;

begin
    Write( '¿Nombre del fichero GIF (con extensión)? ');
    ReadLn( Nombre );
    Assign( Fich, Nombre );
    Reset( Fich, 1 );                           { Tamaño base: 1 byte }
    BlockRead( Fich, Cabecera, SizeOf(Cabecera) );
    Close( Fich );
    With Cabecera DO
    begin
        WriteLn('Version: ', Firma, NumVer);
        WriteLn('Resolución: ', Tam_X, 'x',
            Tam_Y, 'x', 2 SHL (_Packed and 7));
    end;
end. 
</code></pre></p>

<blockquote><i><b>Ejercicio propuesto 7.3.1:</b> Crea un programa que abra un fichero con extensión EXE (cuyo nombre introducirá el usuario) y compruebe si realmente se trata de un ejecutable, mirando si los dos primeros bytes del fichero corresponden a una letra "M" y una letra "Z", respectivamente.</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.3.2:</b> Crea un programa que pida al usuario dos nombres de ficheros y los compare byte a byte, para decir finalmente si son iguales o no.</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.3.3:</b> Crea un programa que pida al usuario el nombre de un fichero y vuelque a un segundo fichero todo el contenido del primero que sea imprimible (todos los caracteres por encima del 31). El segundo fichero tendrá el mismo nombre que el primero, pero se le añadirá al final ".txt" para que se pueda abrir con cualquier editor de texto.</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.3.4:</b> Crea un programa que abra un fichero con extensión BMP (cuyo nombre introducirá el usuario) y mire si parece ser una imagen BMP válida, viendo si los dos primeros bytes del fichero corresponden a una letra "B" (posición 0) y una letra "M" (posición 1), respectivamente. Si es así, mostrará el ancho de la imagen (bytes 18 a 21) y su alto (bytes 22 a 25).</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.3.5:</b> Crea un programa que muestre la información sobre un fichero MP3, a partir de estos detalles: Muchos ficheros MP3 incluyen una "cabecera" al final del fichero, conocida como"ID3 versión 1". Se trata de un bloque de tamaño fijo de 128 bytes al final del fichero en cuestión. Si es fichero contiene realmente es cabecera ID3 V1, aparecerán en primer lugar eso caracteres TAG, luego el Título (30 caracteres), el Artista (30 caracteres), el Álbum (30 caracteres), el Año (4 caracteres), un comentario (30 caracteres) y el género musical (un carácter). Todas las etiquetas usan caracteres ASCII (terminados en espacios o en carácter nulo), excepto el género, que es un número entero almacenado en un único byte. El género musical asociado a cada byte está predefinido en el estándar e incluye definiciones de 80 géneros, numerados del 0 al 79, aunque algunos programas de reproducción han ampliado por su cuenta los géneros definidos (a partir del número 80). </i></blockquote>


<h2>7.4. Abrir exclusivamente para lectura.</h2>


<p><a name="filemode"></a>Puede interesarnos leer un fichero que se encuentra
en un CdRom/DvdRom, o en una red de ordenadores. Normalmente, tanto los CdRom como 
las "unidades de red" se comportan de forma muy similar a un disco duro 
"local", de modo que no supondrá ningún problema acceder a su contenido 
desde MsDos y desde Windows. En cambio, si intentamos leer datos desde un 
CdRom o desde una unidad de red, con Turbo Pascal 7, de la misma manera que 
hemos hecho hasta ahora, nos podemos encontrar con que no lo consigamos, 
sino que obtengamos un error de "File acces denied" (se ha denegado el 
acceso al fichero).</p>

<p>El motivo es que Turbo Pascal intenta abrir el fichero tanto para leer de 
él como para escribir en él. Esto es algo útil si utilizamos nuestro disco 
duro o (en equipos antiguos) un diskette, pero normalmente no tendremos la 
posibilidad de grabar directamente datos en un CdRom convencional, ni 
tendremos a veces permisos para escribir en una unidad de red. </p>

<p>Pero podemos cambiar esta forma de comportarse de Turbo Pascal. Lo haremos
mediante la variable <b>FileMode</b>, que está definida siempre en Turbo 
Pascal (está en la unidad System). Esta variable normalmente tiene el valor 
2 (abrir para leer y escribir), pero también le podemos dar los valores 1 
(abrir sólo para escribir) y 0 (abrir sólo para lectura). </p>

<p>Por tanto, la forma de abrir un fichero que se encuentre en un CdRom
o en una unidad de red sería añadir la línea</p>

<p><pre><code class='language-pascal'>FileMode := 0;</code></pre></p> 
<p>antes de intentar abrir el fichero con "reset".</p>

<blockquote><i><b>Ejercicio propuesto 7.4.1:</b> Crea un nueva versión del programa 7.3.1, que abre un fichero con extensión EXE (cuyo nombre introducirá el usuario) y comprueba si realmente se trata de un ejecutable, mirando si los dos primeros bytes del fichero corresponden a una letra "M" y una letra "Z", respectivamente. Esta nueva versión debe abrir el fichero en modo sólo de lectura.</i></blockquote>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   6831 visitas desde el 05-06-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas07b.php">Anterior</a></li>
                    <li><a href="cupas08.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        