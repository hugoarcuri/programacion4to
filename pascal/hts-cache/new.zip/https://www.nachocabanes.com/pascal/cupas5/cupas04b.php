<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 4 - Arrays, cadenas, registros y conjuntos (2).</title>

    
    <meta name="description" content="4 - Arrays, cadenas, registros y conjuntos (2). - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="array,record,set,string" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 4 - Arrays, cadenas, registros y conjuntos (2).          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas04.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas04c.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2>4.2. Cadenas de texto (strings)</h2>

<h3>4.2.1. ¿Qué es una cadena de texto?</h3>

<p>Un <b>string</b> es una secuencia de caracteres. Se usan para almacenar
texto. En algunas versiones de Pascal existe un límite de 255 letras,
y, en ese caso, cada string ocupa 256 bytes. En otras versiones esa limitación es mucho
más suave, con tamaños por encima de 32.000 letras, como es el caso de GNU Pascal.
En Pascal estándar, el formato era string[n] (o 
string(n) en algunos compiladores), donde n es la anchura 
máxima que queremos almacenar en esa cadena de caracteres (de 0 a 255), y 
en ese caso ocupará n+1 bytes en memoria.</p>

<p>Vamos a ver un primer ejemplo que pida al usuario su nombre y le salude:</p>

<p><pre><code class='language-pascal'>(* SALUDO.PAS, Pedir nombre al usuario y saludarle  *)
(* Parte de CUPAS5, por Nacho Cabanes               *) 

program Saludo;

var
    nombre: string[30];

begin
    writeLn('Introduce tu nombre, por favor');
    readLn(nombre);
    write('Hola ',nombre);
end.

(* Ejemplo de ejecucion:
Introduce tu nombre, por favor
Nacho
Hola Nacho
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.1.1:</b> Crea un programa que te pida tres palabras
    y las muestre separadas por espacios y en el orden contrario a como las
    has introducido (primero la tercera palabra, después la segunda y finalmente la primera).</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.1.2:</b> Crea un programa que pida al usuario su nombre y su apellido y luego los escriba al revés, separados por una coma. Por ejemplo si el usuario introduce Nacho como nombre y Cabanes como apellido, se escribirá Cabanes, Nacho.</i></blockquote>
<p>Podemos dar un valor a una cadena, o comparar el valor de una cadena con un texto
prefijado, si indicamos el texto entre comillas simples, así:</p>

<p><pre><code class='language-pascal'>(* STRING1.PAS, Dar valor prefijado a un string  *)
(* Parte de CUPAS5, por Nacho Cabanes            *) 

program String1;

var
    saludo: string;

begin
    saludo := 'Hola, soy un texto';
    writeLn( saludo );
end.

(* Resultado:
Hola, soy un texto
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.1.3:</b> Crea un programa que pida al usuario su nombre. Si es Nacho, le dirá "Hola";
    si es otro nombre, le responderá "No te conozco".</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.1.4:</b> Crea un programa que pida nombres al usuario. Cuando el usuario introduzca
    un nombre, por ejemplo "Juan", le responderá saludándole (por ejemplo, "Hola, Juan").
    Terminará cuando el nombre que introduzca el usuario sea "fin".</i></blockquote>


<h3>4.2.2. Acceder a las letras de una cadena</h3>

<p>Podemos acceder a las letras que forman una cadena usando corchetes, 
como si se tratara de un array de caracteres, en el que el primer elemento
está en la posición 1 y la cantidad de letras se sabe con "length":</p>

<p><pre><code class='language-pascal'>(* STRING2.PAS, Acceder a las letras de un string  *)
(* Parte de CUPAS5, por Nacho Cabanes              *) 

program String2;

var
    saludo: string;

begin
    saludo := 'Hola, soy un texto';
    writeLn( 'El texto tiene ', length(saludo), ' letras' );
    writeLn( 'La primera es ', saludo[1] );
end.

(* Resultado:
El texto tiene 18 letras
La primera es H
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.2.1:</b> Crea un programa que te pida tu nombre y lo muestre al revés (de la última letra a la primera).</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.2.2:</b> Crea un programa que te pida tu nombre y muestre las letras separadas por espacios (por ejemplo, "Nacho" se convertiría en "N a c h o".</i></blockquote>



<h3>4.2.3. Operaciones habituales con cadenas</h3>

<p>Podemos crear una cadena a partir de varias (<b>concatenar</b>), usando el símbolo de la suma o la orden <b>concat</b>, que a la que indicaremos varias subcadenas entre paréntesis:</p>

<p><pre><code class='language-pascal'>(* STRING3.PAS, Concatenar cadenas     *)
(* Parte de CUPAS5, por Nacho Cabanes  *) 

program String3;

var
    palabra1, palabra2, espacio: string;
    resultado1, resultado2: string;

begin
    palabra1 := 'Hola';
    espacio := ' ';
    palabra2 := 'Pascal';
    
    resultado1 := palabra1 + espacio + palabra2 + '!';
    resultado2 := concat(palabra1, '-', palabra2);
    writeLn( resultado1 );
    writeLn( resultado2 );
end.

(* Resultado:
Hola Pascal!
Hola-Pascal
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.3.1:</b> Crea un programa que pida al usuario su nombre y su apellido,
    cree una cadena formada por el apellido, una coma y el nombre (por ejemplo
    si el usuario introduce Nacho como nombre y Cabanes como apellido, la
    cadena contendrá "Cabanes, Nacho"), y finalmente escriba esa cadena.</i></blockquote>

<p>Si necesitamos partir de una cadena <b>vacía</b> (por ejemplo, para irle añadiendo letras) o bien queremos vaciar una cadena ya existente, lo podemos hacer usando dos comillas simples que no contengan nada entre medias (ni siquiera un espacio):</p>

<p><pre><code class='language-pascal'>(* STRING4.PAS, Vaciar una cadena     *)
(* Parte de CUPAS5, por Nacho Cabanes *) 

program String4;

var
    texto: string;
    i: integer;

begin
    texto := '';
    writeLn( 'El texto es ', texto );
    
    for i := 1 to 10 do
        texto := texto + '-';
    writeLn( 'Ahora el texto es ', texto );
end.

(* Resultado:
El texto es
Ahora el texto es ----------
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.3.2:</b> Crea un programa que cree y muestre una cadena formada por 20 símbolos de
    exclamación (!).</i></blockquote>

<p>Podemos <b>extraer una subcadena</b> (un fragmento del texto original) con la
orden <b>copy</b>, que debe recibir tres parámetros: la cadena, la posición de comienzo
y la cantidad de caracteres a extraer:</p>

<p><pre><code class='language-pascal'>(* STRING5.PAS, Extraer una subcadena *)
(* Parte de CUPAS5, por Nacho Cabanes *) 

program String5;

var
    texto: string;

begin
    texto := 'Hola, esto es un ejemplo';
    writeLn( 'La primera palabra es ', copy(texto,1,4) );
    writeLn( 'Otro fragmento es "', copy(texto,9,5), '"' );
end.

(* Resultado:
La primera palabra es Hola
Otro fragmento es "to es"
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.3.3:</b> Crea un programa que te pida tu nombre y escriba un triángulo creciente, que empiece con una letra, siga con dos y vaya aumentando hasta mostrar todas las letras:<br> N<br>Na<br>Nac<br>Nach<br>Nacho</i></blockquote>

<p>También es posible <b>ver si contiene una subcadena</b>, usando <b>pos</b>, que recibe como datos
la subcadena a buscar y la cadena que la contiene, y devolverá 0 si no aparece, o un número mayor
que cero (la posición) en caso de que sí esté contenida:</p>

<p><pre><code class='language-pascal'>(* STRING6.PAS, Posicion de una subcadena *)
(* Parte de CUPAS5, por Nacho Cabanes     *) 

program String6;

var
    texto: string;

begin
    texto := 'Hola, esto es un ejemplo';
    writeLn( 'La palabra "esto" aparece en la posicion ', 
        pos('esto', texto));
end.

(* Resultado:
La palabra "esto" aparece en la posicion 7 
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.3.4:</b> Crea un programa que pida al usuario una frase y diga si contiene
    la palabra "hola" y, en caso afirmativo, en qué posición.</i></blockquote>
<p>Finalmente, también tenemos la posibilidad de <b>insertar una subcadena</b>, usando <b>insert</b>, o de <b>borrar una subcadena</b>, con <b>delete</b>. A "insert" se le indican 3 datos: el texto a insertar, la cadena dentro de la que queremos incluirlo, y la posición en la que debe aparecer; a "delete" se le detalla la cadena, la posición en la que empezar a borrar y la cantidad de letras a eliminar:</p>

<p><pre><code class='language-pascal'>(* STRING7.PAS, Insertar y borrar en una cadena *)
(* Parte de CUPAS5, por Nacho Cabanes           *) 

program String7;

var
    texto: string;

begin
    texto := 'Hola, esto es un ejemplo';
    writeLn( 'El texto original es ', texto );
    
    insert( ' amigo,', texto, 6);
    writeLn( 'Tras insertar queda ', texto );
    
    delete( texto, 14, 5);
    writeLn( 'Y tras borrar queda ', texto );
end.

(* Resultado:
El texto original es Hola, esto es un ejemplo
Tras insertar queda Hola, amigo, esto es un ejemplo
Y tras borrar queda Hola, amigo, es un ejemplo
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.3.5:</b> Crea un programa que pida al usuario su nombre. Si el nombre incluye "Sr. ", deberás borrar esa partícula. Donde estuviera ese "Sr. ", deberás incluir "Usuario del sistema: ".</i></blockquote>
<p>Además, algunas versiones de Pascal permiten convertir un texto a minúsculas o a mayúsculas de forma simple. Por ejemplo, con FreePascal se puede usar upperCase(x) para convertir un string a mayúsculas y lowerCase(x) para convertir a minúsculas.</p>

<blockquote><i><b>Ejercicio propuesto 4.2.3.6:</b> Crea un programa que pida al usuario su nombre y lo muestre en mayúsculas</i></blockquote>
<p>Y si necesitamos el valor numérico de una cadena de texto, lo podemos hacer con "VAL", que se usa VAL(texto, valor, codigoDeError). En "valor" obtendremos el valor de la cadena, si es que se puede convertir claramente a un número. Si no se pudiera convertir, el valor sería 0 y "codigoDeError" tendría un valor distinto de cero (que indica la posición de la cadena en la que ha fallado la conversión).</p>



<h3>4.2.4. Arrays de cadenas</h3>

<p>Podemos crear un array formado por varias cadenas de texto, igual que los creábamos a partir de datos numéricos. El manejo será idéntico. La única peculiaridad que merece la pena comentar es que si queremos acceder a una letra concreta de una de esas cadenas deberemos usar dos pares de corchetes: la primera pareja indicará la posición en que está la frase dentro del array, y la segunda pareja de corchetes detallará qué letra dentro de esa cadena:</p>

<p><pre><code class='language-pascal'>(* ARRAYST.PAS, Contacto con array de strings *)
(* Parte de CUPAS5, por Nacho Cabanes         *)
 
Program ArraySt;
 
var
    datos: array[1..4] of string;
 
begin
    datos[1] := 'Hola';
    datos[2] := 'Adios';
    datos[3] := '1234';
    datos[4] := '(.,)';
 
    writeLn('La tercera letra de la segunda cadena es ',
        datos[2][3]);
end. 

(* Resultado:
La tercera letra de la segunda cadena es i
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.2.4.1:</b> Crea un programa que pida 5 frases al usuario y luego las muestre en orden contrario a como se introdujeron (de la última frase a la primera).</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.4.2:</b> Crea un programa que te pida 5 nombres, los guarde en un array y luego muestre sus iniciales.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.4.3:</b> Crea un programa que pida al usuario el número de un mes (por ejemplo, 3) y responda la cantidad de días que tiene ese mes (31) y su nombre (marzo). Utiliza para ello dos arrays, uno que contenga números enteros y otro que contenga textos.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.4.4:</b> Crea un programa que pida al usuario el nombre de un mes (por ejemplo, "marzo") y responda el nombre de ese mes en inglés ("march"), usando dos arrays de cadenas de texto.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.2.4.5:</b> Crea un programa que pida al usuario el nombre de un mes (por ejemplo, "marzo") y responda el nombre de ese mes en inglés ("march"), usando un array bidimensional de cadenas de texto.</i></blockquote>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   10551 visitas desde el 19-03-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas04.php">Anterior</a></li>
                    <li><a href="cupas04c.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        