<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 9.1. ¿Por qué usar variables dinámicas?</title>

    
    <meta name="description" content="9.1. ¿Por qué usar variables dinámicas? - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="punteros,memoria dinámica" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 9.1. ¿Por qué usar variables dinámicas?          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas08.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas09b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>9. Variables dinámicas</h1> 

<h2>9.1. ¿Por qué usar variables dinámicas?</h2> 

<p>En Pascal estándar, tal y como hemos visto hasta ahora, tenemos
una serie de variables que declaramos al principio del programa o de cada
módulo (función o procedimiento, unidad, etc).  Estas
variables, que reciben el nombre de <b>estáticas</b>, tienen un
tamaño asignado desde el momento en que se crea el programa.</p>

<p>Esto hace que la ejecución sea muy rápida y que sea fácil detectar errores, pero
sólo cuando vamos a manejar estructuras de datos que no cambien. Si, por el contrario,
necesitamos almacenar un cantidad variable de datos, una estructura estática
como un "array" puedo no ser útil o, como poco, resultar poco eficiente.
</p>

<p>Pensemos en el caso de una agenda, que deba contener una serie de fichas 
de personas. Si creemos que necesitaremos guardar fichas para 20 personas, y 
reservamos espacio exactamente para esas 20, no podremos llegar a añadir 21 
si nuestras necesidades cambian. Si "sobredimensionamos", reservando espacio 
para 100, en un caso normal estaremos desperdiciando el espacio de 80 datos 
no utilizados, lo que tampoco es una buena solución.</p> 

<p>Una alternativa sería trabajar siempre en disco: conservar sólo una ficha 
en memoria y descargar un nuevo dato cada vez que lo necesitemos. Así no 
tendremos límite en cuanto a número de fichas, pero el funcionamiento será 
muchísimo más lento. </p> 

<p>Lo ideal sería aprovechar mejor la memoria que tenemos en el ordenador, 
para guardar en ella todas las fichas o al menos todas aquellas que quepan 
en memoria. </p>


<p>Todas estas limitaciones se solucionan con el uso de <b>variables 
dinámicas</b>, para las cuales se reserva espacio en el momento de ejecución 
del programa, sólo en la cantidad necesaria, se pueden añadir elementos 
después, y se puede aprovechar toda la memoria libre de nuestro equipo. </p> 


<blockquote><i><b>Ejercicio propuesto 9.1.1:</b> Como primera aproximación al uso de memoria dinámica,
    crea un programa que pida al usuario una cantidad indeterminada de números,
    y tras cada número muestre la suma de todos los números que se han introducido
    hasta ese momento. Terminará cuando se introduzca "fin" en vez de un número.
    (Pista: ¿necesitas almacenar todos esos números?)</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.1.2:</b> Como segunda aproximación al uso de memoria dinámica,
    crea un programa que pida al usuario una cantidad indeterminada de números,
    y tras cada número muestre todos los que se han introducido
    hasta ese momento, en orden inverso, en una misma línea.
    Terminará cuando se introduzca "fin" en vez de un número.
    (Pista: ¿necesitas almacenar todos esos números? Reserva espacio para 10 números, ¿qué ocurre
    cuando intentas guardar más?)</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.1.3:</b> Como tercera aproximación al uso de memoria dinámica, crea
    un programa que permita guardar (hasta) 10 strings. Se mostrará al
    usuario un menú que le permita añadir un nuevo string (a continuación de
    los ya existentes), ver todos los datos existentes o salir. Cuando el espacio
    para (10) datos esté lleno, se deberá avisar al usuario, en vez de intentar
    añadir nuevos datos e interrumpir la ejecución.</i></blockquote>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   3107 visitas desde el 22-06-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas08.php">Anterior</a></li>
                    <li><a href="cupas09b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        