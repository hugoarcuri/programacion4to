<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - (Pronto)</title>

    
    <meta name="description" content="Curso de Pascal - (Pronto) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="forward" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - (Pronto)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas06e.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas06g.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>

<h2>6.6. La sentencia "forward"</h2>
<a name="forward"></a>

<p>En Pascal, cualquier función o procedimiento debe ser declarado antes de 
usarlo, o el programa no compilará. Esto no suele ser un problema, pero existe 
un caso puntual en el que no es posible: Cuando desde un procedimiento A se 
llame a otro B, pero a su vez, el procedimiento B pueda llamar a A.</p>

<p>En este (poco habitual) caso, cada uno de los procedimientos exigiría
que el otro se hubiese detallado antes, la única solución
es decirle que uno de los dos (por ejemplo "A") ya lo detallaremos más
adelante, pero que existe. Así ya podemos escribir "B" y después
dar los detalles sobre cómo es "A", así:</p>


<p><pre><code class='language-pascal'>(* FORW.PAS, Ejemplo de "forward"     *)
(* Parte de CUPAS5, por Nacho Cabanes *)

program forw;

procedure A(n: byte); forward;  { No detallamos cómo es "A", porque
                                    "A" necesita a "B", que el compilador
                                    aún no conoce; por eso sólo  "declaramos"
                                    "A", e indicamos con "forward" que
                                    más adelante lo detallaremos }

procedure B (n: byte);          { "B" ya puede llamar a "A" }
begin
  writeLn('Entrando a B, con parámetro ', n);
  if n>0 then A (n-1);
end;

procedure A;                   { Y aquí detallamos "A"; ya no hace falta }
begin                          { volver a indicar los parámetros }
  writeLn('Entrando a A, con parámetro ', n);
  if n>0 then B (n-1);
end;

begin
  A(6);
end. 

(* 
Ejemplo de ejecucion:
Entrando a A, con parámetro 6
Entrando a B, con parámetro 5
Entrando a A, con parámetro 4
Entrando a B, con parámetro 3
Entrando a A, con parámetro 2
Entrando a B, con parámetro 1
Entrando a A, con parámetro 0
*)  
</code></pre></p>
<p>En otros lenguajes se pueden detallar las funciones tras el cuerpo del 
programa, pero no es el caso en Pascal, ni siquiera empleando "forward": tras 
el punto final de la orden "end" que indica que acaba el cuerpo del programa no 
puede haber ninguna función ni procedimiento.</p>

<p>Una alternativa más moderna al uso de "forward" es emplear "unidades", que 
veremos más adelante.</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   2993 visitas desde el 06-10-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas06e.php">Anterior</a></li>
                    <li><a href="cupas06g.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        
