<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal (v5)</title>

    
    <meta name="description" content="Curso de Pascal (v5) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="pascal,delphi,lazarus,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal (v5)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="index.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas00.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>
      <a name="cupas"><h2>Curso de Pascal de Nacho Cabanes</h2></a>
      <ul>
        <li><a href="cupas00.php">0 - Contacto: instalar y escribir en pantalla</a>.
        </li>
            <ul></ul>


        <li>1 - Pedir datos al usuario:
        </li>
            <ul>
                <li><a href="cupas01.php">1a - variables</a></li>
                <li><a href="cupas01b.php">1b - tipos de datos básicos</a>.</li>
            </ul>
        
        
        <li>2 - Condiciones:
        </li>
            <ul>
                <li><a href="cupas02.php">2a - if</a></li>
                <li><a href="cupas02b.php">2b - booleans, case</a>.</li>
            </ul>        

            
        <li><a href="cupas03.php">3 - Estructuras repetitivas</a>. 
        </li>
            <ul>
                <li><a href="cupas03.php">3a - for</a>.</li>
                <li><a href="cupas03b.php">3b - while, repeat..until</a>.</li>
            </ul>

            
        <li><a href="cupas04.php">4 - Arrays, cadenas, registros y conjuntos</a>.  
        </li>
            <ul>
                <li><a href="cupas04.php">4a - Arrays</a>.</li>
                <li><a href="cupas04b.php">4b - Cadenas de texto</a>.</li>
                <li><a href="cupas04c.php">4c - Registros</a>.</li>
                <li><a href="cupas04d.php">4d - Subrangos, enumerados, conjuntos</a>.</li>
            </ul>
        

        <li>5 - <a href="cupas05.php">Constantes</a> y <a href="cupas05b.php">tipos</a>.
        </li>
            <ul>
                <li><a href="cupas05.php">Constantes</a></li>
                <li><a href="cupas05b.php">Tipos</a></li>
            </ul>
        
        <li><a href="cupas06.php">6 - Procedimientos y funciones</a>. 
        </li>
            <ul>
                <li><a href="cupas06.php">6a - Procedimientos</a>.</li>
                <li><a href="cupas06b.php">6b - Parámetros</a>.</li>
                <li><a href="cupas06c.php">6c - Funciones</a>.</li>
                <li><a href="cupas06d.php">6d - Modificación de parámetros</a>.</li>
                <li><a href="cupas06e.php">6e - Recursividad</a>.</li>
                <li><a href="cupas06f.php">6f - Forward</a>.</li>
                <li><a href="cupas06g.php">6g - Funciones incorporadas</a>.</li>
            </ul>
        
        <li><a href="cupas07.php">7 - Ficheros</a>.
        </li>
            <ul>
                <li><a href="cupas07.php">7a - Ficheros de texto</a>.</li>
                <li><a href="cupas07b.php">7b - Ficheros con tipo</a>.</li>
                <li><a href="cupas07c.php">7c - Ficheros binarios</a>.</li>
            </ul>
        
        
        <li><a href="cupas08.php">8 - Unidades</a>.</li>
        
        <li><a href="cupas09.php">9 - Estructuras dinámicas</a>.
        </li>
            <ul>
                <li><a href="cupas09.php">9a - ¿Por qué usar estructuras dinámicas?</a>.</li>
                <li><a href="cupas09b.php">9b - Pilas</a>.</li>
                <li><a href="cupas09c.php">9c - Colas</a>.</li>
                <li><a href="cupas09d.php">9d - Listas enlazadas</a>.</li>
                <li><a href="cupas09e.php">9e - Listas ordenadas</a>.</li>
                <li><a href="cupas09f.php">9f - Árboles binarios</a>. (*)</li>
                <li><a href="cupas09g.php">9g - Arrays dinámicos</a>.</li>
                <li><a href="cupas09h.php">9h - Listas de strings</a>.</li>
            </ul>
            
        <li><a href="cupas10.php">10 - Programación orientada a objetos</a>. (*)</li>
        <li><a href="cupas11.php">11 - Pantalla en modo texto</a>.</li>
        <li><a href="cupas12.php">12 - Gráficos</a>. (*)</li>
        <li><a href="cupas13.php">13 - Servicios del sistema</a>.</li>
        <li><a href="cupas14.php">14 - Entornos visuales</a>. (*)</li>
                
        <li><a href="cupasejercicios.php">Recopilación de ejercicios propuestos</a>.</li>
        <li><a href="cupascambios.php">Cambios entre versiones y próximas mejoras</a>.</li>
      </ul>
      
      <h2>Foros sobre Pascal y Free Pascal</h2>
      <ul>
        <li><a href="http://www.aprendeaprogramar.com/mod/forum/view.php?id=19">Foro de Pascal</a> en <a href="http://www.aprendeaprogramar.com/">AprendeAProgramar.com</a></li>
      </ul>


           </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   31785 visitas desde el 23-02-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="index.php">Anterior</a></li>
                    <li><a href="cupas00.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        