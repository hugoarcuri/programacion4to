<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 6 - Procedimientos y funciones (3)</title>

    
    <meta name="description" content="6 - Procedimientos y funciones (3) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="generalidades,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 6 - Procedimientos y funciones (3)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas06b.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas06d.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h2>6.3. Funciones</h2>

<p>En muchas ocasiones querremos obtener un valor como resultado de esa "subrutina" que hemos creado. Llamaremos "<b>función</b>" a un procedimiento capaz de devolver un valor. Por ejemplo, podríamos crear una función sencilla, que calcule (y devuelva) el doble del número que se le pase como parámetro, así:</p>

<p><pre><code class='language-pascal'>(* DOBLE.PAS, Primer ejemplo de funcion *)
(* Parte de CUPAS5, por Nacho Cabanes   *)

program FuncionDoble;

function doble( numero: integer): integer;
begin
    doble := numero * 2;
end;

(* Cuerpo del programa *)
var
    n: integer;

begin
    write('Introduce un numero entero: ');
    readLn( n );
    writeLn('Su doble es: ', doble(n) );
    writeLn('Y el doble de 5 es: ', doble(5) );
end. 

(* 
Ejemplo de ejecucion:
Introduce un numero entero: 3
Su doble es: 6
Y el doble de 5 es: 10
*)
</code></pre></p>
<p>Aquí hay varios detalles que merece la pena comentar, algunos de ellos nuevos:</p>

<ul>
    <li> Esta función se llama "doble".</li>
    <li> Tiene un <b>parámetro</b> llamado "numero", que es un número entero.</li>
    <li> El resultado va a ser también un número entero.</li>
    <li> Antes de salir de la función, le asignamos el que será su valor definitivo.</li>
    <li> Desde el cuerpo del programa usamos la función 2 veces: la primera para calcular el doble del número "n", que ha introducido el usuario, y la segunda para hallar el doble de 5.</li>
</ul> 
 

<blockquote><i><b>Ejercicio propuesto 6.3.1:</b> Crea una función "triple", que reciba un número real como parámetro, y devuelva como resultado ese número multiplicado por tres.</i></blockquote>    


<p>Una función puede recibir más de un parámetro, y puede realizar operaciones más complejas. Por ejemplo, podríamos calcular una potencia (un número elevado a otro) mediante multiplicaciones repetitivas, así:</p>

<p><pre><code class='language-pascal'>(* POTENCIA.PAS, Segundo ejemplo de funcion *)
(* Parte de CUPAS5, por Nacho Cabanes       *)

program PruebaDePotencia;


function potencia(a,b: integer): integer;   (* Definimos la funcion *)
var
    i: integer;                      (* Locales: para bucles *)
    temporal: integer;               (* y para el valor temporal *)
begin
    temporal := 1;                    (* Inicializacion *)
    for i := 1 to b do
        temporal := temporal * a;     (* multiplicamos "b" veces por "a" *)
    potencia := temporal;             (* y finalmente devolvemos el valor *)
end;


var
    numero1, numero2: integer;

begin                                (* Cuerpo del programa *)
    writeLn('Potencia de un numero entero');
    writeLn;
    writeLn('Introduce el primer numero');
    readLn( numero1 );
    writeLn('Introduce el segundo numero');
    readLn( numero2 );
    writeLn( numero1 ,' elevado a ', numero2 ,' vale ',
        potencia (numero1, numero2) )
end. 
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 6.3.2:</b> Prepara una función llamada "media", que reciba dos números reales como parámetros, y devuelva como resultado su media aritmética.</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.3.3:</b> Crear una función "potenciaReal", que trabaje con números reales, y permita cálculos como 3.2 elevado a 1.7 (pista; hay que usar exponenciales y logaritmos, como vimos en el apartado 1.6.3</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.3.4:</b> Haz una función que halle la raíz cúbica del número que se le indique (pista: hallar una raíz cúbica es lo mismo que elevar a 1/3).</i></blockquote><blockquote><i><b>Ejercicio propuesto 6.3.5:</b> Define las funciones Suma3 y Producto3, que calculen suma y producto de tres números enteros, y crea un programa que haga una operación u otra según escoja el usuario (empleando "case").</i></blockquote>    



<p>Por supuesto, una función puede devolver valores de otros tipos, no solo numéricos. Así, una función que nos devolviera la inicial de una palabra podría ser:</p>

<p><pre><code class='language-pascal'>(* INICIAL.PAS, Funcion que devuelve char *)
(* Parte de CUPAS5, por Nacho Cabanes     *)

program FuncionInicial;

function inicial( texto: string): char;
begin
    inicial := texto[1];
end;

(* Cuerpo del programa *)
var
    frase: string;

begin
    write('Introduce una frase: ');
    readLn( frase );
    writeLn('Su primera letra es: ', inicial(frase) );
end. 

(* 
Ejemplo de ejecucion:
Introduce una frase: hola, que tal
Su primera letra es: h
*)
</code></pre></p>


<p>O bien podríamos recorrer una frase formada por varias palabras, para así construir y devolver una cadena que contenga las iniciales de todas ellas:</p>

<p><pre><code class='language-pascal'>(* INICIALES.PAS, Funcion que devuelve un string *)
(* Parte de CUPAS5, por Nacho Cabanes            *)

program FuncionIniciales;

function iniciales( texto: string): string;
var
    temporal: string;
    i: byte;
begin
    temporal := '';
    temporal := temporal + texto[1];
    for i := 2 to length(texto) do
        if texto[i-1] = ' ' then
            temporal := temporal + texto[i];
    iniciales := temporal;
end;

(* Cuerpo del programa *)
var
    frase: string;

begin
    write('Introduce una frase con varias palabras: ');
    readLn( frase );
    writeLn('Sus iniciales son: ', iniciales(frase) );
end. 

(* 
Ejemplo de ejecucion:
Introduce una frase con varias palabras: hola, que tal
Sus iniciales son: hqt
*)
</code></pre></p>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   5568 visitas desde el 13-04-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas06b.php">Anterior</a></li>
                    <li><a href="cupas06d.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        