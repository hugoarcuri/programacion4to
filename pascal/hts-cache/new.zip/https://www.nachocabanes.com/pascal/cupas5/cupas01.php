<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 1. Pedir datos al usuario. Operaciones aritméticas. Variables</title>

    
    <meta name="description" content="1. Pedir datos al usuario. Operaciones aritméticas. Variables - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="generalidades,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 1. Pedir datos al usuario. Operaciones aritméticas. Variables          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas00.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas01b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>1. Pedir datos al usuario. Operaciones aritméticas. Variables</h1>

<h2>1.1. Datos calculados</h2>

<p>Hemos visto que para escribir algo usaremos la orden "write". Entre paréntesis se indica lo que queremos mostrar. Si se trata de un texto que queremos escribir "tal cual", lo encerraremos además entre comillas, pero en ocasiones no desearemos que se escriba de forma literal, sino que el ordenador <b>analice una cierta expresión</b> y nos muestre su resultado. Por ejemplo, podemos realizar una suma de la siguiente forma:</p>

<p><pre><code class='language-pascal'>(* Suma calculada *)

program Suma1;

begin 
  write(5+2);
end.

(* Resultado:
7
*)
</code></pre></p>
<p>A partir de ahora, nuestros programas de ejemplo, seguirán (siempre que sea posible) el esquema anterior: comenzarán con un comentario que recuerde su cometido, incluirán la palabra "program" al principio, seguida del cuerpo del programa, y terminarán con un nuevo comentario, que muestre lo que aparecería en pantalla al ejecutar el programa. No incluirán la orden "<b>readLn;</b>" al final, que, como hemos visto en el apartado 0.4, podría ser necesaria si usas Lazarus para que no se cierre la ventana sin que dé tiempo a leer su contenido.</p>

<blockquote><i><b>Ejercicio propuesto 1.1.1:</b> Crea un programa que calcule la suma de 23 y 38.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.1.2:</b> Crea un programa que muestre el resultado de sumar 123456 y 789012.</i></blockquote>

<p>Pero realmente hay más: con una misma orden "write" se pueden <b>escribir varios datos</b>, separados por comas. Por ejemplo, podemos escribir una operación matemática y su resultado con una única orden "write", así:</p>

<p><pre><code class='language-pascal'>(* Suma detallada y calculada *)

program Suma2;

begin 
  write('5+2=', 5+2);
end.

(* Resultado:
5+2=7
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 1.1.3:</b> Crea un programa que muestre la operación "1234 + 5486" y su resultado.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.1.4:</b> Crea un programa que muestre la operación "5486 - 1234" y su resultado.</i></blockquote>

<h2>1.2. Avanzar de línea</h2>

<p>Ya sabemos que podemos escribir varios datos en una misma línea, bien usando dos órdenes "write" consecutivas, o bien con una única orden "write" que tenga varios datos separados por comas. Pero es frecuente que nos interese <b>escribir datos en líneas distintas</b>. Es fácil: en vez de "write" usaremos "<b>writeLn</b>", y el curso bajará a la línea siguiente de pantalla cuando termine de escribir:</p>

<p><pre><code class='language-pascal'>(* Suma y avance de linea *)

program SumaWriteLn;

begin 
  write('Un ejemplo');
  writeLn(' de suma:');
  writeLn('5+2=', 5+2);
end.

(* Resultado:
Un ejemplo de suma:
5+2=7
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 1.2.1:</b> Crea un programa que escriba "Hola" y, en la línea siguiente, tu nombre.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.2.2:</b> Crea un programa que muestre la suma de 78 y 41 y, en la línea siguiente, su diferencia.</i></blockquote>

<h2>1.3. Operaciones matemáticas</h2>

<p>Ya hemos visto que podemos sumar con el símbolo "+" y restar con "-". La división también es fácil, con la barra de <b>división</b>: "/". La <b>multiplicación</b> puede parecer un poco menos intuitiva, porque se realiza con el "asterisco" ("*").</p>
 
<p><pre><code class='language-pascal'>(* Operaciones aritmeticas (1) *)

program Operaciones1;

begin 
  writeLn('5+2=', 5+2);
  writeLn('5-2=', 5-2);
  writeLn('5/2=', 5/2);
  writeLn('5*2=', 5*2);
end.

(* Resultado:
5+2=7
5-2=3
5/2=2.5000000000000000E+0000
5*2=10
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 1.3.1:</b> Crea un programa que muestre el producto de 56 y 39.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.3.2:</b> Crea un programa que calcule la multiplicación de 12345 por 98765.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.3.3:</b> Crea un programa que muestre el resultado de dividir 12345 entre 974.</i></blockquote>
<p>Como los datos del ejemplo anterior eran números enteros (sin cifras decimales), los resultados también son números enteros, excepto para la división, que sí tendrá cifras decimales, y aparece en un formato "raro". Dentro de poco veremos cómo mejorarlo.</p>

<p>Si queremos sólo la parte de la división, deberemos usar la palabra "<b>div</b>", mientras que con "<b>mod</b>" podemos obtener el resto de la división, de la siguiente manera:</p>
 
<p><pre><code class='language-pascal'>(* Operaciones aritmeticas (2) *)

program Operaciones2;

begin 
  writeLn('7 div 2 = ', 7 div 2);
  writeLn('7 mod 2 = ', 7 mod 2);
end.

(* Resultado:
7 div 2 = 3
7 mod 2 = 1
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 1.3.4:</b> Crea un programa que muestre la división entera (sin decimales) de 12345 entre 974.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.3.5:</b> Crea un programa que calcule la multiplicación de 12345 por 98765.</i></blockquote>
<p>La operación "módulo" (mod) nos será mucho más útil de lo que parece: comprobando el resto de dividir un número entre 2 podemos saber si es par, comprobando el resto entre 10 o cualquier otro número podemos comprobar si es múltiplo de éste. La usaremos con una cierta frecuencia... dentro de poco...</p>


<p>También podemos realizar <b>operaciones entre bits</b>, que quizá te resulten todavía demasiado avanzadas si aún no has estudiado nada sobre el sistema binario de numeración, pero mencionaremos las ideas básicas, porque más adelante nos serán útiles en algunos casos puntuales.</p>

<table cellspacing="0" cellpadding="0">
  <tr>
    <td width="168" valign="top"><p>Operaci&oacute;n </p></td>
    <td width="180" valign="top"><p>Resultado </p></td>
    <td width="48" valign="top"><p>Sintaxis </p></td>
    <td width="144" valign="top"><p>Ejemplo </p></td>
  </tr>
  <tr>
    <td width="168" valign="top"><p>Complemento </p></td>
    <td width="180" valign="top"><p>Cambiar 0 por 1 y viceversa </p></td>
    <td width="48" valign="top"><p>not</p></td>
    <td width="144" valign="top"><p>not 1100 = 0011 </p></td>
  </tr>
  <tr>
    <td width="168" valign="top"><p>Producto l&oacute;gico </p></td>
    <td width="180" valign="top"><p>1 s&oacute;lo si los 2 bits son 1 </p></td>
    <td width="48" valign="top"><p>and </p></td>
    <td width="144" valign="top"><p>1101 and 1011 = 1001 </p></td>
  </tr>
  <tr>
    <td width="168" valign="top"><p>Suma l&oacute;gica </p></td>
    <td width="180" valign="top"><p>1 si al menos uno de los bits es 1 </p></td>
    <td width="48" valign="top"><p> or </p></td>
    <td width="144" valign="top"><p>1101 or 1011 = 1111 </p></td>
  </tr>
  <tr>
    <td width="168" valign="top"><p>Suma exclusiva </p></td>
    <td width="180" valign="top"><p>1 s&oacute;lo si los 2 bits son distintos </p></td>
    <td width="48" valign="top"><p>xor </p></td>
    <td width="144" valign="top"><p>1101 xor 1011 = 0110 </p></td>
  </tr>
  <tr>
    <td width="168" valign="top"><p>Desplazamiento a la izquierda </p></td>
    <td width="180" valign="top"><p>Desplaza y rellena con ceros </p></td>
    <td width="48" valign="top"><p>shl </p></td>
    <td width="144" valign="top"><p>1101 shl 2 = 110100 </p></td>
  </tr>
  <tr>
    <td width="168" valign="top"><p>Desplazamiento a la derecha </p></td>
    <td width="180" valign="top"><p>Desplaza y rellena con ceros </p></td>
    <td width="48" valign="top"><p>shr </p></td>
    <td width="144" valign="top"><p>1101 shr; 2 = 0011 </p></td>
  </tr>
</table>

<p>Un programa que los probase podría ser:</p>

<p><pre><code class='language-pascal'>(* Operaciones a nivel de bit *)

program OpBits;

begin 
    writeLn('El complemento de 67 es: ', not 67);
    writeLn('El producto lógico de 67 y 33 es: ', 67 and 33);
    writeLn('Su suma lógica es: ', 67 or 33);
    writeLn('Su suma lógica exclusiva es: ', 67 xor 33);
    writeLn('Desplacemos a a la izquierda: ', 67 shl 1);
    writeLn('Desplacemos a a la derecha: ', 67 shr 1);
end.
</code></pre></p>
<p>La respuesta que obtendremos es la siguiente:</p>

<pre>El complemento de 67 es: -68
El producto lógico de 67 y 33 es: 1
Su suma lógica es: 99
Su suma lógica exclusiva es: 98
Desplacemos a a la izquierda: 134
Desplacemos a a la derecha: 33</pre>

<p>Para comprobar que es correcto, podemos convertir al sistema binario esos dos n&uacute;meros y seguir las operaciones paso a paso (insisto, puedes saltarte este apartado si no has estudiado el sistema binario, porque no es algo que vayamos a usar con frecuencia así que no necesitas dominarlo):</p>
<p> 67 = 0100 0011<br />
  33 = 0010 0001</p>
<p>En primer lugar complementamos &quot;a&quot;, cambiando los ceros por unos:</p>
<p> 1011 1100 = -68</p>
<p>Despu&eacute;s hacemos el producto l&oacute;gico de A y B, multiplicando cada bit, de modo que 1*1 = 1, 1*0 = 0, 0*0 = 0</p>
<p> 0100 0011 and 0010 0001 = 0000 0001 = 1</p>
<p>Despu&eacute;s hacemos su suma l&oacute;gica, sumando cada bit, de modo que 1+1 = 1, 1+0 = 1, 0+0 = 0<br />
  0100 0011 or 0010 0001 = 0110 0011 = 99</p>
<p>La suma l&oacute;gica exclusiva devuelve un 1 cuando los dos bits son distintos: 1 xor 1 = 0, 1 xor 0 = 1, 0 xor 0 = 0</p>
<p> 0100 0011 xor 0010 0001 = 0110 0010 = 98</p>
<p>Desplazar los bits una posici&oacute;n a la izquierda es como multiplicar por dos:</p>
<p> 0100 0011 shl 1 = 1000 0110 = 134</p>
<p>Desplazar los bits una posici&oacute;n a la derecha es como dividir entre dos:</p>
<p> 0100 0011 shr 1 = 0010 0001 = 33</p>


<blockquote><i><b>Ejercicio propuesto 1.3.6:</b> Crea un programa que, para los números 133 y 7, calcule: su producto lógico, su suma lógica,
        su suma exclusiva, el complemento del segundo, el resultado de desplazar el segundo dos veces a la izquierda y el resultado de desplazar el primero dos veces a la derecha.</i></blockquote>


<h2>1.4. Variables</h2>

<p>Casi ningún programa real trabajará con datos prefijados. Lo habitual es que nuestros datos de partida los introduzca el usuario del programa, o se lean de un fichero o una base de datos, o se descarguen de Internet...</p>

<p>En todos esos casos, necesitaremos un "espacio" donde guardar esos datos. Eso es lo que llamaremos "<b>una variable</b>". Cada "variable" necesitará un nombre (por ejemplo, "x") y un tipo de datos,
para que nuestro ordenador sepa cuánto espacio necesitará reservarle.  El primer tipo de datos que usaremos será un número entero, que se designará con la palabra en inglés "integer".</p>

<p>Usaremos la palabra "<b>var</b>" para indicar que vamos a "<b>declarar variables</b>, algo que deberemos hacer antes de que comience el programa en sí. Ya dentro del cuerpo del programa, podremos <b>dar un valor</b> a la variable usando la expresión <b>:=</b> (un símbolos de "dos
puntos" y otro de "igual", seguidos, sin espacios entre medias), así:</p>

<p><pre><code class='language-pascal'>(* Primer ejemplo de "variables" *)

program Var1;

var
  x: integer;

begin 
  x := 5;
  writeLn('x vale ', x);
end.

(* Resultado:
x vale 5
*)
</code></pre></p>
<p>Podemos utilizar más de una variable, y entonces todas ellas se declararían en el bloque "var":</p>

<p><pre><code class='language-pascal'>(* Segundo ejemplo de "variables" *)

program Var2;

var
  x: integer;
  y: integer;

begin 
  x := 5;
  y := 8;
  writeLn('x vale ', x);
  writeLn('y vale ', y);
  writeLn('Su suma es ', x+y);
end.

(* Resultado:
x vale 5
y vale 8
Su suma es 13
*)
</code></pre></p>
<p>Si varias variables son del mismo tipo (por ahora es nuestro caso, porque sólo conocemos el tipo "integer"), podríamos declarar todas ellas a la vez, separadas por comas, para que el programa quede un poco más compacto, así:</p>

<p><pre><code class='language-pascal'>(* Tercer ejemplo de "variables" *)

program Var3;

var
  x,y: integer;

begin 
  x := 5;
  y := 8;
  writeLn('x vale ', x);
  writeLn('y vale ', y);
  writeLn('Su suma es ', x+y);
end.

(* Resultado:
x vale 5
y vale 8
Su suma es 13
*)
</code></pre></p>
<p>Por supuesto, las variables pueden tener nombres más largos, y eso algo que generalmente será conveniente aprovechar, para que nuestros programas sean tan <b>legibles</b> como sea posible:</p>

<p><pre><code class='language-pascal'>(* Cuarto ejemplo de "variables" *)

program Var4;

var
  numero, doble: integer;

begin 
  numero := 6;
  writeLn('El numero es ', numero);
  doble := numero * 2;
  writeLn('Y su doble es ', doble);
end.

(* Resultado:
El numero es 6
Y su doble es 12
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 1.4.1:</b> Crea un programa que defina una variable llamada "numero1" y otra llamada "numero2". La primera tendrá el valor 14 y la segunda el valor 37. Guarda su multiplicación en una variable llamada "producto" y luego muestra el valor de dicha multiplicación en pantalla.</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.4.2:</b> Crea una variable "n", que tenga el valor 123, y muestra el valor de la variable en pantalla. Ahora cambia su valor por 145 y comprueba que realmente se ha modificado. Finalmente, muestra el resultado de multiplicar esa variable por 7</i></blockquote>

<h2>1.5. Pedir datos al usuario</h2>

<p>Si queremos que el valor de la variable lo introduzca el usuario, usaremos la orden "<b>readLn</b>", abreviatura de "read" (leer) y "Line" (línea, porque se leerá hasta el final de línea, hasta que pulsemos Intro):</p>

<p><pre><code class='language-pascal'>(* Datos introducidos por el usuario, 1 *)

program ReadLn1;

var
  numero, doble: integer;

begin 
  write('Introduce un numero: ');
  readLn(numero);
  doble := numero * 2;
  writeLn('Su doble es ', doble);
end.

(* Ejemplo de ejecucion:
Introduce un numero: 7
Su doble es 14
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 1.5.1:</b> Crea un programa que pida un número al usuario y muestre su triple. Debe usar una única variable llamada "n".</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.5.2:</b> Crea un programa que pida dos números enteros y muestre su suma, usando variables llamadas "n1", "n2" y "suma".</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.5.3:</b> Crea un programa que pida dos números enteros y muestre su suma, diferencia, producto división del primero entre el segundo, y división del segundo entre el primero, usando dos variables llamadas "primerNumero" y "segundoNumero".</i></blockquote><blockquote><i><b>Ejercicio propuesto 1.5.4:</b> Pide dos números al usuario y muestra su división entera (el primer número entre el segundo) y el resto de dicha división. Usa los nombres de variables que quieras.</i></blockquote>
<p>Como curiosidad, también existe la orden "<b>read</b>", que no lee hasta el final de línea, sino hasta el siguiente espacio en blanco. Sólo tiene sentido utilizarla en el caso (poco habitual) de que queramos que el usuario introduzca varios valores en una misma línea, separados por espacios en blanco. Normalmente, si pedimos datos al usuario, querremos que los introduzca de uno en uno, y en ese caso será preferible usar "<b>readLn</b>".</p>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   8547 visitas desde el 25-02-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas00.php">Anterior</a></li>
                    <li><a href="cupas01b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        