<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 0. Contacto: instalar y escribir en pantalla.</title>

    
    <meta name="description" content="0. Contacto: instalar y escribir en pantalla. - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="interprete,compilador,ensamblador,c,pascal,basic" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 0. Contacto: instalar y escribir en pantalla.          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="index.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas00lazarusWindows.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>0. Contacto: instalar y escribir en pantalla.</h1>

<h2>0.1. ¿Por qué Pascal?</h2>

<p>A finales de los años 80 y principios de los 90, el lenguaje Pascal era uno de los mejor considerados a la hora de enseñar los fundamentos de la programación de ordenadores. Hoy en día hay lenguajes más potentes que también pueden ser adecuados para comenzar, pero suelen tener una curva de aprendizaje un poco más pronunciada que la de Pascal, por lo que existen bastantes centros de estudios que siguen usando Pascal como lenguaje de introducción a la programación y/o a la resolución de problemas con la ayuda de una computadora.</p>

<h2>0.2. ¿Cómo es un programa básico?</h2>

<p>Voy a intentar que este curso sea muy práctico, con muchos ejemplos, pocas explicaciones teóricas y muchos ejercicios propuestos (aunque en un apéndice al final de este texto encontrarás fundamentos teóricos adicionales, para cuando te apetezca leer un rato). Por eso, lo primero que haremos es ver la apariencia de un programa básico e instalar un entorno que nos permita probarlo y practicar a partir de ese momento:</p>

<p><pre><code class='language-pascal'>program Saludo;

(* Escribe Hola en pantalla *)

begin 
  write('Hola');
end.
</code></pre></p>
<p>Como se puede observar, casi todas las palabras están escritas en inglés. Será lo habitual en las "<b>órdenes</b>" que podremos dar en lenguaje Pascal, y también ocurrirá en la mayoría de lenguajes de programación.</p>

<p>Es habitual, aunque es opcional en la mayoría de versiones de Pascal, usar al principio la palabra "<b>program</b>", seguida del nombre que demos a nuestro programa. Nos ayudará a recordar de un vistazo para qué sirve el programa.</p>

<p>Si queremos añadir algún <b>comentario</b> más detallado, lo podemos indicar entre "(*" y "*)". Lo que escribamos entre esos símbolos será una aclaración para nosotros, que no afecta al funcionamiento real del programa. La mayoría de versiones de Pascal permiten también usar llaves: "{" y "}".</p>
 
<p>En el lenguaje Pascal no existe distinción entre <b>mayúsculas  y minúsculas</b>, por lo que "BEGIN" haría el mismo efecto que "begin" o "Begin".  Así, lo mejor será adoptar el convenio que a cada uno le resulte más legible: algunos autores emplean las órdenes en mayúsculas y el resto en minúsculas,otros todo en minúsculas, otros todo en minúsculas salvo las iniciales de cada palabra...  Yo emplearé normalmente minúsculas, y a veces mayúsculas y minúsculas combinadas cuando esto haga que alguna orden especialmente larga resulte más legible.</p>
 
<p>Si sabemos un poco de inglés, podríamos traducir literalmente el programa anterior, y así intuir lo que hace: </p>
 
<p><pre><code class='language-pascal'>programa saludo
comienzo
escribir 'Hola'
final</code></pre></p>
<p>Efectivamente, todo programa en Pascal deberá empezar con la orden "<b>begin</b>" y terminar con "<b>end.</b>" (cuidado: esa palabra "end" debe terminar con un <b>punto</b>).</p> 

<p>Y para escribir usaremos "<b>write</b>". El conjunto de todo lo que se 
desee escribir se indica entre paréntesis. Cuando se trata de un texto que 
queremos que aparezca "tal cual", éste se encierra además entre comillas 
(una comilla simple para el principio y otra para el final, como aparece en 
el ejemplo). </p>

<p>La orden "write" debe terminar en <b>punto y coma</b> y lo mismo ocurrirá con todas las órdenes que formen nuestro programa. En ocasiones podremos omitir ese punto y coma, pero veremos más adelante qué ocasiones son esas. </p>
 
 
<p>Hemos escrito la orden "write" algo más a la derecha que el resto.  Esto 
se llama <b>escritura indentada</b>, y consiste en escribir a la misma 
altura todos los comandos que pertenecen a un mismo bloque, para conseguir 
una mayor legibilidad. Realmente, en un programa en Pascal no hay necesidad 
de conservar una <b>estructura</b> tal que aparezca cada orden en una línea 
distinta. Los espacios en blanco, así como las líneas en blanco y los 
comentarios, son cosas que se suelen añadir claridad, pero realmente son los 
puntos y coma lo que indica el final de una orden, por lo que el programa 
anterior se podría haber escrito: </p>
 
<p><pre><code class='language-pascal'>
program Saludo; begin write('Hola'); end. 
</code></pre></p>
<p>o bien</p>  

<p><pre><code class='language-pascal'>program Saludo;
  begin            write('Hola');
     end.
</code></pre></p>
<p>lo que desde luego no se puede hacer es "partir palabras": si escribimos  </p>

<p><pre><code class='language-pascal'>pro gram Saludo;</code></pre></p>
<p>el ordenador creerá que "pro" y "gram" son dos órdenes distintas, 
y nos dirá que no sabe qué es eso.</p>

<p>Antes de ver cómo probar este programa, vamos a proponer unos pocos ejercicios que puedas intentarlos cuanto tengas tu entorno funcionando:</p>

<blockquote><i><b>Ejercicio propuesto 0.2.1:</b> Crea un programa que te salude por tu nombre (por ejemplo, "Hola, Nacho").</i></blockquote><blockquote><i><b>Ejercicio propuesto 0.2.2:</b> Crea un programa que primero te diga "Hola" y luego te diga "Adios", usando dos órdenes "Write" distintas. (¿Se comporta como esperabas?)</i></blockquote><blockquote><i><b>Ejercicio propuesto 0.2.3:</b> Crea una nueva versión del programa anterior que incluya dos comentarios: uno antes de decirte "Hola" y otro antes de decirte "Adios". (¿Cambia su comportamiento?)</i></blockquote>

<h2>0.3. Vamos a instalar un entorno de desarrollo</h2>

<p>Ha llegado el momento de escoger un entorno para probar este programa y para hacer los ejercicios. Elige el que más se aproxime a tu tipo de computadora. No necesitarás leer las instrucciones de instalación de todos ellos, sino sólo del que vayas a emplear:</p>

<ul>
  <li> Entorno recomendado en Windows: <a href="cupas00lazarusWindows.php">Lazarus</a>.</li>
  <li> Entorno recomendado en Linux o en una máquina virtual: <a href="cupas00linuxGeany.php">FreePascal y Geany</a>.</li>
  <li> Entorno alternativo en Windows: <a href="cupas00fpWindows.php">Free Pascal en modo consola</a>.</li>
  <li> Para equipos PC antiguos o emulador DosBox: <a href="cupas00tp55.php">Turbo Pascal 5 (gratuito) para MsDos</a>.</li>
  <li> Para equipos PC antiguos o emulador DosBox: <a href="cupas00tp7.php">Turbo Pascal 7 (comercial) para MsDos</a>.</li>
</ul>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   6219 visitas desde el 23-02-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="index.php">Anterior</a></li>
                    <li><a href="cupas00lazarusWindows.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        