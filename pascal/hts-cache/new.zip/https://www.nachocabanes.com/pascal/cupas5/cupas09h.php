<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>9.8. Listas de cadenas de texto: TStringList</title>

    
    <meta name="description" content="9.8. Listas de cadenas de texto: TStringList - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="string,list,strlist,stringlist" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            9.8. Listas de cadenas de texto: TStringList          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas09g.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas10.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h2>9.8. Listas de cadenas de texto: TStringList</h2>

<p>En Free Pascal (pero no en Turbo Pascal) tenemos predefinido un tipo de 
datos que es una lista de cadenas de texto. En ella podemos guardar nuevos 
elementos al final (con Add), insertar en cualquier posición (Insert), saber el 
tamaño (Count), obtener un dato (corchetes o Get) e incluso guardar a fichero 
todo el contenido con una única orden (SaveToFile),  cargar desde fichero 
(GetFromFile) y ordenar (Sort). </p>

<p>Para comenzar a usarlo deberemos usar dato := TStringList.Create y cuando 
terminemos deberemos liberar la memoria con Free. </p>

<p>Vamos a ver casi todo eso en un ejemplo:</p>

<p><pre><code class='language-pascal'>(* STRLIST.PAS, Ejemplo de TStringList *)
(* Parte de CUPAS5, por Nacho Cabanes  *)

program StrList;

uses classes;

var
    lista: TStringList;
    dato: string;
    i: integer;

begin
    lista := TStringList.Create;
    repeat
        write('Introduce un dato (Intro para acabar): ');
        readLn(dato);
        if dato <> '' then
            lista.Add(dato);
    until dato = '';

    for i:= lista.Count-1 downto 0 do
        writeLn(lista[i]);

    writeLn('Ordenando alfabéticamente...');
    lista.Sort;

    writeLn('Y guardando en "lista.txt"...');
    lista.SaveToFile('lista.txt');
    
    lista.Free;
end.
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 9.8.1:</b> Crea un programa que permita al usuario guardar una lista de
    frases. El usuario introducirá tantas frases como desee, e indicará que
    ha terminado pulsando Intro sin ningún otro texto. En ese momento la lista
    se guardará a fichero ("frases.txt"). Finalmente, se le preguntará qué texto quiere buscar
    (por ejemplo, "hola") y se le responderá cuántas frases contienen ese texto.
    La ejecución terminará cuando se pulse Intro en vez de un texto a buscar.</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.8.2:</b> Crea una nueva versión del programa 9.8.1, en la que se lean
    inicialmente las frases que ya formaban parte del fichero "frases.txt",
    en caso de que este existiera.</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.8.3:</b> Crea una versión mejorada del programa 9.8.2, que muestre un
    menú que permita añadir, contar las frases que contengan un cierto texto,
    mostrar las frases que contengan un texto, mostrar todas las frases o 
    terminar.</i></blockquote><blockquote><i><b>Ejercicio propuesto 9.8.4:</b> Crea un programa que permita al usuario guardar una lista de
    números reales. El usuario introducirá tantos datos como desee (usando
    99999 para terminar), y en ese momento se le mostrará la media de los
    valores, después todos los que están por encima de esa media (en una misma
    línea, separados por espacios en blanco) y finalmente todos los que están
    por debajo de esa media (en una nueva línea, también separados por espacios
    en blanco). Debes usar una lista de strings para guardar los datos.</i></blockquote>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   2623 visitas desde el 27-08-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas09g.php">Anterior</a></li>
                    <li><a href="cupas10.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        