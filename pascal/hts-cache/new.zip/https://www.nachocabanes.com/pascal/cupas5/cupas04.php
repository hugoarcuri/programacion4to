<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 4. Arrays, cadenas, registros y conjuntos.</title>

    
    <meta name="description" content="4. Arrays, cadenas, registros y conjuntos. - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="array,sort,ordenar,burbuja,borrar,insertar" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 4. Arrays, cadenas, registros y conjuntos.          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas03.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas04b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>4. Arrays, cadenas, registros y conjuntos.</h1>

<h2>4.1. Arrays</h2>

<h3>4.1.1. Arrays de una dimensión</h3>

<p>Un <b>array</b> (que algunos autores traducen como "<b>arreglo</b>") 
es una estructura que se utiliza para guardar una serie
de elementos, todos los cuales son del mismo tipo (por ejemplo, 20 números reales).</p>

<p> A la hora de definir un array, deberemos
indicar el índice inferior y superior (desde dónde y hasta
dónde queremos contar), separados por dos puntos (..), así
como el tipo de datos de esos elementos individuales.  Por ejemplo,
para guardar hasta 200 números enteros, usaríamos:</li></ul>
 
<p><pre><code class='language-pascal'>lista: array [1..200] of integer</code></pre></p> 
 
<p>Se suele emplear para definir <b>vectores o matrices</b>. Para mostrar 
en pantalla el segundo elemento de esa lista de números (o de ese 
vector) se usaría</p>

<p><pre><code class='language-pascal'>write( lista[2] );</code></pre></p>
<p>Un ejemplo completo, que guarde varios datos en un array y luego muestre uno de ellos podría ser:</p>

<p><pre><code class='language-pascal'>(* ARRAY00.PAS, Contacto con arrays    *)
(* Datos en posiciones prefijadas      *)
(* Parte de CUPAS5, por Nacho Cabanes  *)

Program Array00;

var
    datos: array[1..4] of integer;

begin
    datos[1] := 20;
    datos[2] := 12;
    datos[3] := 7;
    datos[4] := 35;
    
    writeLn('El segundo dato es ',dato[2]);
end. 
</code></pre></p>
<p>Es habitual recorrer todo un array usando un bucle "for", de modo que podamos pedir y mostrar los datos de forma repetitiva.
Por ejemplo, podríamos pedir al usuario 5 números y luego mostrarlos en orden inverso, así:</p>

<p><pre><code class='language-pascal'>(* ARRAY01.PAS, Ejemplo de uso de arrays (01): *)
(* Pedir datos y mostrarlos al revés           *)
(* Parte de CUPAS5, por Nacho Cabanes          *)

Program Array01;

var
    datos: array[1..5] of integer;
    i: integer;

begin
    for i := 1 to 5 do
    begin
        write('Deme el dato ',i,': ');
        readLn(datos[i]);
    end;

    write('Los datos al reves son: ');
    for i := 5 downto 1 do
        write(datos[i], ' ');
        
    writeLn;
end. 
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.1.1.1:</b> Crea un programa que reserve espacio para un Array de 3 números enteros, que asigne a sus elementos los valores 3, 5 y 8, y que después muestre en pantalla la suma de los valores de sus 3 elementos.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.1.2:</b> Crea un programa que pida al usuario cinco números enteros, los guarde en un array y luego muestre el primero y el último.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.1.3:</b> Crea un programa que pida al usuario diez números enteros, los guarde en un array y luego muestre los que se encuentran en posiciones impares (1, 3, 5, 7, 9).</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.1.4:</b> Crea un programa que pida al usuario diez números enteros, los guarde en un array y luego muestre los que son impares.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.1.5:</b> Crea un programa que sume dos vectores, cuyos componentes indicará el usuario. Por ejemplo, la suma de (1,2,3) y (7,11,-1) sería (8,13,2).</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.1.6:</b> Crea un programa que halle el producto escalar dos vectores, cuyos componentes indicará el usuario.</i></blockquote>
<h3>4.1.2. Buscar en un array</h3>

<p>Buscar en un array "tiene truco": si el elemento que estamos mirando contiene
el dato que buscábamos, sabremos con seguridad que el dato existía, pero, por el contrario, no
podremos afirmar que un dato no existe hasta que no hayamos comprobado todos
los elementos. Por eso, lo habitual es usar un "boolean" para memorizar si
lo hemos encontrado o no:</p>

<p><pre><code class='language-pascal'>(* ARRAYB.PAS, Buscar en un array     *)
(* Parte de CUPAS5, por Nacho Cabanes *)

program ArrayB;

var
    datos: array[1..5] of integer;
    i: integer;
    encontrado: boolean;

begin
    for i := 1 to 5 do
    begin
        write('Deme el dato ',i,': ');
        readLn(datos[i]);
    end;

    encontrado := false;
    write('Buscando un 10... ');
    for i := 1 to 5 do
        if datos[i] = 10 then encontrado := true;
        
    if encontrado then 
        writeLn('Encontrado!');
    else
        writeLn('No encontrado.');
end. 
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.1.2.1:</b> Crea un programa que pida al usuario diez números enteros, los guarde en un array y luego le pida un número más y diga si era parte de los 10 datos originales o no.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.2.2:</b> Crea un programa que pida al usuario diez números enteros, los guarde en un array y luego le vaya preguntando qué número quiere buscar de forma repetitiva, y diga si era parte de los 10 datos originales o no. Terminará cuando el número introducido sea 9999.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.2.3:</b> Crea un programa que pida al usuario dos listas de 5 números enteros, usando dos arrays distintos, y luego muestre en pantalla los números que aparecen en ambas listas.</i></blockquote>
<h3>4.1.3. Máximo y mínimo de un array</h3>

<p>No es difícil encontrar el valor máximo o el mínimo de un array. 
Debemos empezar con un máximo (o mínimo) provisional,
que puede ser el primer valor del array. A partir de ese punto, vamos comparando
uno a uno con todos los demás datos. Si el dato actual es mayor que el máximo
(o menor que el mínimo), pasará a ser nuestro nuevo máximo (o mínimo), que
deberemos memorizar.<p>

<p><pre><code class='language-pascal'>(* ARRAYMAX.PAS, Maximo valor en un array *)
(* Parte de CUPAS5, por Nacho Cabanes     *)
 
program ArrayMax;
 
var
    datos: array[1..6] of integer;
    i: integer;
    maximo: integer;
 
begin
    datos[1] := 20;
    datos[2] := 12;
    datos[3] := 7;
    datos[4] := 35;
    datos[5] := 48;
    datos[6] := 14;
 
    maximo := datos[1];
    for i := 2 to 6 do
        if datos[i] > maximo then 
            maximo := datos[i];

    writeLn('El maximo es: ', maximo);
end. 
 
(* Resultado:
El maximo es: 48
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.1.3.1:</b> Crea un programa que pida al usuario diez números reales, los guarde en un array y luego busque y muestre el menor de esos números.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.3.2:</b> Crea una versión alternativa, que pida al usuario diez números reales y muestre el menor de todos ellos, sin usar arrays.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.3.3:</b> Crea un programa que pida al usuario 10 nombres de personas y sus 10 estaturas. Estos datos se guardarán en dos arrays distintos. A continuación deberás mostrar el nombre de la persona más alta.</i></blockquote>
<h3>4.1.4. Arrays de dos o más dimensiones</h3>

<p>Cuando se trata de una matriz de 2, 3 o más dimensiones, podemos indicar los
rangos de valores aceptables, separados por comas.
Por ejemplo, una matriz de bidimensional de tamaño 3x2 que debiera contener números
reales sería:<p>
 
<p><pre><code class='language-pascal'>matriz1: array [1..3, 1..2] of real</code></pre></p>  
<p>y para ver el elemento (3,1) de la matriz haríamos:</p>

<p><pre><code class='language-pascal'>writeLn( matriz1[3,1] );</code></pre></p>
<p>Un ejemplo más completo, que pidiera 2x3 datos y mostrar uno de ellos sería:</p>

<p><pre><code class='language-pascal'>(* ARRAYBI.PAS, Array bidimensional   *)
(* Parte de CUPAS5, por Nacho Cabanes *)

program ArrayBi;

var
    datos: array[1..2, 1..3] of integer;
    fila,columna: integer;

begin
    for fila := 1 to 2 do
        for columna := 1 to 3 do
        begin
            write('Deme el dato de la fila ',fila,
                ' y columna ', columna, ': ');
            readLn(datos[fila, columna]);
        end;

    writeLn('El dato de la fila 1 y columna 2 es ', datos[1,2]);
end. 

(* Ejemplo de ejecucion:
Deme el dato de la fila 1 y columna 1: 1
Deme el dato de la fila 1 y columna 2: 20
Deme el dato de la fila 1 y columna 3: 3
Deme el dato de la fila 2 y columna 1: 54
Deme el dato de la fila 2 y columna 2: 15
Deme el dato de la fila 2 y columna 3: 9
El dato de la fila 1 y columna 2 es 20
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.1.4.1:</b> Crea un programa que pida al usuario dos bloques de 3 números enteros y luego muestre en pantalla las dos filas de tres datos cada una.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.4.2:</b> Crea un programa que pida al usuario dos bloques de 5 números enteros y luego diga la suma de ambos bloques.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.4.3:</b> Crea un programa que sume dos matrices de tamaño 3x3.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.4.4:</b> Si has estudiado álgebra matricial, crea un programa que multiplique dos matrices de tamaño 3x3.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.4.5:</b> Si has estudiado álgebra matricial, crea un programa que calcule el determinante de una matriz de tamaño 3x3.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.4.6:</b> Si has estudiado álgebra matricial, crea un programa que calcule el determinante de una matriz de tamaño 4x4.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.4.7:</b> Si has estudiado álgebra matricial, crea un programa de resolución de sistemas de ecuaciones de 3 ecuaciones con 3 incógnitas usando el método de Gauss.</i></blockquote>


<h3>4.1.5. Sobredimensionar un array</h3>

<p>Cuando no sabemos cuántos datos vamos a tener que guardar, una primera
solución es sobredimensionar: crear un array más grande de lo que esperemos
necesitar y llevar un contador de cuántos datos ya hemos almacenado:<p>

<p><pre><code class='language-pascal'>(* ARRAYSD.PAS, Array sobredimensionado *)
(* Parte de CUPAS5, por Nacho Cabanes  *)

program ArraySD;

var
       datos: array[1..20] of integer; { Los datos en si }
       cantidad: integer;               {  Cantidad de datos guardados }
       i: integer;                      { Para bucles }

begin
    { Pedimos 200 datos o hasta introducir el valor 999 }
    cantidad := 0;
    repeat
        if cantidad >= 200 then
            writeLn('No caben mas datos!')
        else
        begin
            cantidad := cantidad+1;
            write('Deme el dato ',cantidad,' (999 para salir): ');
            readLn(datos[cantidad]);
        end;
    until datos[cantidad]=999;

    { El ultimo dato no hay que guardarlo }
    cantidad := cantidad-1;

    { Al final, muestro todos }
    writeLn('Cantidad de datos: ', cantidad);
    writeLn('Los datos al reves son: ');
    for i := cantidad downto 1 do
        write(datos[i], ' ');
    writeLn;
end. 

(* Ejemplo de ejecucion:
Deme el dato 1 (999 para salir): 23
Deme el dato 2 (999 para salir): 45
Deme el dato 3 (999 para salir): 7
Deme el dato 4 (999 para salir): 16
Deme el dato 5 (999 para salir): 999
Cantidad de datos: 4
Los datos al reves son: 16 7 45 23 
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.1.5.1:</b> Crea un programa que pida al usuario tantos números reales como desee, para después mostrar todos los datos con dos cifras decimales.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.5.2:</b> Crea un programa que pida al usuario tantos números reales como desee, para después mostrar su media aritmética y los datos que están por encima de esa media.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.5.3:</b> Crea un programa que pida al usuario tantos números reales como desee, para después mostrar su media aritmética, sin utilizar arrays.</i></blockquote>

<h3>4.1.6. Borrar e insertar en un array</h3>

<p>En un array sobredimensionado, nos puede interesar borrar o insertar datos.
Para borrar, deberemos desplazar hacia "la izquierda" (hacia el principio del array)
los datos que hay desde esa posición, y luego disminuir el contador de datos:<p>

<p><pre><code class='language-pascal'>(* ARRAYBor.PAS, Borrar en un array sobredimensionado *)
(* Parte de CUPAS5, por Nacho Cabanes                 *)

Program ArrayBor;

var
    datos: array[1..10] of integer;
    cantidad: integer;
    i: integer;
    posicionBorrar: integer;

begin
    datos[1] := 20;
    datos[2] := 12;
    datos[3] := 7;
    datos[4] := 35;
    datos[5] := 8;
    datos[6] := 49;
    cantidad := 6;
    
    { Primero mostramos los datos }
    writeLn('Los datos iniciales son: ');
    for i := 1 to cantidad do
        write(datos[i], ' ');
    writeLn;
        
    { Ahora borramos el tercero }
    posicionBorrar := 3;
    for i := posicionBorrar to cantidad-1 do
        datos[i] := datos[i+1];
    cantidad := cantidad-1;
    
    { Y mostramos el resultado }
    writeLn('Los datos tras borrar el tercero son: ');
    for i := 1 to cantidad do
        write(datos[i], ' ');
    writeLn;
end. 

(* Resultado:
Los datos iniciales son: 
20 12 7 35 8 49 
Los datos tras borrar el tercero son: 
20 12 35 8 49 
*)
</code></pre></p>
<p>De forma similar, podríamos insertar un dato en una cierta posición, si 
primero desplazamos hacia "la derecha" (hacia el final del array) los datos 
que hay a partir de esa posición e incrementamos el contador que almacena
la cantidad de datos.</p>

<blockquote><i><b>Ejercicio propuesto 4.1.6.1:</b> Crea una variante del programa que borra un elemento de un array. En esta ocasión, deberá insertar el valor "10" en la tercera posición y mostrar el resultado.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.6.2:</b> Crea un programa que permita al usuario guardar tantos números
    enteros como desee (hasta un máximo de 1000). Deberá permitir añadir datos
    al final, insertar en cualquier posición, borrar cualquier posición o
    mostrar los datos que hay almacenados.</i></blockquote>

<h3>4.1.7. Ordenar los datos de un array</h3>

<p>¿Y si necesitamos ordenar los datos de menor a mayor, o de mayor a menor, o
(pronto) alfabéticamente? Hay muchas formas de hacerlo. Algunas son eficientes
pero difíciles de entender, otras son sencillas pero lentas, otras son
intermedias entre ambas.<p>

<p>Uno de los algoritmos de ordenación más simples y conocidos es el de "burbuja",
en el que se va comparando cada dato con todos los anteriores, de modo que el
más pequeño (el más "ligero", como si se tratara de una burbuja) vaya desplazándose
hacia el final del array (como si "subiera hacia la superficie"). Tras cada
pasada, el número más pequeño quedará colocado en su sitio:<p>

<p><pre><code class='language-pascal'>(* ARRAYORD.PAS, Ordenar un array (burbuja) *)
(* Parte de CUPAS5, por Nacho Cabanes       *)

Program ArrayOrd;

var
    datos: array[1..6] of integer;
    i,j: integer;
    temporal: integer;

begin
    datos[1] := 20;
    datos[2] := 12;
    datos[3] := 7;
    datos[4] := 35;
    datos[5] := 49;
    datos[6] := 8;
    
    { Primero mostramos los datos }
    writeLn('Los datos iniciales son: ');
    for i := 1 to 6 do
        write(datos[i], ' ');
    writeLn;
        
    { Ahora ordenamos mediante burbuja }
    for i := 6 downto 2 do
        for j := 0 to i - 1 do
            if datos[j] > datos[j + 1] then
            begin
                temporal := datos[j];
                datos[j] := datos[j + 1];
                datos[j + 1] := temporal;
            end;
    
    { Y mostramos el resultado }
    writeLn('Los datos tras ordenar son: ');
    for i := 1 to 6 do
        write(datos[i], ' ');
    writeLn;
end. 

(* Resultado:
Los datos iniciales son: 
20 12 7 35 49 8 
Los datos tras ordenar son: 
7 8 12 20 35 49 
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 4.1.7.1:</b> Modifica el programa de ordenación mediante burbuja, para que muestre
    en pantalla el resultado de cada paso intermedio.</i></blockquote><blockquote><i><b>Ejercicio propuesto 4.1.7.2:</b> Crea un programa que permita al usuario guardar tantos números
    enteros como desee (hasta un máximo de 1000) y luego los muestre ordenados.</i></blockquote>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   </p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas03.php">Anterior</a></li>
                    <li><a href="cupas04b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        