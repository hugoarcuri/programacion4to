<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>5. Constantes y tipos</title>

    
    <meta name="description" content="5. Constantes y tipos - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="generalidades,freepascal" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            5. Constantes y tipos          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas04d.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas05b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>5. Constantes y tipos</h1>

<h2>5.1. Definición de constantes</h2> 

<h3>5.1.1. Valores que no cambian</h3> 

<p>Cuando desarrollamos un programa, nos podemos encontrar con que hay
variables que realmente "no varían" a lo largo de la ejecución
de un programa, sino que su valor es <b>constante</b>.
</p>

<p>Hay una manera especial de definirlas: con el especificador "<b>const</b>",
que tiene el formato</p>

<p><pre><code class='language-pascal'>const Nombre = Valor;</code></pre></p>
<p>Cuando las declaramos, no será necesario indicar el tipo de datos, porque el
compilador lo puede deducir:</p>

<p><pre><code class='language-pascal'>const MiNombre = 'Nacho Cabanes'; 
const PI = 3.1415926535; 
const LongitudMaxima = 128; </code></pre></p>
 
<p>Ya en el cuerpo del programa, estas constantes se manejan igual que variables como las que habíamos
visto hasta hora, con la diferencia de que no se nos permitirá cambiar su valor. Por tanto,
es válido hacer
</p>

<p><pre><code class='language-pascal'>WriteLn(MiNombre); 
if Longitud > LongitudMaxima then ... 
OtraVariable := MiNombre; 
LongitudCircunferencia := 2 * PI * radio; </code></pre></p>
<p>pero no podríamos hacer</p>

<p><pre><code class='language-pascal'>PI := 3.14; 
MiNombre := 'Nacho'; 
LongitudMaxima := LongitudMaxima + 10;</code></pre></p>
<p>Con los pocos conocimientos que llevamos hasta ahora, las constantes
nos resultarán especialmente útiles para indicar el tamaño máximo de
un array, de modo que los cambios en el programa sean mínimos en caso
de que decidamos usar un tamaño de array mayor o menor, como en este ejemplo:</p>

<p><pre><code class='language-pascal'>(* CONST01.PAS, Const y arrays (01)   *)
(* Parte de CUPAS5, por Nacho Cabanes *)

Program Const01;

const
    MAXIMO = 5;

var
    datos: array[1..MAXIMO] of integer;
    i: integer;

begin
    for i := 1 to MAXIMO do
    begin
        write('Deme el dato ',i,': ');
        readLn(datos[i]);
    end;

    write('Los datos al reves son: ');
    for i := MAXIMO downto 1 do
        write(datos[i], ' ');
        
    writeLn;
end. 
</code></pre></p>
<p>Si decidimos que queremos trabajar con 10 datos, el único cambio sería el
valor de la constante; el resto de programa se comportaría correctamente en cuanto
recompilásemos.</p>

<p>Como se ve en este ejemplo, las declaraciones de constantes se hacen 
antes del cuerpo del programa principal, y generalmente antes de las 
declaraciones de variables.</p>


<blockquote><i><b>Ejercicio propuesto 5.1.1.1:</b> Crea una nueva versión del programa 4.1.3.1 (pedir 10 números reales, guardarlos en un array y luego buscar el menor de todos ellos), usando una constante para el tamaño del array, en vez de una variable.</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.1.1.2:</b> Crea una nueva versión del programa de adivinar números (3.4.6) para que el número a adivinar deba estar entre 1 y 1000 (estos límites se definirán mediante constantes) y el máximo de intentos permitidos sea 10 (también usando una constante).</i></blockquote>




<h3>5.1.2. Inicialización: Constantes "con tipo"</h3> 

<p>En Turbo Pascal (y Free Pascal), el identificador "const" tiene también  
otro uso menos habitual: definir lo que se suele llamar "<b>constantes con 
tipo</b>", que no son más que <b>variables normales</b>, pero a las que 
damos un valor inicial antes de que comience a ejecutarse el programa. Se 
usa </p>

<p><pre><code class='language-pascal'>const variable: tipo = valor;</code></pre></p>
<p>Un ejemplo más detallado sería:</p>

<p><pre><code class='language-pascal'>(* CONSTTIPO.PAS, Constantes con tipo *)
(* Parte de CUPAS5, por Nacho Cabanes *)

Program ConstTipo;

const
    x: integer = 5;
    y: byte = 2;

begin
    writeLn('La suma de X e Y es: ', x+y);

    write('Nuevo valor para X? ');
    readLn(x);
    
    write('Nuevo valor para Y? ');
    readLn(y);
    
    writeLn('La nueva suma de X e Y es: ', x+y);
end. 

(* Ejemplo de ejecucion:
La suma de X e Y es: 7
Nuevo valor para X? 3
Nuevo valor para Y? 6
La nueva suma de X e Y es: 9
*)
</code></pre></p>
<p>La única ventaja real sobre el uso "habitual" de una variable es la 
legibilidad: en el mismo punto en el que se declara la variable, queda
indicado cuál queremos que sea su valor inicial.</p>

<blockquote><i><b>Ejercicio propuesto 5.1.2.1:</b> Crea un programa que pida al usuario 10 números enteros y vaya calculando
    y mostrando su suma. No debes almacenar los datos en un array, y la suma
    debe guardarse en una variable que se haya inicializado a 0, usando una
    "constante con tipo".</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.1.2.2:</b> Crea un programa que pida al usuario 5 números enteros y vaya calculando
    y mostrando su producto. No debes almacenar los datos en un array, y el producto
    se debe guardar en una variable que se haya inicializado a 1, empleando una
    "constante con tipo".</i></blockquote>


<h3>5.1.3. Inicialización de arrays</h3> 

<p>Las "constantes con tipo" son especialmente útiles para dar valores iniciales
a todo un array, indicando todos sus valores entre paréntesis y separados por comas, así:</p>


<p><pre><code class='language-pascal'>(* CONSTTIPOARR.PAS, Constantes con tipo          *)
(* como forma de dar valores iniciales a un array *)
(* Parte de CUPAS5, por Nacho Cabanes             *)

program ConstTipoArr;

const
    diasMes : array[1..12] of byte =
        (31,28,31,30,31,30,  { Enero a Junio }
         31,31,30,31,30,31); { Julio a Diciembre }

var
    mes: byte;

begin
    write('Dime un numero de mes: ');
    readLn(mes);
    
    writeLn('Ese mes tiene ', diasMes[ mes ], ' dias');
end. 

(* Ejemplo de ejecucion:
Dime un numero de mes: 7
Ese mes tiene 31 dias
*)
</code></pre></p>
<p>No sólo se pueden emplear valores numéricos. Por ejemplo, también podemos
crear un array de cadenas de texto, si delimitamos los valores entre comillas
simples, de la siguiente manera:</p>

<p><pre><code class='language-pascal'>(* CONSTTIPOARR2.PAS, Constantes con tipo         *)
(* como forma de dar valores iniciales a un array *)
(* Version con cadenas de texto                   *)
(* Parte de CUPAS5, por Nacho Cabanes             *)

Program ConstTipoArr2;

const
    nombreMes : array[1..12] of string =
        ('enero', 'febrero', 'marzo', 'abril',
         'mayo', 'junio', 'julio', 'agosto',
         'septiembre', 'octubre', 'noviembre', 'diciembre');

var
    mes: byte;

begin
    write('Dime un numero de mes: ');
    readLn(mes);
    
    writeLn('Ese mes se llama ', nombreMes[ mes ]);
end. 

(* Ejemplo de ejecucion:
Dime un numero de mes: 4
Ese mes se llama abril
*)
</code></pre></p>

<blockquote><i><b>Ejercicio propuesto 5.1.3.1:</b> Crea una nueva versión del programa
    4.1.1.1 (que reserva espacio para un array de 3 números enteros, asigna a sus elementos los valores 3, 5 y 8, y que después muestre en pantalla la suma de los valores de sus 3 elementos), empleando
    constantes con tipo para dar esos valores iniciales.</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.1.3.2:</b> Crea un programa que pida al usuario el número de un mes
    y muestre la cantidad de días que tiene ese mes, así como el nombre del mes,
    usando dos arrays definidos mediante "constantes con tipo".</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.1.3.3:</b> Crea un programa que pida al usuario el nombre de un mes
    y muestre la cantidad de días que tiene ese mes,
    usando dos arrays definidos mediante "constantes con tipo".</i></blockquote><blockquote><i><b>Ejercicio propuesto 5.1.3.4:</b> Crea un programa que pida al usuario un número del 1 al 7
    y muestre el nombre del correspondiente día de la semana,
    usando un array definido con una "constante con tipo".</i></blockquote>
        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   </p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas04d.php">Anterior</a></li>
                    <li><a href="cupas05b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        