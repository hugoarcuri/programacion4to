<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Pascal y Geany bajo Linux</title>

    
    <meta name="description" content="Free Pascal y Geany bajo Linux - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="linux,geany,synaptic" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Free Pascal y Geany bajo Linux          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas00lazarusWindows.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas00fpWindows.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>
<h2>0.5. Free Pascal y Geany bajo Linux</h2>
    
    
<p>En casi cualquier distribución de Linux tendremos un gestor de paquetes que nos permita instalar nuevos programas. Uno de los más habituales es Synaptic:</p>

<p align="center"><img src="img/fpc-geany-linux01.png"></p>

<p>Es habitual que se nos pida que introduzcamos nuestra contraseña para ver si tenemos permisos para instalar nuevo software:</p>

<p align="center"><img src="img/fpc-geany-linux02.png"></p>

<p>En la lista de paquetes disponibles, podemos teclear "fpc" para que se nos lleve hasta el compilador de Pascal:</p>

<p align="center"><img src="img/fpc-geany-linux03.png"></p>

<p>Al hacer doble clic se nos mostrará la lista de paquetes adicionales que dependen de ése:</p>

<p align="center"><img src="img/fpc-geany-linux04.png"></p>

<p>Y todos ellos quedarán seleccionados. Entonces deberemos pulsar el botón "Aplicar":</p>

<p align="center"><img src="img/fpc-geany-linux05.png"></p>

<p>Se nos informará del tamaño de las descargas y de la cantidad de espacio que ocupará una vez instalado: </p>

<p align="center"><img src="img/fpc-geany-linux06.png"></p>

<p>Y comenzará la descarga en sí:</p>

<p align="center"><img src="img/fpc-geany-linux07.png"></p>

<p>Al cabo de un instante estará instalado:</p>

<p align="center"><img src="img/fpc-geany-linux08.png"></p>

<p>Si no queremos tener que compilar "desde línea de comandos", puede interesar instalar un editor para programadores, como Geany:</p>

<p align="center"><img src="img/fpc-geany-linux09.png"></p>

<p>Nuevamente se nos avisará de los demás paquetes que sean necesarios:</p>

<p align="center"><img src="img/fpc-geany-linux10.png"></p>

<p>Y del espacio que va a ocupar:</p>

<p align="center"><img src="img/fpc-geany-linux11.png"></p>

<p>Y en un instante estará listo:</p>

<p align="center"><img src="img/fpc-geany-linux12.png"></p>

<p>A partir de ese momento, deberíamos tener disponible el menú "Programación", y dentro de él estará "Geany":</p>

<p align="center"><img src="img/fpc-geany-linux13.png"></p>

<p>Que nos muestra una ventana dividida en 3 bloques:</p>

<p align="center"><img src="img/fpc-geany-linux14.png"></p>

<p>El bloque más grande es nuestra ventana de edición, en la que escribiremos el programa:</p>

<p align="center"><img src="img/fpc-geany-linux15.png"></p>

<p>En cuanto lo guardemos con un nombre terminado en ".pas", se realzará la sintaxis en colores, siguiendo las reglas de Pascal:</p>

<p align="center"><img src="img/fpc-geany-linux16.png"></p>

<p>Y entonces ya podremos pulsar el botón "Compilar":</p>

<p align="center"><img src="img/fpc-geany-linux17.png"></p>

<p>En el bloque inferior de nuestra ventana se nos informará de si la compilación ha sido correcta; en caso de que no fuera así, las líneas con errores aparecerían subrayadas en color rojo en la ventana principal:</p>

<p align="center"><img src="img/fpc-geany-linux18.png"></p>

<p>Si la compilación ha sido correcta, ya podemos ejecutar nuestro programa, sin necesidad de salir de Geany:</p>

<p align="center"><img src="img/fpc-geany-linux19.png"></p>

<p>Y el resultado se mostrará en una nueva ventana. Cuando termine la ejecución del programa, la ventana permanecerá abierta hasta que pulsemos Intro, para que podamos comprobar los resultados:</p>

<p align="center"><img src="img/fpc-geany-linux20.png"></p>


           </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   4265 visitas desde el 04-03-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas00lazarusWindows.php">Anterior</a></li>
                    <li><a href="cupas00fpWindows.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        