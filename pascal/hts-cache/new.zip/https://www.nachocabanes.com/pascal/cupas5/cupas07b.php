<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 7b. Manejo de ficheros (2: ficheros con tipo)</title>

    
    <meta name="description" content="7b. Manejo de ficheros (2: ficheros con tipo) - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="file,file of,seek,filesize" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 7b. Manejo de ficheros (2: ficheros con tipo)          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas07.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas07c.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        

<h2>7.2. Ficheros con tipo.</h2>

<p>Hemos visto cómo acceder a los ficheros de texto, tanto para leerlos como 
para escribir en ellos.  Ahora nos centraremos en lo que vamos a llamar "<b>
ficheros con tipo</b>".</p>

<p>Estos son ficheros en los que cada uno de los elementos que lo integran
es del mismo tipo (como vimos que ocurre en un array).</p>

<p>En los de texto se podría considerar que estaban formados por
elementos iguales, de tipo "char", pero es un dato demasiado pequeño,
de modo que los leíamos y escribíamos línea a línea.</p>

<p>Ahora vamos a llegar más
allá, porque un fichero formado por datos de tipo "record" sería
lo ideal para una agenda o cualquier otra colección de datos
estructurados.
</p>

<p>Conociendo los ficheros de texto, no hay muchas diferencias
a la hora de un primer manejo de ficheros con tipo: debemos declarar un fichero, asignarlo,
abrirlo, trabajar con él y cerrarlo.
</p>

<p>Pero ahora también podemos hacer más cosas, que con un fichero de texto no era posible.
En aquellos, el uso habitual era leer línea
por línea, no carácter por carácter.  Como las
líneas pueden tener cualquier longitud, no podíamos empezar
por leer la línea 4 (por ejemplo), sin haber leído antes las
tres anteriores, porque no sabríamos en qué posición del fichero empezará
esa línea 4.  Esto se conoce como <p>acceso secuencial</p>: para llegar a 
un punto debemos recorrer primero las partes anteriores del fichero.</p>

<p>Por el contrario, en un "fichero con tipo", sí que sabemos lo que va a ocupar cada dato, ya que todos
son del mismo tipo, y podremos aprovecharlo para acceder a una determinada
posición del fichero cuando nos interese, sin necesidad de pasar
por todas las posiciones anteriores.  Esto es el <b>acceso aleatorio</b> 
(o "acceso directo"). La idea es sencilla: si cada ficha ocupa 25 bytes, y queremos leer la
número 8, bastaría con "saltarnos" 25*7=175 bytes.
</p>

<p>Pero algunos compiladores recientes (como Turbo Pascal y Free Pascal) nos 
lo facilitan más aún, con una orden, <b>seek</b>, que permite saltar a una 
cierta "ficha" (un "record") dentro del fichero, sin necesidad de 
calcular nada nosotros mismos.</p>

<p>Vamos a comenzar por introducir varias fichas en un fichero con tipo. Las
únicas diferencias con lo que conocemos son que el tipo del fichero no será
"text" sino "<b>file of TipoBase</b>" y que escribiremos con "<b>write</b>",
en vez de "writeLn":</p>

<p><pre><code class='language-pascal'>(* CREAFT.PAS, Crea un fichero "con tipo" *)
(* Parte de CUPAS5, por Nacho Cabanes     *)

program CreaFT;

type
    ficha = record                           (* Nuestras fichas *)
        nombre: string [80];
        edad:   byte
    end;

var
    fichero:    file of ficha;               (* Nuestro fichero *)
    numFicha:   byte;                        (* Para bucles *)
    datoActual: ficha;                       (* La ficha actual *)

begin
    assign( fichero, 'ejemplo.dat' );        (* Asignamos *)
    rewrite( fichero );                      (* Abrimos (escritura) *)
    writeLn('Te ire pidiendo los datos de cuatro personas...' );
    for numFicha := 1 to 4 do                (* Repetimos 4 veces: *)
    begin                                    (* Pedimos un dato *)
        writeLn('Introduce el nombre de la persona numero ', numFicha);
        readln( datoActual.nombre );
        writeLn('Introduce la edad de la persona numero ', numFicha);
        readln( datoActual.edad );
        write( fichero, datoActual );        (* Guardamos el dato *)
    end;
    close( fichero );                        (* Cerramos el fichero *)
end.  
</code></pre></p>

<p>Si queremos leer sólo la tercera ficha de este fichero de datos que acabamos de crear,
usaríamos "<b>seek"</b>. La posición de las fichas dentro de un fichero de empieza
a numerar en 0, que corresponderá a la primera posición. 
Así, accederemos a la segunda posición con un 1, a la tercera
con un 2, y en general a la "n" con "<b>seek(fichero,n-1)</b>":
</p> 

<p><pre><code class='language-pascal'>(* LEEFT.PAS, Lee un dato de un fichero "con tipo" *)
(* Parte de CUPAS5, por Nacho Cabanes              *)

program LeeFt;

type
    ficha = record
        nombre: string [80];
        edad:   byte
    end;

var
    fichero:    file of ficha;
    datoActual: ficha;

begin
    assign( fichero, 'ejemplo.dat' );
    reset( fichero );                     (* Abrimos (lectura) *)
    seek( fichero, 2 );                   (* <== Vamos a la ficha 3 *)
    read( fichero, datoActual );          (* Leemos *)
    writeLn('El tercer nombre es: ', datoActual.nombre );
    writeLn('Su edad es: ',datoActual.edad );
    close( fichero );                     (* Y cerramos el fichero *)
end. 
</code></pre></p>

<p>Por supuesto, también podemos leer un fichero con tipo hasta el final. 
La diferencia con un fichero de texto es que ahora no podemos usar "while not eof",
pero la alternativa es comprobar el tamaño usando "<b>filesize</b>", de modo que podremos
leer "hacia delante" con "read" (y usar un contador con un "for"), o bien
también saltar a cualquier otra posición con "seek":
</p> 

<p><pre><code class='language-pascal'>(* LEEFT2.PAS, Lee todo un fichero "con tipo" *)
(* Parte de CUPAS5, por Nacho Cabanes         *)

program LeeFt2;

type
    ficha = record
        nombre: string [80];
        edad:   byte
    end;

var
    fichero:    file of ficha;
    datoActual: ficha;
    tamanyo:    longint;
    numFicha:   integer;

begin
    assign( fichero, 'ejemplo.dat' );
    reset( fichero );
    tamanyo := filesize( fichero );
    for numFicha := 1 to tamanyo do
    begin
        read( fichero, datoActual );
        writeLn('Ficha actual: ', numFicha );
        writeLn('Nombre: ', datoActual.nombre );
        writeLn('Edad: ',datoActual.edad );
        writeLn;
    end;
    close( fichero );
end. 
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 7.2.1:</b> Crea un programa que pida al usuario los nombres de los 12 meses y la cantidad de días de cada mes, almacene cada uno de esos pares de datos en un "record" y los guarde en un "fichero con tipo" llamado "meses.dat".</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.2.2:</b> Crea un programa que lea el fichero "meses.dat" como si fuera un fichero de texto y muestre en pantalla lo que va leyendo. Comprobarás que no se comportará correctamente, aunque hayas guardado "sólo" textos y números en el fichero.</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.2.3:</b> Crea un programa que lea y muestre el fichero "meses.dat" como "fichero con tipo", usando la construcción "while not eof".</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.2.4:</b> Crea un programa que lea y muestre el fichero "meses.dat" como "fichero con tipo", usando "filesize" y un bucle "for".</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.2.5:</b> Crea un programa que pida al usuario el número de un mes, de 1 (enero) a 12 (diciembre) y muestre el nombre de ese mes y la cantidad de días que contiene, usando "seek" en el fichero "meses.dat".</i></blockquote><blockquote><i><b>Ejercicio propuesto 7.2.6:</b> Crea un programa que lea y muestre el fichero "meses.dat" en orden inverso (del último mes al primero), usando "filesize", "seek" y un bucle "for".</i></blockquote>

        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   5049 visitas desde el 25-05-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas07.php">Anterior</a></li>
                    <li><a href="cupas07c.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        