<!doctype html><!--[if IE 9]><html class="lt-ie10" lang="es" > <![endif]--><html class="no-js" lang="es" 
    data-useragent="Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso de Pascal - 2. Condiciones</title>

    
    <meta name="description" content="2. Condiciones - Por Nacho Cabanes" />
    
    <meta name="author" content="Nacho Cabanes" />
    <meta name="keywords" content="if,case" />

    <link rel="stylesheet" href="../../css/foundation.css" />
    <link rel="stylesheet" href="../../css/prism.css" />
    <script src="../../js/modernizr.js"></script>
    <script src="../../css/prism.js"></script>
    <style type="text/css">
    pre {
      background: #F2F2F2;
      padding: 15px;
      line-height: 1.5em;
      font-size: 1.1em;
      display: block;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      word-wrap: break-word;
      white-space: pre-wrap;
    }
    p {
      margin-bottom: 0.5rem;
      margin-top: 0.5rem;
    }
    </style>
  </head>
  <body>
    
<!-- Navegación (Nav) -->
 
  <nav class="top-bar" data-topbar>
    <ul class="title-area">
      <!-- Título -->
      <li class="name">
        <h1>
          <a href="#">
            Curso de Pascal - 2. Condiciones          </a>
        </h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span>menu</span></a></li>
    </ul>
 
    <section class="top-bar-section">
      <!-- Navegación derecha -->
      <ul class="right">
          <li class="divider"></li>
          <li><a href="index.php">Índice</a></li>
          <li class="divider"></li>
            <li><a href="cupas01b.php">Anterior</a></li>
            <li class="divider"></li>
            <li><a href="cupas02b.php">Posterior</a></li>
            <li class="divider"></li>
            <li><a href="../../">NachoCabanes.com</a></li>
      </ul>
    </section>
  </nav>
 
  <!-- Fin de la barra superior -->
  
  
    <!-- Aviso cookies -->
           <!-- Fin de aviso cookies -->
 
  <div class="row">
    <div class="large-12 columns">
 
       
    <style type="text/css">
.top-bar {
  background: #4040F0;
}
.top-bar-section li:not(.has-form) a:not(.button) {
  background: #4040F0;
}

</style>        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
        
<h1>2. Condiciones</h1>

<h2>2.1. Si... entonces...</h2>

<h3>2.1.1. Condiciones básicas</h3>

<p>Vamos a ver cómo podemos evaluar condiciones
desde Pascal.  La primera construcción que trataremos es <b>if
... then</b>, que en español se podría traducir como "si ... entonces", algo que
expresa bastante bien lo que podemos hacer con ella:</p>

<p><pre><code class='language-pascal'>(* IF1.PAS, primera prueba de "if"    *)
(* Parte de CUPAS5, por Nacho Cabanes *)

program if1;

var numero: integer;

begin
    writeLn('Escriba un numero');
    readLn(numero);
    if numero > 0 then writeLn('El numero es positivo');
end. 

(* Ejemplo de ejecucion:
Escriba un numero
26
El numero es positivo
*)
</code></pre></p>
<p>Es decir, tras "if" se una indica "condición", que debe dar como resultado "verdadero" o "falso".
La "sentencia" que indiquemos tras la palabra "then" se ejecutará si esa condición es "verdadera".</p>

<p>A partir de ahora, el <b>comentario de la cabecera</b> de nuestro fuente será como éste, un poco más detallado para indicar un "nombre del fuente" y la versión del curso a la que pertenece, de modo que sea más fácil saber de qué fuente se está hablando en caso de preguntar dudas en algún foro, como los de <a href="http://www.aprendeaprogramar.com/mod/forum/view.php?f=14">AprendeAProgramar.com</a>. Además, los fuentes no usarán <b>acentos ni eñe</b>, para que no se conviertan en "caracteres extraños" si se llevan a un sistema operativo distinto.</p>

<p>En nuestro caso, veíamos si el número era mayor que cero (positivo). Los "operadores de comparación" que podemos emplear son:</p>

<table>
    <tr><td><b>Operador</b></td><td><b>Significado</b></td></tr>
    <tr><td>&gt;</td><td>Mayor que</td></tr>
    <tr><td>&gt;=</td><td>Mayor o igual que</td></tr>
    <tr><td>&lt;</td><td>Menor que</td></tr>
    <tr><td>&lt;=</td><td>Menor o igual que</td></tr>
    <tr><td>=</td><td>Igual que</td></tr>
    <tr><td>&lt;&gt;</td><td>Distinto de</td></tr>
</table>

<blockquote><i><b>Ejercicio propuesto 2.1.1.1:</b> Crea un programa que pida al usuario un número real y diga si es mayor de 10.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.1.2:</b> Crea un programa que pida al usuario un número entero y diga si es par (pista: habrá que comprobar el resto de la división entre 2).</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.1.3:</b> Crea un programa que pida al usuario un número entero y diga si ha tecleado el número 5 o ha tecleado un número distinto.</i></blockquote>
<h3>2.1.2. Si no se cumple la condición</h3> 

<p>También podemos indicar lo
que queremos que se haga <b>si no se cumple</b> la condición. 
Para ello tenemos la construcción "if condición then sentencia1
<b>else</b> 
sentencia2":</p>

<p><pre><code class='language-pascal'>(* IF2.PAS, uso de "if" con "else"    *)
(* Parte de CUPAS5, por Nacho Cabanes *)

program if2;

var
    numero: integer;

begin
    writeLn('Escriba un numero');
    readLn(numero);
    if numero<0 then
        writeLn('El numero es negativo.')
    else
        writeLn('El numero es positivo o cero.')
end. 
 
(* Ejemplo de ejecucion:
Escriba un numero
26
El numero es positivo o cero.
*)
</code></pre></p>
<p>El comportamiento no es exactamente el mismo que si escribimos dos "if", con condiciones opuestas, como en este ejemplo:</p>

<p><pre><code class='language-pascal'>(* IF2B.PAS, Dos "if" alternativos, sin "else" *)
(* Parte de CUPAS5, por Nacho Cabanes          *)

program if2b;

var
    numero: integer;

begin
    writeLn('Escriba un numero');
    readLn(numero);
    if numero < 0 then
        writeLn('El numero es negativo.')
    if numero >= 0 then
        writeLn('El numero es positivo o cero.')
end. 
 
(* Ejemplo de ejecucion:
Escriba un numero
26
El numero es positivo o cero.
*)
</code></pre></p>
<p>En este segundo fuente se analizará la segunda condición, incluso en caso de que se haya cumplido la primera; en caso de usar "else", por el contrario, no se analiza la segunda parte cuando se cumple la condición inicial.</p>

<p>En ambos fuentes hemos vuelto a emplear <b>escritura indentada</b>: las líneas que "dependen" de la anterior (como la orden que sigue a un "if" o a un "else") están un poco más a la derecha. La recomendación más habitual para esta "sangría" adicional en el texto es no usar el símbolo de tabulación, sino espacios en blanco, y la cantidad de espacios que se suele emplear es 4 (casi cualquier editor de texto moderno se podrá configurar para escribir espacios al pulsar la tecla de tabulación, y para que esa cantidad de espacios sea la que nosotros indiquemos).</p>

<p>Un detalle importante que conviene tener en cuenta es que antes del
"else" <b>no debe haber</b> un punto y coma, porque eso indicaría
el final de la sentencia "if...", y el compilador nos avisaría con
un error.</p>



<blockquote><i><b>Ejercicio propuesto 2.1.2.1:</b> Crea un programa que pida al usuario un número real y diga si ha tecleado el número 5 o ha tecleado un número distinto, usando "else".</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.2.2:</b> Crea un programa que pida al usuario un número entero y diga si es par o es impar.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.2.3:</b> Crea un programa que pida al usuario dos números enteros y diga el resultado de dividir el primero entre el segundo si el segundo no es cero, o que escriba "no se puede dividir" en caso contrario.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.2.4:</b> Crea un programa que pida al usuario un número real y muestre su valor absoluto (si es positivo, lo mostrará tal cual; si es negativo, le cambiará el signo).</i></blockquote>


<h3>2.1.3. Condiciones y sentencias compuestas</h3> 

<p>Si queremos hacer varias cosas cuando se cumpla una cierta condición, deberemos encerrar todas ellas entre "begin" y "end", para formar una "<b>sentencia compuesta</b>":</p>

<p><pre><code class='language-pascal'>(* IF3.PAS, "if" y sentencias compuestas *)
(* Parte de CUPAS5, por Nacho Cabanes    *)

program if3;

var
    numero: integer;

begin
    writeLn('Escriba un numero');
    readLn(numero);
    if numero < 0 then
    begin
        writeLn('El numero es negativo.  Pulse INTRO para seguir.');
        readLn
    end;
end. 
 
(* Ejemplo de ejecucion:
Escriba un numero
-10
El numero es negativo.  Pulse INTRO para seguir.

*)
</code></pre></p>
<p>En este ejemplo, si el número es negativo, se ejecutan dos acciones:
escribir un mensaje en pantalla y esperar a que el usuario pulse INTRO
(o ENTER, o RETURN, o &crarr;, según sea nuestro teclado), lo que
podemos conseguir usando "readln" pero sin indicar ninguna variable en
la que queremos almacenar lo que el usuario teclee.
</p>

<p><i>Nota</i>: nuevamente, hemos empleado la <b>escritura indentada</b> 
para intentar que el programa resulte más legible: los pasos que
forman parte de cada "sentencia compuesta" están tabulados una posición más a la derecha, para que sea fácil ver dónde empieza y dónde termina el bloque.</p>

<p>Como se puede observar en la última orden "readln", <b>no es necesario punto y coma antes de un "end"</b>, pero tampoco se considera un error si se conserva el punto y coma.</p>

<blockquote><i><b>Ejercicio propuesto 2.1.3.1:</b> Crea un programa que pida al usuario su identificador (un número entero). Sólo si ese identificador es "2001", deberá entonces pedirle una contraseña (otro número entero), y en caso de que la contraseña sea "1234", le responderá diciendo "Bienvenido!"</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.3.2:</b> Pide al usuario dos números enteros. Si el segundo es cero, deberás mostrar el texto "No se puede dividir entre cero", y en caso contrario, se calculará el valor de la división en una nueva variable y después se mostrará el valor de dicha variable"</i></blockquote>

<h3>2.1.4. Sentencias "If" encadenadas</h3>
<p>Si unas condiciones dependen de otras anteriores, podemos <b>encadenar</b> varias sentencias "if...then...else":</p>

<p><pre><code class='language-pascal'>(* IF4.PAS, "if" encadenados             *)
(* Parte de CUPAS5, por Nacho Cabanes    *)

program if4;

var
    numero: integer;

begin
    writeLn('Escriba un numero');
    readLn(numero);
    if numero<0 then
        writeLn('El numero es negativo.')
    else if numero>0 then
        writeLn('El numero es positivo.')
    else
        writeLn('El numero es cero.')
end. 

(* Ejemplo de ejecucion:
Escriba un numero
0
El numero es cero.
*)
</code></pre></p>
<blockquote><i><b>Ejercicio propuesto 2.1.4.1:</b> Crea un programa que pida al usuario un número entero y diga si es mayor de 10, es menor de 10 o es exactamente 10.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.4.2:</b> Crea un programa que pida al usuario dos números reales y que diga si son iguales, o, en caso contrario, diga cual es el mayor de los dos.</i></blockquote>


<h3>2.1.5. Varias condiciones simultáneas.</h3> 

<p>Si se deben cumplir <b>varias condiciones </b>a 
la vez, podemos <b>enlazarlas</b> con "and" (y).  Si se pueden cumplir
varias, usaremos "or" (o).  Para detallar que una condición NO debe cumplirse, utilizaremos "not" (no):</p>

<p><pre><code class='language-pascal'>if ( opcion = 1 ) and ( puntos > 500 ) then [...]</code></pre></p><p><pre><code class='language-pascal'>if ( opcion = 3 ) or ( enemigos = 0 ) then [...]</code></pre></p><p><pre><code class='language-pascal'>if not ( vidas > 0 ) then [...]</code></pre></p><p><pre><code class='language-pascal'>if ( opcion = 2 ) and not ( nivelDeAcceso < 40 ) then [...]</code></pre></p>



<blockquote><i><b>Ejercicio propuesto 2.1.5.1:</b> Crea un programa que pida al usuario un número entero y diga si es par y a la vez múltiplo de 3.</i></blockquote><blockquote><i><b>Ejercicio propuesto 2.1.5.2:</b> Crea un programa que pida al usuario dos números reales y diga si ambos son positivos.</i></blockquote>


        <p style="text-align: center"><br />
      <script type="text/javascript"><!--
        google_ad_client = "pub-4298821349414973";
        google_ad_width = 320;
        google_ad_height = 50;
        google_ad_format = "320x50_as";
        google_ad_type = "text_image";
        google_ad_channel ="";
        google_color_border = "D1D1D1";
        google_color_bg = "FFFFFF";
        google_color_link = "516695";
        google_color_url = "516695";
        google_color_text = "000000";
//--></script>
      <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
      </script>
      </p>
                   </div>
        </div>
      </div>
      
    <!-- Pie (Footer) -->
 
      <footer class="row">
        <div class="large-12 columns"><hr>
            <div class="row">
 
              <div class="large-6 columns">
                  <p>&copy; 2015 <a href="http://www.nachocabanes.com">Nacho Cabanes</a>
                   6076 visitas desde el 04-03-2014</p>
              </div>
 
              <div class="large-6 small-12 columns">
                  <ul class="inline-list right">
                    <li><a href="index.php">Índice</a></li>
                    <li><a href="cupas01b.php">Anterior</a></li>
                    <li><a href="cupas02b.php">Posterior</a></li>
                    <li><a href="../../">NachoCabanes.com</a></li>
                  </ul>
              </div>
 
            </div>
        </div>
      </footer>
 
    <!-- Fin del pie -->
 
    </div>
  </div>
 
    <script src="../../js/jquery.js"></script>
    <script src="../../js/foundation.min.js"></script>
    <script>
      $(document).foundation();

      var doc = document.documentElement;
      doc.setAttribute('data-useragent', navigator.userAgent);
    </script>
    
    
  </body>
</html>
        